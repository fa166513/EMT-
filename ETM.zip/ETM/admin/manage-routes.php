<?php
session_start();
include("../config/config.php");

// Admin auth check
if(!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

$admin_name = $_SESSION['user'] ?? 'Admin';
$toast = $toast_type = '';

// ── HANDLE ACTIONS ──
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ADD ROUTE
    if($action === 'add') {
        $source      = trim($_POST['source']);
        $destination = trim($_POST['destination']);
        $distance    = (int)($_POST['distance'] ?? 0);
        $duration    = trim($_POST['duration'] ?? '');
        $base_fare   = (float)($_POST['base_fare'] ?? 0);

        if(empty($source) || empty($destination)) {
            $toast = 'Source and destination are required.'; $toast_type = 'error';
        } elseif(strtolower($source) === strtolower($destination)) {
            $toast = 'Source and destination cannot be the same.'; $toast_type = 'error';
        } else {
            $stmt = $conn->prepare("INSERT INTO routes (source, destination, distance_km, duration, base_fare) VALUES (?,?,?,?,?)");
            $stmt->bind_param("ssids", $source, $destination, $distance, $base_fare, $duration);
            if($stmt->execute()) { $toast = 'Route added successfully!'; $toast_type = 'success'; }
            else { $toast = 'Error adding route.'; $toast_type = 'error'; }
            $stmt->close();
        }

    // EDIT ROUTE
    } elseif($action === 'edit') {
        $id          = (int)$_POST['route_id'];
        $source      = trim($_POST['source']);
        $destination = trim($_POST['destination']);
        $distance    = (int)($_POST['distance'] ?? 0);
        $duration    = trim($_POST['duration'] ?? '');
        $base_fare   = (float)($_POST['base_fare'] ?? 0);

        $stmt = $conn->prepare("UPDATE routes SET source=?, destination=?, distance_km=?, duration=?, base_fare=? WHERE id=?");
        $stmt->bind_param("ssidsi", $source, $destination, $distance, $base_fare, $duration, $id);
        if($stmt->execute()) { $toast = 'Route updated successfully!'; $toast_type = 'success'; }
        else { $toast = 'Error updating route.'; $toast_type = 'error'; }
        $stmt->close();

    // DELETE ROUTE
    } elseif($action === 'delete') {
        $id   = (int)$_POST['route_id'];
        $used = $conn->query("SELECT COUNT(*) as c FROM buses WHERE route_id=$id")->fetch_assoc()['c'];
        if($used > 0) {
            $toast = "Cannot delete — $used bus(es) are assigned to this route."; $toast_type = 'error';
        } else {
            $conn->query("DELETE FROM routes WHERE id=$id");
            $toast = 'Route deleted.'; $toast_type = 'warn';
        }

    // TOGGLE ACTIVE
    } elseif($action === 'toggle') {
        $id  = (int)$_POST['route_id'];
        $val = (int)$_POST['current_active'] === 1 ? 0 : 1;
        $conn->query("UPDATE routes SET is_active=$val WHERE id=$id");
        $toast = $val ? 'Route activated.' : 'Route deactivated.'; $toast_type = 'success';
    }
}

// ── FETCH ROUTES ──
$routes = $conn->query("
    SELECT r.*,
           (SELECT COUNT(*) FROM buses WHERE route_id = r.id) as bus_count,
           (SELECT COUNT(*) FROM bookings b JOIN buses bs ON b.bus_id = bs.id WHERE bs.route_id = r.id) as booking_count
    FROM routes r
    ORDER BY r.id DESC
");

$total_routes          = $conn->query("SELECT COUNT(*) as t FROM routes")->fetch_assoc()['t'];
$active_routes         = $conn->query("SELECT COUNT(*) as t FROM routes WHERE is_active=1")->fetch_assoc()['t'];
$total_buses_on_routes = $conn->query("SELECT COUNT(*) as t FROM buses")->fetch_assoc()['t'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manage Routes — ETrans Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root{--navy:#0b1f3a;--blue:#1a5cff;--cyan:#00d4ff;--green:#00c48c;--gold:#f5a623;--red:#ff4d6d;--light:#f0f4ff;--white:#ffffff;--sidebar:260px;}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--light);display:flex;min-height:100vh;}

/* SIDEBAR */
.sidebar{width:var(--sidebar);background:var(--navy);display:flex;flex-direction:column;padding:28px 16px;position:fixed;top:0;left:0;height:100vh;overflow-y:auto;z-index:100;}
.sidebar-brand{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;color:white;padding:0 10px;margin-bottom:8px;text-decoration:none;display:flex;align-items:center;gap:8px;}
.sidebar-brand span{color:var(--cyan);}
.sidebar-brand .b-icon{width:34px;height:34px;background:linear-gradient(135deg,var(--blue),var(--cyan));border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px;}
.admin-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(255,77,109,0.15);border:1px solid rgba(255,77,109,0.3);color:#ff8fa3;font-size:11px;font-weight:700;padding:3px 10px;border-radius:50px;margin:6px 10px 20px;}
.nav-section{font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:rgba(255,255,255,0.28);padding:12px 12px 6px;}
.nav-item{display:flex;align-items:center;gap:11px;padding:11px 14px;border-radius:10px;color:rgba(255,255,255,0.6);font-size:14px;font-weight:500;text-decoration:none;transition:all .2s;margin-bottom:2px;}
.nav-item:hover{background:rgba(255,255,255,0.07);color:white;}
.nav-item.active{background:rgba(26,92,255,0.25);border:1px solid rgba(26,92,255,0.35);color:white;}
.nav-item i{color:rgba(255,255,255,0.35);font-size:14px;width:17px;text-align:center;}
.nav-item.active i{color:var(--cyan);}
.sidebar-logout{margin-top:auto;display:flex;align-items:center;gap:10px;padding:11px 14px;border-radius:10px;color:rgba(255,100,120,0.8);font-size:14px;font-weight:500;cursor:pointer;text-decoration:none;transition:background .2s;}
.sidebar-logout:hover{background:rgba(255,77,109,0.1);color:var(--red);}

/* MAIN */
.main{margin-left:var(--sidebar);flex:1;padding:32px 36px 60px;}
.topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px;flex-wrap:wrap;gap:14px;}
.topbar h2{font-family:'Syne',sans-serif;font-size:24px;font-weight:800;color:var(--navy);}
.topbar p{font-size:14px;color:#8a94a6;margin-top:2px;}
.btn-action{display:inline-flex;align-items:center;gap:7px;padding:11px 20px;border-radius:50px;font-family:'Syne',sans-serif;font-size:13px;font-weight:700;text-decoration:none;cursor:pointer;border:none;transition:transform .2s,box-shadow .2s;}
.btn-primary-action{background:linear-gradient(135deg,var(--blue),#3a7bff);color:white;box-shadow:0 4px 14px rgba(26,92,255,0.3);}
.btn-primary-action:hover{transform:translateY(-2px);box-shadow:0 8px 22px rgba(26,92,255,0.4);color:white;}

/* Stats */
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin-bottom:28px;}
.stat-card{background:var(--white);border-radius:18px;padding:20px;border:1.5px solid #edf0f8;display:flex;align-items:center;gap:16px;animation:fadeUp .4s ease both;}
.stat-icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;}
.ic-blue{background:#e8f0ff;}.ic-green{background:#e0fff5;}.ic-gold{background:#fff5e0;}.ic-cyan{background:#e0faff;}
.stat-num{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;color:var(--navy);}
.stat-lbl{font-size:12px;color:#8a94a6;}

/* Route Cards Grid */
.routes-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:20px;animation:fadeUp .4s .1s ease both;}
.route-card{background:var(--white);border-radius:18px;border:1.5px solid #edf0f8;overflow:hidden;transition:transform .2s,box-shadow .2s;}
.route-card:hover{transform:translateY(-4px);box-shadow:0 16px 40px rgba(11,31,58,0.1);}
.route-card-top{background:linear-gradient(135deg,var(--navy) 0%,#162d52 100%);padding:22px 22px 18px;position:relative;overflow:hidden;}
.route-card-top::before{content:'';position:absolute;inset:0;background-image:radial-gradient(circle,rgba(0,212,255,0.06) 1px,transparent 1px);background-size:20px 20px;}
.route-id-badge{position:absolute;top:14px;right:14px;background:rgba(255,255,255,0.1);color:rgba(255,255,255,0.5);font-size:11px;font-weight:700;padding:3px 10px;border-radius:50px;font-family:'Syne',sans-serif;}
.route-cities{display:flex;align-items:center;gap:10px;position:relative;z-index:1;}
.city-name{font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:white;}
.route-arrow{color:var(--cyan);font-size:16px;flex-shrink:0;}
.route-sub{font-size:12px;color:rgba(255,255,255,0.4);margin-top:6px;position:relative;z-index:1;display:flex;gap:14px;}
.route-sub span{display:flex;align-items:center;gap:5px;}
.route-sub i{color:var(--cyan);font-size:11px;}
.route-card-body{padding:16px 22px;}
.route-meta{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:4px;}
.meta-chip{display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:600;padding:5px 12px;border-radius:8px;background:var(--light);color:var(--navy);border:1px solid #dde4f2;}
.meta-chip i{color:var(--blue);font-size:11px;}
.meta-chip.green-chip{background:#e0fff5;color:var(--green);border-color:#b2f5e1;}
.route-card-footer{display:flex;align-items:center;justify-content:space-between;padding:12px 22px;border-top:1.5px solid #f0f4ff;}
.active-toggle{display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;color:#6b7a99;}
.toggle-switch{position:relative;display:inline-block;width:42px;height:22px;}
.toggle-switch input{opacity:0;width:0;height:0;}
.toggle-slider{position:absolute;cursor:pointer;inset:0;background:#dde4f2;border-radius:22px;transition:.3s;}
.toggle-slider::before{content:'';position:absolute;width:16px;height:16px;left:3px;bottom:3px;background:white;border-radius:50%;transition:.3s;}
input:checked + .toggle-slider{background:var(--green);}
input:checked + .toggle-slider::before{transform:translateX(20px);}
.card-action-btns{display:flex;gap:8px;}
.btn-sm{padding:7px 14px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;border:none;display:flex;align-items:center;gap:5px;transition:all .2s;}
.btn-edit{background:#e8f0ff;color:var(--blue);}
.btn-edit:hover{background:var(--blue);color:white;}
.btn-del{background:#fff0f3;color:var(--red);}
.btn-del:hover{background:var(--red);color:white;}

/* Empty */
.empty-state{text-align:center;padding:60px 20px;background:var(--white);border-radius:20px;border:1.5px solid #edf0f8;}
.empty-state .e-icon{font-size:56px;margin-bottom:14px;}
.empty-state h5{font-family:'Syne',sans-serif;font-size:20px;font-weight:700;color:var(--navy);margin-bottom:8px;}
.empty-state p{color:#8a94a6;font-size:14px;margin-bottom:22px;}

/* Toast */
.toast-msg{position:fixed;top:24px;right:24px;z-index:9999;color:white;font-family:'Syne',sans-serif;font-weight:700;font-size:14px;padding:14px 22px;border-radius:14px;display:flex;align-items:center;gap:10px;box-shadow:0 8px 28px rgba(0,0,0,0.18);animation:slideIn .4s ease both,fadeOut .4s 3s ease forwards;}
.toast-success{background:var(--green);}.toast-warn{background:var(--gold);}.toast-error{background:var(--red);}

/* Modal */
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(11,31,58,0.55);z-index:1000;align-items:center;justify-content:center;padding:20px;}
.modal-overlay.open{display:flex;}
.modal-box{background:white;border-radius:22px;padding:36px;width:100%;max-width:500px;box-shadow:0 24px 60px rgba(11,31,58,0.2);animation:fadeUp .3s ease both;}
.modal-box h4{font-family:'Syne',sans-serif;font-size:20px;font-weight:800;color:var(--navy);margin-bottom:22px;display:flex;align-items:center;gap:10px;}
.modal-box h4 i{color:var(--blue);}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.form-group{display:flex;flex-direction:column;gap:7px;}
.form-group.full{grid-column:1/-1;}
.form-group label{font-size:12px;font-weight:700;color:#6b7a99;text-transform:uppercase;letter-spacing:.7px;}
.form-group input{height:46px;border:2px solid #e8edf5;border-radius:10px;padding:0 14px;font-family:'DM Sans',sans-serif;font-size:14px;color:var(--navy);background:#f8faff;outline:none;transition:border-color .2s;}
.form-group input:focus{border-color:var(--blue);background:white;}
.modal-footer{display:flex;gap:12px;margin-top:24px;}
.btn-modal-submit{flex:1;padding:14px;border-radius:12px;font-family:'Syne',sans-serif;font-size:15px;font-weight:700;cursor:pointer;border:none;background:linear-gradient(135deg,var(--blue),#3a7bff);color:white;transition:all .2s;}
.btn-modal-submit:hover{transform:translateY(-2px);}
.btn-modal-cancel{padding:14px 22px;border-radius:12px;font-family:'Syne',sans-serif;font-size:15px;font-weight:700;cursor:pointer;background:var(--light);color:var(--navy);border:1.5px solid #dde4f2;}
.btn-modal-cancel:hover{border-color:var(--blue);color:var(--blue);}

/* Delete modal */
.del-modal{display:none;position:fixed;inset:0;background:rgba(11,31,58,0.55);z-index:1001;align-items:center;justify-content:center;}
.del-modal.open{display:flex;}
.del-box{background:white;border-radius:20px;padding:32px;max-width:400px;width:100%;margin:20px;box-shadow:0 24px 60px rgba(11,31,58,0.2);animation:fadeUp .3s ease both;text-align:center;}
.del-box h4{font-family:'Syne',sans-serif;font-size:20px;font-weight:800;color:var(--navy);margin-bottom:8px;}
.del-box p{color:#6b7a99;font-size:14px;margin-bottom:24px;}
.del-btns{display:flex;gap:12px;}
.btn-del-confirm{flex:1;padding:13px;border-radius:12px;font-family:'Syne',sans-serif;font-size:14px;font-weight:700;cursor:pointer;border:none;background:var(--red);color:white;}
.btn-del-cancel{flex:1;padding:13px;border-radius:12px;font-family:'Syne',sans-serif;font-size:14px;font-weight:700;cursor:pointer;background:var(--light);color:var(--navy);border:1.5px solid #dde4f2;}

@keyframes slideIn{from{opacity:0;transform:translateX(40px);}to{opacity:1;transform:translateX(0);}}
@keyframes fadeOut{to{opacity:0;transform:translateX(40px);}}
@keyframes fadeUp{from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:translateY(0);}}
@media(max-width:768px){.sidebar{display:none;}.main{margin-left:0;padding:20px 16px 60px;}.stats-row{grid-template-columns:1fr 1fr;}.form-grid{grid-template-columns:1fr;}.routes-grid{grid-template-columns:1fr;}}
</style>
</head>
<body>
<div style="display:flex;min-height:100vh;">

<!-- SIDEBAR -->
<aside class="sidebar">
    <a href="admin-dashboard.php" class="sidebar-brand"><div class="b-icon">🚌</div>E<span>Trans</span></a>
    <div class="admin-badge"><i class="fas fa-shield-halved"></i> ADMIN PANEL</div>
    <div class="nav-section">Main</div>
    <a class="nav-item" href="admin-dashboard.php"><i class="fas fa-gauge-high"></i> Dashboard</a>
    <a class="nav-item" href="manage-bookings.php"><i class="fas fa-ticket"></i> Bookings</a>
    <a class="nav-item" href="manage-buses.php"><i class="fas fa-bus"></i> Buses</a>
    <a class="nav-item active" href="manage-routes.php"><i class="fas fa-route"></i> Routes</a>
    <div class="nav-section">Users</div>
    <a class="nav-item" href="#"><i class="fas fa-users"></i> All Users</a>
    <div class="nav-section">System</div>
    <a class="nav-item" href="#"><i class="fas fa-chart-line"></i> Reports</a>
    <a class="nav-item" href="#"><i class="fas fa-gear"></i> Settings</a>
    <a class="sidebar-logout" href="../auth/logout.php"><i class="fas fa-right-from-bracket"></i> Logout</a>
</aside>

<!-- MAIN -->
<main class="main">

    <?php if($toast): ?>
    <div class="toast-msg toast-<?php echo $toast_type; ?>">
        <i class="fas fa-<?php echo $toast_type==='success'?'circle-check':($toast_type==='error'?'circle-exclamation':'triangle-exclamation'); ?>"></i>
        <?php echo htmlspecialchars($toast); ?>
    </div>
    <?php endif; ?>

    <!-- Topbar -->
    <div class="topbar">
        <div>
            <h2>Manage Routes 🗺️</h2>
            <p>Add, edit and manage all bus routes</p>
        </div>
        <button class="btn-action btn-primary-action" onclick="openAdd()">
            <i class="fas fa-plus"></i> Add New Route
        </button>
    </div>

    <!-- Stats -->
    <div class="stats-row">
        <div class="stat-card" style="animation-delay:.0s">
            <div class="stat-icon ic-blue">🗺️</div>
            <div><div class="stat-num"><?php echo $total_routes; ?></div><div class="stat-lbl">Total Routes</div></div>
        </div>
        <div class="stat-card" style="animation-delay:.07s">
            <div class="stat-icon ic-green">✅</div>
            <div><div class="stat-num"><?php echo $active_routes; ?></div><div class="stat-lbl">Active</div></div>
        </div>
        <div class="stat-card" style="animation-delay:.14s">
            <div class="stat-icon ic-gold">💤</div>
            <div><div class="stat-num"><?php echo $total_routes - $active_routes; ?></div><div class="stat-lbl">Inactive</div></div>
        </div>
        <div class="stat-card" style="animation-delay:.21s">
            <div class="stat-icon ic-cyan">🚌</div>
            <div><div class="stat-num"><?php echo $total_buses_on_routes; ?></div><div class="stat-lbl">Total Buses</div></div>
        </div>
    </div>

    <!-- Routes Grid -->
    <?php if($routes && $routes->num_rows > 0): ?>
    <div class="routes-grid">
    <?php while($r = $routes->fetch_assoc()): ?>
    <div class="route-card">
        <div class="route-card-top">
            <div class="route-id-badge">#<?php echo str_pad($r['id'],3,'0',STR_PAD_LEFT); ?></div>
            <div class="route-cities">
                <span class="city-name"><?php echo htmlspecialchars($r['source']); ?></span>
                <i class="fas fa-arrow-right route-arrow"></i>
                <span class="city-name"><?php echo htmlspecialchars($r['destination']); ?></span>
            </div>
            <div class="route-sub">
                <?php if($r['distance_km']): ?><span><i class="fas fa-road"></i> <?php echo $r['distance_km']; ?> km</span><?php endif; ?>
                <?php if($r['duration']): ?><span><i class="fas fa-clock"></i> <?php echo htmlspecialchars($r['duration']); ?></span><?php endif; ?>
            </div>
        </div>
        <div class="route-card-body">
            <div class="route-meta">
                <span class="meta-chip"><i class="fas fa-bus"></i> <?php echo $r['bus_count']; ?> bus<?php echo $r['bus_count']!=1?'es':''; ?></span>
                <span class="meta-chip <?php echo $r['booking_count']>0?'green-chip':''; ?>">
                    <i class="fas fa-ticket"></i> <?php echo $r['booking_count']; ?> booking<?php echo $r['booking_count']!=1?'s':''; ?>
                </span>
                <?php if($r['base_fare']): ?>
                <span class="meta-chip"><i class="fas fa-indian-rupee-sign"></i> From ₹<?php echo number_format($r['base_fare']); ?></span>
                <?php endif; ?>
            </div>
        </div>
        <div class="route-card-footer">
            <div class="active-toggle">
                <form method="POST" style="display:inline-flex;align-items:center;gap:8px;">
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="route_id" value="<?php echo $r['id']; ?>">
                    <input type="hidden" name="current_active" value="<?php echo $r['is_active']; ?>">
                    <label class="toggle-switch">
                        <input type="checkbox" <?php echo $r['is_active']?'checked':''; ?> onchange="this.form.submit()">
                        <span class="toggle-slider"></span>
                    </label>
                    <span><?php echo $r['is_active']?'Active':'Inactive'; ?></span>
                </form>
            </div>
            <div class="card-action-btns">
                <button class="btn-sm btn-edit" onclick='openEdit(<?php echo json_encode($r); ?>)'>
                    <i class="fas fa-pen"></i> Edit
                </button>
                <button class="btn-sm btn-del" onclick="openDelete(<?php echo $r['id']; ?>, '<?php echo addslashes($r['source'].' → '.$r['destination']); ?>')">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    </div>
    <?php endwhile; ?>
    </div>

    <?php else: ?>
    <div class="empty-state">
        <div class="e-icon">🗺️</div>
        <h5>No Routes Yet</h5>
        <p>Add your first route to get started.</p>
        <button class="btn-action btn-primary-action" onclick="openAdd()" style="margin:auto;">
            <i class="fas fa-plus"></i> Add First Route
        </button>
    </div>
    <?php endif; ?>

</main>
</div>

<!-- ADD / EDIT MODAL -->
<div class="modal-overlay" id="routeModal">
<div class="modal-box">
    <h4><i class="fas fa-route"></i> <span id="modalTitle">Add New Route</span></h4>
    <form method="POST" id="routeForm">
        <input type="hidden" name="action" id="formAction" value="add">
        <input type="hidden" name="route_id" id="fieldRouteId">
        <div class="form-grid">
            <div class="form-group">
                <label>Source City *</label>
                <input type="text" name="source" id="fieldSource" placeholder="e.g. Chennai" required>
            </div>
            <div class="form-group">
                <label>Destination City *</label>
                <input type="text" name="destination" id="fieldDestination" placeholder="e.g. Bangalore" required>
            </div>
            <div class="form-group">
                <label>Distance (km)</label>
                <input type="number" name="distance" id="fieldDistance" placeholder="350" min="1">
            </div>
            <div class="form-group">
                <label>Duration</label>
                <input type="text" name="duration" id="fieldDuration" placeholder="e.g. 6h 30m">
            </div>
            <div class="form-group full">
                <label>Base Fare (₹)</label>
                <input type="number" name="base_fare" id="fieldFare" placeholder="500" min="1" step="0.01">
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn-modal-submit" id="submitBtn">
                <i class="fas fa-plus"></i> Add Route
            </button>
            <button type="button" class="btn-modal-cancel" onclick="closeModal()">Cancel</button>
        </div>
    </form>
</div>
</div>

<!-- DELETE MODAL -->
<div class="del-modal" id="delModal">
<div class="del-box">
    <div style="font-size:48px;margin-bottom:14px;">🗺️</div>
    <h4>Delete Route?</h4>
    <p id="delMsg">This cannot be undone.</p>
    <div class="del-btns">
        <form method="POST" style="flex:1;">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="route_id" id="delRouteId">
            <button type="submit" class="btn-del-confirm" style="width:100%;">
                <i class="fas fa-trash"></i> Delete
            </button>
        </form>
        <button class="btn-del-cancel" onclick="closeDelete()">Cancel</button>
    </div>
</div>
</div>

<script>
function openAdd() {
    document.getElementById('modalTitle').textContent = 'Add New Route';
    document.getElementById('formAction').value = 'add';
    document.getElementById('submitBtn').innerHTML = '<i class="fas fa-plus"></i> Add Route';
    document.getElementById('routeForm').reset();
    document.getElementById('routeModal').classList.add('open');
}
function openEdit(r) {
    document.getElementById('modalTitle').textContent = 'Edit Route';
    document.getElementById('formAction').value = 'edit';
    document.getElementById('submitBtn').innerHTML = '<i class="fas fa-save"></i> Save Changes';
    document.getElementById('fieldRouteId').value    = r.id;
    document.getElementById('fieldSource').value    = r.source;
    document.getElementById('fieldDestination').value = r.destination;
    document.getElementById('fieldDistance').value  = r.distance_km || '';
    document.getElementById('fieldDuration').value  = r.duration || '';
    document.getElementById('fieldFare').value      = r.base_fare || '';
    document.getElementById('routeModal').classList.add('open');
}
function closeModal() { document.getElementById('routeModal').classList.remove('open'); }
function openDelete(id, name) {
    document.getElementById('delRouteId').value = id;
    document.getElementById('delMsg').textContent = `Delete "${name}"? Buses on this route must be reassigned first.`;
    document.getElementById('delModal').classList.add('open');
}
function closeDelete() { document.getElementById('delModal').classList.remove('open'); }
document.getElementById('routeModal').addEventListener('click', e => { if(e.target===document.getElementById('routeModal')) closeModal(); });
document.getElementById('delModal').addEventListener('click',   e => { if(e.target===document.getElementById('delModal'))   closeDelete(); });
</script>
</body>
</html>