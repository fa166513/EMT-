<?php
session_start();
include("../config/config.php");

// Admin auth check
if(!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

$admin_name = $_SESSION['user'] ?? 'Admin';

// ── HANDLE STATUS UPDATE ──
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $bid    = (int)($_POST['booking_id'] ?? 0);
    $action = $_POST['action'];

    if($action === 'cancel') {
        $conn->query("UPDATE bookings SET booking_status='cancelled', payment_status='refunded' WHERE id=$bid");
        $toast = 'Booking cancelled successfully.';
        $toast_type = 'warn';
    } elseif($action === 'confirm_pay') {
        $conn->query("UPDATE bookings SET payment_status='paid' WHERE id=$bid");
        $toast = 'Payment marked as paid.';
        $toast_type = 'success';
    }
}

// ── FILTERS ──
$filter_status  = $_GET['status']  ?? 'all';
$filter_payment = $_GET['payment'] ?? 'all';
$search         = trim($_GET['search'] ?? '');

$where = "WHERE 1=1";
if($filter_status  !== 'all') $where .= " AND b.booking_status  = '$filter_status'";
if($filter_payment !== 'all') $where .= " AND b.payment_status  = '$filter_payment'";
if($search) $where .= " AND (b.booking_code LIKE '%$search%' OR u.name LIKE '%$search%' OR u.email LIKE '%$search%')";

// ── STATS ──
$total_bookings  = $conn->query("SELECT COUNT(*) as t FROM bookings")->fetch_assoc()['t'];
$paid_bookings   = $conn->query("SELECT COUNT(*) as t FROM bookings WHERE payment_status='paid'")->fetch_assoc()['t'];
$pending_bookings= $conn->query("SELECT COUNT(*) as t FROM bookings WHERE payment_status='pending'")->fetch_assoc()['t'];
$total_revenue   = $conn->query("SELECT COALESCE(SUM(total_amount),0) as t FROM bookings WHERE payment_status='paid'")->fetch_assoc()['t'];

// ── BOOKINGS QUERY ──
$bookings = $conn->query("
    SELECT b.*, u.name AS user_name, u.email AS user_email, u.phone AS user_phone,
           bs.bus_name, bs.bus_type, r.source, r.destination
    FROM bookings b
    JOIN users  u  ON b.user_id  = u.id
    JOIN buses  bs ON b.bus_id   = bs.id
    JOIN routes r  ON b.route_id = r.id
    $where
    ORDER BY b.booked_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manage Bookings — ETrans Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root {
    --navy:#0b1f3a; --blue:#1a5cff; --cyan:#00d4ff;
    --green:#00c48c; --gold:#f5a623; --red:#ff4d6d;
    --light:#f0f4ff; --white:#ffffff; --sidebar:260px;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--light);display:flex;min-height:100vh;}

/* ── SIDEBAR (same as dashboard) ── */
.sidebar{width:var(--sidebar);background:var(--navy);display:flex;flex-direction:column;padding:28px 16px;position:fixed;top:0;left:0;height:100vh;overflow-y:auto;z-index:100;}
.sidebar-brand{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;color:white;padding:0 10px;margin-bottom:8px;text-decoration:none;display:flex;align-items:center;gap:8px;}
.sidebar-brand span{color:var(--cyan);}
.sidebar-brand .b-icon{width:34px;height:34px;background:linear-gradient(135deg,var(--blue),var(--cyan));border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px;}
.admin-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(255,77,109,0.15);border:1px solid rgba(255,77,109,0.3);color:#ff8fa3;font-size:11px;font-weight:700;padding:3px 10px;border-radius:50px;margin:6px 10px 20px;letter-spacing:.5px;}
.nav-section{font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:rgba(255,255,255,0.28);padding:12px 12px 6px;}
.nav-item{display:flex;align-items:center;gap:11px;padding:11px 14px;border-radius:10px;color:rgba(255,255,255,0.6);font-size:14px;font-weight:500;text-decoration:none;transition:all .2s;margin-bottom:2px;}
.nav-item:hover{background:rgba(255,255,255,0.07);color:white;}
.nav-item.active{background:rgba(26,92,255,0.25);border:1px solid rgba(26,92,255,0.35);color:white;}
.nav-item.active i{color:var(--cyan);}
.nav-item i{width:17px;text-align:center;color:rgba(255,255,255,0.35);font-size:14px;}
.badge-count{margin-left:auto;background:var(--red);color:white;font-size:10px;font-weight:700;padding:2px 7px;border-radius:50px;}
.sidebar-logout{margin-top:auto;display:flex;align-items:center;gap:10px;padding:11px 14px;border-radius:10px;color:rgba(255,100,120,0.8);font-size:14px;font-weight:500;cursor:pointer;text-decoration:none;transition:background .2s;}
.sidebar-logout:hover{background:rgba(255,77,109,0.1);color:var(--red);}

/* ── MAIN ── */
.main{margin-left:var(--sidebar);flex:1;padding:32px 36px 60px;}

.topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px;flex-wrap:wrap;gap:14px;}
.topbar h2{font-family:'Syne',sans-serif;font-size:24px;font-weight:800;color:var(--navy);}
.topbar p{font-size:14px;color:#8a94a6;margin-top:2px;}

/* Stats */
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin-bottom:28px;}
.stat-card{background:var(--white);border-radius:18px;padding:20px;border:1.5px solid #edf0f8;display:flex;align-items:center;gap:16px;}
.stat-icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;}
.ic-blue{background:#e8f0ff;} .ic-green{background:#e0fff5;} .ic-gold{background:#fff5e0;} .ic-red{background:#fff0f3;}
.stat-num{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;color:var(--navy);}
.stat-lbl{font-size:12px;color:#8a94a6;}

/* Filters */
.filter-bar{background:var(--white);border-radius:16px;border:1.5px solid #edf0f8;padding:16px 20px;display:flex;align-items:center;gap:12px;margin-bottom:20px;flex-wrap:wrap;}
.search-wrap{position:relative;flex:1;min-width:220px;}
.search-wrap i{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#a0aabf;font-size:14px;}
.search-wrap input{width:100%;height:42px;border:2px solid #e8edf5;border-radius:10px;padding:0 14px 0 40px;font-family:'DM Sans',sans-serif;font-size:14px;color:var(--navy);background:#f8faff;outline:none;transition:border-color .2s;}
.search-wrap input:focus{border-color:var(--blue);background:var(--white);}
.filter-select{height:42px;border:2px solid #e8edf5;border-radius:10px;padding:0 14px;font-family:'DM Sans',sans-serif;font-size:14px;color:var(--navy);background:#f8faff;outline:none;cursor:pointer;}
.filter-select:focus{border-color:var(--blue);}
.btn-filter{height:42px;padding:0 20px;background:var(--blue);color:white;border:none;border-radius:10px;font-family:'Syne',sans-serif;font-size:13px;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:7px;}
.btn-filter:hover{background:#1248d4;}
.btn-reset{height:42px;padding:0 16px;background:var(--white);color:#6b7a99;border:1.5px solid #dde4f2;border-radius:10px;font-size:13px;font-weight:600;cursor:pointer;text-decoration:none;display:flex;align-items:center;gap:7px;}
.btn-reset:hover{border-color:var(--blue);color:var(--blue);}

/* Table card */
.table-card{background:var(--white);border-radius:20px;border:1.5px solid #edf0f8;overflow:hidden;}
.table-head-bar{padding:16px 22px;border-bottom:1.5px solid #f0f4ff;display:flex;align-items:center;justify-content:space-between;}
.table-head-bar h5{font-family:'Syne',sans-serif;font-size:16px;font-weight:700;color:var(--navy);margin:0;display:flex;align-items:center;gap:8px;}
.table-head-bar h5 i{color:var(--blue);}
.result-count{font-size:13px;color:#8a94a6;}

.admin-table{width:100%;border-collapse:collapse;}
.admin-table th{background:#f8faff;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#8a94a6;padding:12px 18px;border-bottom:1.5px solid #f0f4ff;text-align:left;white-space:nowrap;}
.admin-table td{padding:14px 18px;border-bottom:1.5px solid #f8faff;font-size:13px;color:var(--navy);vertical-align:middle;}
.admin-table tr:last-child td{border-bottom:none;}
.admin-table tr:hover td{background:#fafbff;}

.code-cell{font-family:'Syne',sans-serif;font-size:13px;font-weight:700;color:var(--blue);}
.user-cell .user-name{font-weight:600;font-size:13px;}
.user-cell .user-email{font-size:11px;color:#8a94a6;margin-top:2px;}
.route-cell .route-name{font-weight:600;font-size:13px;}
.route-cell .route-bus{font-size:11px;color:#8a94a6;margin-top:2px;}
.seat-chips{display:flex;gap:4px;flex-wrap:wrap;}
.seat-chip{background:#e8f0ff;color:var(--blue);font-size:11px;font-weight:700;padding:3px 8px;border-radius:6px;}

.status-pill{display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:700;padding:4px 10px;border-radius:50px;}
.sp-paid{background:#e0fff5;color:var(--green);}
.sp-pending{background:#fff5e0;color:var(--gold);}
.sp-confirmed{background:#e8f0ff;color:var(--blue);}
.sp-cancelled{background:#fff0f3;color:var(--red);}
.sp-refunded{background:#f5f5f5;color:#8a94a6;}

/* Action buttons */
.action-btns{display:flex;gap:6px;}
.btn-sm-action{padding:6px 12px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;border:none;display:flex;align-items:center;gap:5px;transition:all .2s;white-space:nowrap;}
.btn-pay{background:#e0fff5;color:var(--green);}
.btn-pay:hover{background:var(--green);color:white;}
.btn-cancel{background:#fff0f3;color:var(--red);}
.btn-cancel:hover{background:var(--red);color:white;}
.btn-view{background:var(--light);color:var(--blue);border:1.5px solid #d0deff;}
.btn-view:hover{background:var(--blue);color:white;}

/* Empty */
.empty-state{text-align:center;padding:50px 20px;}
.empty-state .e-icon{font-size:52px;margin-bottom:14px;}
.empty-state h5{font-family:'Syne',sans-serif;font-size:18px;font-weight:700;color:var(--navy);margin-bottom:8px;}
.empty-state p{color:#8a94a6;font-size:14px;}

/* Toast */
.toast-msg{position:fixed;top:24px;right:24px;z-index:9999;color:white;font-family:'Syne',sans-serif;font-weight:700;font-size:14px;padding:14px 22px;border-radius:14px;display:flex;align-items:center;gap:10px;box-shadow:0 8px 28px rgba(0,0,0,0.18);animation:slideIn .4s ease both,fadeOut .4s 3s ease forwards;}
.toast-success{background:var(--green);}
.toast-warn{background:var(--gold);}

@keyframes slideIn{from{opacity:0;transform:translateX(40px);}to{opacity:1;transform:translateX(0);}}
@keyframes fadeOut{to{opacity:0;transform:translateX(40px);}}
@keyframes fadeUp{from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:translateY(0);}}

/* Modal */
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(11,31,58,0.5);z-index:1000;align-items:center;justify-content:center;}
.modal-overlay.open{display:flex;}
.modal-box{background:white;border-radius:20px;padding:32px;max-width:440px;width:100%;margin:20px;box-shadow:0 24px 60px rgba(11,31,58,0.2);animation:fadeUp .3s ease both;}
.modal-box h4{font-family:'Syne',sans-serif;font-size:20px;font-weight:800;color:var(--navy);margin-bottom:8px;}
.modal-box p{color:#6b7a99;font-size:14px;margin-bottom:24px;}
.modal-btns{display:flex;gap:12px;}
.modal-btn{flex:1;padding:13px;border-radius:12px;font-family:'Syne',sans-serif;font-size:14px;font-weight:700;cursor:pointer;border:none;transition:all .2s;}
.modal-confirm{background:var(--red);color:white;}
.modal-confirm:hover{background:#e0003a;}
.modal-cancel-btn{background:var(--light);color:var(--navy);border:1.5px solid #dde4f2;}
.modal-cancel-btn:hover{border-color:var(--blue);color:var(--blue);}

@media(max-width:768px){.sidebar{display:none;}.main{margin-left:0;padding:20px 16px 60px;}.stats-row{grid-template-columns:1fr 1fr;}}
</style>
</head>
<body>
<div style="display:flex;min-height:100vh;">

<!-- SIDEBAR -->
<aside class="sidebar">
    <a href="admin-dashboard.php" class="sidebar-brand">
        <div class="b-icon">🚌</div>E<span>Trans</span>
    </a>
    <div class="admin-badge"><i class="fas fa-shield-halved"></i> ADMIN PANEL</div>
    <div class="nav-section">Main</div>
    <a class="nav-item" href="admin-dashboard.php"><i class="fas fa-gauge-high"></i> Dashboard</a>
    <a class="nav-item active" href="manage-bookings.php"><i class="fas fa-ticket"></i> Bookings</a>
    <a class="nav-item" href="manage-buses.php"><i class="fas fa-bus"></i> Buses</a>
    <a class="nav-item" href="manage-routes.php"><i class="fas fa-route"></i> Routes</a>
    <div class="nav-section">Users</div>
    <a class="nav-item" href="#"><i class="fas fa-users"></i> All Users</a>
    <div class="nav-section">System</div>
    <a class="nav-item" href="#"><i class="fas fa-chart-line"></i> Reports</a>
    <a class="nav-item" href="#"><i class="fas fa-gear"></i> Settings</a>
    <a class="sidebar-logout" href="../auth/logout.php"><i class="fas fa-right-from-bracket"></i> Logout</a>
</aside>

<!-- MAIN -->
<main class="main">

    <?php if(isset($toast)): ?>
    <div class="toast-msg toast-<?php echo $toast_type; ?>">
        <i class="fas fa-circle-check"></i> <?php echo htmlspecialchars($toast); ?>
    </div>
    <?php endif; ?>

    <!-- Topbar -->
    <div class="topbar">
        <div>
            <h2>Manage Bookings 🎫</h2>
            <p>View, filter and manage all passenger bookings</p>
        </div>
    </div>

    <!-- Stats -->
    <div class="stats-row" style="animation:fadeUp .4s ease both;">
        <div class="stat-card">
            <div class="stat-icon ic-blue">🎫</div>
            <div><div class="stat-num"><?php echo $total_bookings; ?></div><div class="stat-lbl">Total Bookings</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon ic-green">✅</div>
            <div><div class="stat-num"><?php echo $paid_bookings; ?></div><div class="stat-lbl">Paid</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon ic-gold">⏳</div>
            <div><div class="stat-num"><?php echo $pending_bookings; ?></div><div class="stat-lbl">Pending</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon ic-green">💰</div>
            <div><div class="stat-num">₹<?php echo number_format($total_revenue); ?></div><div class="stat-lbl">Revenue</div></div>
        </div>
    </div>

    <!-- Filters -->
    <form method="GET" action="">
        <div class="filter-bar">
            <div class="search-wrap">
                <i class="fas fa-search"></i>
                <input type="text" name="search" placeholder="Search by booking ID, name or email..."
                       value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <select name="status" class="filter-select">
                <option value="all"       <?php echo $filter_status==='all'       ?'selected':''; ?>>All Status</option>
                <option value="confirmed" <?php echo $filter_status==='confirmed' ?'selected':''; ?>>Confirmed</option>
                <option value="cancelled" <?php echo $filter_status==='cancelled' ?'selected':''; ?>>Cancelled</option>
                <option value="completed" <?php echo $filter_status==='completed' ?'selected':''; ?>>Completed</option>
            </select>
            <select name="payment" class="filter-select">
                <option value="all"      <?php echo $filter_payment==='all'     ?'selected':''; ?>>All Payments</option>
                <option value="paid"     <?php echo $filter_payment==='paid'    ?'selected':''; ?>>Paid</option>
                <option value="pending"  <?php echo $filter_payment==='pending' ?'selected':''; ?>>Pending</option>
                <option value="refunded" <?php echo $filter_payment==='refunded'?'selected':''; ?>>Refunded</option>
            </select>
            <button type="submit" class="btn-filter"><i class="fas fa-filter"></i> Filter</button>
            <a href="manage-bookings.php" class="btn-reset"><i class="fas fa-rotate"></i> Reset</a>
        </div>
    </form>

    <!-- Table -->
    <div class="table-card" style="animation:fadeUp .4s .1s ease both;">
        <div class="table-head-bar">
            <h5><i class="fas fa-list"></i> All Bookings</h5>
            <span class="result-count"><?php echo $bookings ? $bookings->num_rows : 0; ?> results</span>
        </div>

        <?php if($bookings && $bookings->num_rows > 0): ?>
        <div style="overflow-x:auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Booking ID</th>
                    <th>Passenger</th>
                    <th>Route / Bus</th>
                    <th>Date</th>
                    <th>Seats</th>
                    <th>Amount</th>
                    <th>Payment</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php while($b = $bookings->fetch_assoc()):
                $pay_class = match($b['payment_status']) {
                    'paid'     => 'sp-paid',
                    'pending'  => 'sp-pending',
                    'refunded' => 'sp-refunded',
                    default    => 'sp-cancelled',
                };
                $bk_class = match($b['booking_status']) {
                    'confirmed' => 'sp-confirmed',
                    'cancelled' => 'sp-cancelled',
                    'completed' => 'sp-paid',
                    default     => 'sp-pending',
                };
                $seats = explode(',', $b['seats']);
            ?>
            <tr>
                <td><span class="code-cell"><?php echo $b['booking_code']; ?></span></td>
                <td class="user-cell">
                    <div class="user-name"><?php echo htmlspecialchars($b['user_name']); ?></div>
                    <div class="user-email"><?php echo htmlspecialchars($b['user_email']); ?></div>
                </td>
                <td class="route-cell">
                    <div class="route-name"><?php echo htmlspecialchars($b['source']); ?> → <?php echo htmlspecialchars($b['destination']); ?></div>
                    <div class="route-bus"><?php echo htmlspecialchars($b['bus_name']); ?></div>
                </td>
                <td><?php echo date("d M Y", strtotime($b['travel_date'])); ?></td>
                <td>
                    <div class="seat-chips">
                        <?php foreach($seats as $s): ?>
                        <span class="seat-chip"><?php echo trim($s); ?></span>
                        <?php endforeach; ?>
                    </div>
                </td>
                <td><strong>₹<?php echo number_format($b['total_amount']); ?></strong></td>
                <td><span class="status-pill <?php echo $pay_class; ?>"><?php echo ucfirst($b['payment_status']); ?></span></td>
                <td><span class="status-pill <?php echo $bk_class; ?>"><?php echo ucfirst($b['booking_status']); ?></span></td>
                <td>
                    <div class="action-btns">
                        <?php if($b['payment_status'] === 'pending'): ?>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="booking_id" value="<?php echo $b['id']; ?>">
                            <input type="hidden" name="action" value="confirm_pay">
                            <button type="submit" class="btn-sm-action btn-pay">
                                <i class="fas fa-check"></i> Pay
                            </button>
                        </form>
                        <?php endif; ?>
                        <?php if($b['booking_status'] === 'confirmed'): ?>
                        <button class="btn-sm-action btn-cancel"
                                onclick="openCancel(<?php echo $b['id']; ?>, '<?php echo $b['booking_code']; ?>')">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
        </div>

        <?php else: ?>
        <div class="empty-state">
            <div class="e-icon">🎫</div>
            <h5>No Bookings Found</h5>
            <p>No bookings match your current filters.</p>
        </div>
        <?php endif; ?>
    </div>

</main>
</div>

<!-- Cancel Confirmation Modal -->
<div class="modal-overlay" id="cancelModal">
    <div class="modal-box">
        <h4>⚠️ Cancel Booking?</h4>
        <p id="modalMsg">Are you sure you want to cancel this booking? This will mark the payment as refunded.</p>
        <div class="modal-btns">
            <form method="POST" style="flex:1;">
                <input type="hidden" name="booking_id" id="cancelId">
                <input type="hidden" name="action" value="cancel">
                <button type="submit" class="modal-btn modal-confirm" style="width:100%;">
                    <i class="fas fa-times"></i> Yes, Cancel
                </button>
            </form>
            <button class="modal-btn modal-cancel-btn" onclick="closeCancel()">Keep Booking</button>
        </div>
    </div>
</div>

<script>
function openCancel(id, code) {
    document.getElementById('cancelId').value = id;
    document.getElementById('modalMsg').textContent = `Cancel booking ${code}? Payment will be marked as refunded.`;
    document.getElementById('cancelModal').classList.add('open');
}
function closeCancel() {
    document.getElementById('cancelModal').classList.remove('open');
}
document.getElementById('cancelModal').addEventListener('click', function(e) {
    if(e.target === this) closeCancel();
});
</script>
</body>
</html>