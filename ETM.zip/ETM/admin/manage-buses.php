<?php
session_start();
include("../config/config.php");

// Admin auth check
if(!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

$admin_name = $_SESSION['user'] ?? 'Admin';
$toast = $toast_type = '';

// ── HANDLE ACTIONS ──
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ADD BUS
    if($action === 'add') {
        $bus_name  = trim($_POST['bus_name']);
        $bus_num   = trim($_POST['bus_number']);
        $bus_type  = $_POST['bus_type'];
        $route_id  = (int)$_POST['route_id'];
        $dep       = $_POST['departure_time'];
        $arr       = $_POST['arrival_time'];
        $price     = (float)$_POST['price'];
        $seats     = (int)$_POST['total_seats'];
        $amenities = implode(',', $_POST['amenities'] ?? []);

        $stmt = $conn->prepare("INSERT INTO buses (bus_name, bus_number, bus_type, route_id, departure_time, arrival_time, price, total_seats, amenities) VALUES (?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("sssissdis", $bus_name, $bus_num, $bus_type, $route_id, $dep, $arr, $price, $seats, $amenities);
        if($stmt->execute()) { $toast = 'Bus added successfully!'; $toast_type = 'success'; }
        else { $toast = 'Error adding bus.'; $toast_type = 'error'; }
        $stmt->close();

    // EDIT BUS
    } elseif($action === 'edit') {
        $id        = (int)$_POST['bus_id'];
        $bus_name  = trim($_POST['bus_name']);
        $bus_num   = trim($_POST['bus_number']);
        $bus_type  = $_POST['bus_type'];
        $route_id  = (int)$_POST['route_id'];
        $dep       = $_POST['departure_time'];
        $arr       = $_POST['arrival_time'];
        $price     = (float)$_POST['price'];
        $seats     = (int)$_POST['total_seats'];
        $amenities = implode(',', $_POST['amenities'] ?? []);

        $stmt = $conn->prepare("UPDATE buses SET bus_name=?, bus_number=?, bus_type=?, route_id=?, departure_time=?, arrival_time=?, price=?, total_seats=?, amenities=? WHERE id=?");
        $stmt->bind_param("sssissdisi", $bus_name, $bus_num, $bus_type, $route_id, $dep, $arr, $price, $seats, $amenities, $id);
        if($stmt->execute()) { $toast = 'Bus updated successfully!'; $toast_type = 'success'; }
        else { $toast = 'Error updating bus.'; $toast_type = 'error'; }
        $stmt->close();

    // DELETE BUS
    } elseif($action === 'delete') {
        $id = (int)$_POST['bus_id'];
        $conn->query("DELETE FROM buses WHERE id=$id");
        $toast = 'Bus deleted.'; $toast_type = 'warn';

    // TOGGLE ACTIVE
    } elseif($action === 'toggle') {
        $id  = (int)$_POST['bus_id'];
        $val = (int)$_POST['current_active'] === 1 ? 0 : 1;
        $conn->query("UPDATE buses SET is_active=$val WHERE id=$id");
        $toast = $val ? 'Bus activated.' : 'Bus deactivated.'; $toast_type = 'success';
    }
}

// ── FETCH DATA ──
$buses  = $conn->query("SELECT b.*, r.source, r.destination FROM buses b LEFT JOIN routes r ON b.route_id = r.id ORDER BY b.id DESC");
$routes = $conn->query("SELECT * FROM routes WHERE is_active=1 ORDER BY source");

$total_buses  = $conn->query("SELECT COUNT(*) as t FROM buses")->fetch_assoc()['t'];
$active_buses = $conn->query("SELECT COUNT(*) as t FROM buses WHERE is_active=1")->fetch_assoc()['t'];
$bus_types    = $conn->query("SELECT bus_type, COUNT(*) as c FROM buses GROUP BY bus_type");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manage Buses — ETrans Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root{--navy:#0b1f3a;--blue:#1a5cff;--cyan:#00d4ff;--green:#00c48c;--gold:#f5a623;--red:#ff4d6d;--light:#f0f4ff;--white:#ffffff;--sidebar:260px;}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--light);display:flex;min-height:100vh;}

/* SIDEBAR */
.sidebar{width:var(--sidebar);background:var(--navy);display:flex;flex-direction:column;padding:28px 16px;position:fixed;top:0;left:0;height:100vh;overflow-y:auto;z-index:100;}
.sidebar-brand{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;color:white;padding:0 10px;margin-bottom:8px;text-decoration:none;display:flex;align-items:center;gap:8px;}
.sidebar-brand span{color:var(--cyan);}
.sidebar-brand .b-icon{width:34px;height:34px;background:linear-gradient(135deg,var(--blue),var(--cyan));border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px;}
.admin-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(255,77,109,0.15);border:1px solid rgba(255,77,109,0.3);color:#ff8fa3;font-size:11px;font-weight:700;padding:3px 10px;border-radius:50px;margin:6px 10px 20px;}
.nav-section{font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:rgba(255,255,255,0.28);padding:12px 12px 6px;}
.nav-item{display:flex;align-items:center;gap:11px;padding:11px 14px;border-radius:10px;color:rgba(255,255,255,0.6);font-size:14px;font-weight:500;text-decoration:none;transition:all .2s;margin-bottom:2px;}
.nav-item:hover{background:rgba(255,255,255,0.07);color:white;}
.nav-item.active{background:rgba(26,92,255,0.25);border:1px solid rgba(26,92,255,0.35);color:white;}
.nav-item.active i,.nav-item i{color:rgba(255,255,255,0.35);font-size:14px;width:17px;text-align:center;}
.nav-item.active i{color:var(--cyan);}
.sidebar-logout{margin-top:auto;display:flex;align-items:center;gap:10px;padding:11px 14px;border-radius:10px;color:rgba(255,100,120,0.8);font-size:14px;font-weight:500;cursor:pointer;text-decoration:none;transition:background .2s;}
.sidebar-logout:hover{background:rgba(255,77,109,0.1);color:var(--red);}

/* MAIN */
.main{margin-left:var(--sidebar);flex:1;padding:32px 36px 60px;}
.topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px;flex-wrap:wrap;gap:14px;}
.topbar h2{font-family:'Syne',sans-serif;font-size:24px;font-weight:800;color:var(--navy);}
.topbar p{font-size:14px;color:#8a94a6;margin-top:2px;}

.btn-action{display:inline-flex;align-items:center;gap:7px;padding:11px 20px;border-radius:50px;font-family:'Syne',sans-serif;font-size:13px;font-weight:700;text-decoration:none;cursor:pointer;border:none;transition:transform .2s,box-shadow .2s;}
.btn-primary-action{background:linear-gradient(135deg,var(--blue),#3a7bff);color:white;box-shadow:0 4px 14px rgba(26,92,255,0.3);}
.btn-primary-action:hover{transform:translateY(-2px);box-shadow:0 8px 22px rgba(26,92,255,0.4);color:white;}

/* Stats */
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin-bottom:28px;}
.stat-card{background:var(--white);border-radius:18px;padding:20px;border:1.5px solid #edf0f8;display:flex;align-items:center;gap:16px;animation:fadeUp .4s ease both;}
.stat-icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;}
.ic-blue{background:#e8f0ff;}.ic-green{background:#e0fff5;}.ic-gold{background:#fff5e0;}.ic-purple{background:#f3e8ff;}
.stat-num{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;color:var(--navy);}
.stat-lbl{font-size:12px;color:#8a94a6;}

/* Table Card */
.table-card{background:var(--white);border-radius:20px;border:1.5px solid #edf0f8;overflow:hidden;animation:fadeUp .4s .1s ease both;}
.table-head-bar{padding:16px 22px;border-bottom:1.5px solid #f0f4ff;display:flex;align-items:center;justify-content:space-between;}
.table-head-bar h5{font-family:'Syne',sans-serif;font-size:16px;font-weight:700;color:var(--navy);margin:0;display:flex;align-items:center;gap:8px;}
.table-head-bar h5 i{color:var(--blue);}

.admin-table{width:100%;border-collapse:collapse;}
.admin-table th{background:#f8faff;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#8a94a6;padding:12px 18px;border-bottom:1.5px solid #f0f4ff;text-align:left;white-space:nowrap;}
.admin-table td{padding:13px 18px;border-bottom:1.5px solid #f8faff;font-size:13px;color:var(--navy);vertical-align:middle;}
.admin-table tr:last-child td{border-bottom:none;}
.admin-table tr:hover td{background:#fafbff;}

.bus-name-cell .bname{font-weight:700;font-size:14px;}
.bus-name-cell .bnum{font-size:11px;color:#8a94a6;margin-top:2px;}
.route-chip{background:#e8f0ff;color:var(--blue);font-size:12px;font-weight:600;padding:4px 12px;border-radius:8px;white-space:nowrap;}
.type-badge{display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:700;padding:4px 10px;border-radius:50px;}
.tb-ac{background:#e8f0ff;color:var(--blue);}
.tb-semi{background:#fff5e0;color:var(--gold);}
.tb-volvo{background:#e0fff5;color:var(--green);}
.tb-nonac{background:#f5f5f5;color:#6b7a99;}

.amenity-tag{display:inline-flex;align-items:center;gap:4px;font-size:11px;color:#6b7a99;background:var(--light);border:1px solid #dde4f2;padding:3px 8px;border-radius:50px;margin:2px;}
.amenity-tag i{color:var(--blue);font-size:10px;}

.toggle-switch{position:relative;display:inline-block;width:42px;height:22px;}
.toggle-switch input{opacity:0;width:0;height:0;}
.toggle-slider{position:absolute;cursor:pointer;inset:0;background:#dde4f2;border-radius:22px;transition:.3s;}
.toggle-slider::before{content:'';position:absolute;width:16px;height:16px;left:3px;bottom:3px;background:white;border-radius:50%;transition:.3s;}
input:checked + .toggle-slider{background:var(--green);}
input:checked + .toggle-slider::before{transform:translateX(20px);}

.action-btns{display:flex;gap:6px;}
.btn-sm{padding:7px 12px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;border:none;display:flex;align-items:center;gap:5px;transition:all .2s;white-space:nowrap;text-decoration:none;}
.btn-edit{background:#e8f0ff;color:var(--blue);}
.btn-edit:hover{background:var(--blue);color:white;}
.btn-del{background:#fff0f3;color:var(--red);}
.btn-del:hover{background:var(--red);color:white;}

/* Toast */
.toast-msg{position:fixed;top:24px;right:24px;z-index:9999;color:white;font-family:'Syne',sans-serif;font-weight:700;font-size:14px;padding:14px 22px;border-radius:14px;display:flex;align-items:center;gap:10px;box-shadow:0 8px 28px rgba(0,0,0,0.18);animation:slideIn .4s ease both,fadeOut .4s 3s ease forwards;}
.toast-success{background:var(--green);}.toast-warn{background:var(--gold);}.toast-error{background:var(--red);}

/* Modal */
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(11,31,58,0.55);z-index:1000;align-items:flex-start;justify-content:center;overflow-y:auto;padding:40px 20px;}
.modal-overlay.open{display:flex;}
.modal-box{background:white;border-radius:22px;padding:36px;width:100%;max-width:560px;box-shadow:0 24px 60px rgba(11,31,58,0.2);animation:fadeUp .3s ease both;margin:auto;}
.modal-box h4{font-family:'Syne',sans-serif;font-size:20px;font-weight:800;color:var(--navy);margin-bottom:20px;display:flex;align-items:center;gap:10px;}
.modal-box h4 i{color:var(--blue);}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.form-group{display:flex;flex-direction:column;gap:7px;}
.form-group.full{grid-column:1/-1;}
.form-group label{font-size:12px;font-weight:700;color:#6b7a99;text-transform:uppercase;letter-spacing:.7px;}
.form-group input,.form-group select{height:46px;border:2px solid #e8edf5;border-radius:10px;padding:0 14px;font-family:'DM Sans',sans-serif;font-size:14px;color:var(--navy);background:#f8faff;outline:none;transition:border-color .2s;}
.form-group input:focus,.form-group select:focus{border-color:var(--blue);background:white;}
.amenities-wrap{display:flex;flex-wrap:wrap;gap:10px;margin-top:4px;}
.amenity-check{display:flex;align-items:center;gap:6px;font-size:13px;color:var(--navy);cursor:pointer;}
.amenity-check input{accent-color:var(--blue);width:15px;height:15px;}
.modal-footer{display:flex;gap:12px;margin-top:24px;}
.btn-modal-submit{flex:1;padding:14px;border-radius:12px;font-family:'Syne',sans-serif;font-size:15px;font-weight:700;cursor:pointer;border:none;background:linear-gradient(135deg,var(--blue),#3a7bff);color:white;transition:all .2s;}
.btn-modal-submit:hover{transform:translateY(-2px);}
.btn-modal-cancel{padding:14px 22px;border-radius:12px;font-family:'Syne',sans-serif;font-size:15px;font-weight:700;cursor:pointer;background:var(--light);color:var(--navy);border:1.5px solid #dde4f2;}
.btn-modal-cancel:hover{border-color:var(--blue);color:var(--blue);}

/* Delete confirm modal */
.del-modal{display:none;position:fixed;inset:0;background:rgba(11,31,58,0.55);z-index:1001;align-items:center;justify-content:center;}
.del-modal.open{display:flex;}
.del-box{background:white;border-radius:20px;padding:32px;max-width:400px;width:100%;margin:20px;box-shadow:0 24px 60px rgba(11,31,58,0.2);animation:fadeUp .3s ease both;text-align:center;}
.del-box h4{font-family:'Syne',sans-serif;font-size:20px;font-weight:800;color:var(--navy);margin-bottom:8px;}
.del-box p{color:#6b7a99;font-size:14px;margin-bottom:24px;}
.del-btns{display:flex;gap:12px;}
.btn-del-confirm{flex:1;padding:13px;border-radius:12px;font-family:'Syne',sans-serif;font-size:14px;font-weight:700;cursor:pointer;border:none;background:var(--red);color:white;}
.btn-del-confirm:hover{background:#e0003a;}
.btn-del-cancel{flex:1;padding:13px;border-radius:12px;font-family:'Syne',sans-serif;font-size:14px;font-weight:700;cursor:pointer;background:var(--light);color:var(--navy);border:1.5px solid #dde4f2;}

@keyframes slideIn{from{opacity:0;transform:translateX(40px);}to{opacity:1;transform:translateX(0);}}
@keyframes fadeOut{to{opacity:0;transform:translateX(40px);}}
@keyframes fadeUp{from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:translateY(0);}}
@media(max-width:768px){.sidebar{display:none;}.main{margin-left:0;padding:20px 16px 60px;}.stats-row{grid-template-columns:1fr 1fr;}.form-grid{grid-template-columns:1fr;}}
</style>
</head>
<body>
<div style="display:flex;min-height:100vh;">

<!-- SIDEBAR -->
<aside class="sidebar">
    <a href="admin-dashboard.php" class="sidebar-brand"><div class="b-icon">🚌</div>E<span>Trans</span></a>
    <div class="admin-badge"><i class="fas fa-shield-halved"></i> ADMIN PANEL</div>
    <div class="nav-section">Main</div>
    <a class="nav-item" href="admin-dashboard.php"><i class="fas fa-gauge-high"></i> Dashboard</a>
    <a class="nav-item" href="manage-bookings.php"><i class="fas fa-ticket"></i> Bookings</a>
    <a class="nav-item active" href="manage-buses.php"><i class="fas fa-bus"></i> Buses</a>
    <a class="nav-item" href="manage-routes.php"><i class="fas fa-route"></i> Routes</a>
    <div class="nav-section">Users</div>
    <a class="nav-item" href="#"><i class="fas fa-users"></i> All Users</a>
    <div class="nav-section">System</div>
    <a class="nav-item" href="#"><i class="fas fa-chart-line"></i> Reports</a>
    <a class="nav-item" href="#"><i class="fas fa-gear"></i> Settings</a>
    <a class="sidebar-logout" href="../auth/logout.php"><i class="fas fa-right-from-bracket"></i> Logout</a>
</aside>

<!-- MAIN -->
<main class="main">

    <?php if($toast): ?>
    <div class="toast-msg toast-<?php echo $toast_type; ?>">
        <i class="fas fa-circle-check"></i> <?php echo htmlspecialchars($toast); ?>
    </div>
    <?php endif; ?>

    <!-- Topbar -->
    <div class="topbar">
        <div>
            <h2>Manage Buses 🚌</h2>
            <p>Add, edit and manage your bus fleet</p>
        </div>
        <button class="btn-action btn-primary-action" onclick="openAdd()">
            <i class="fas fa-plus"></i> Add New Bus
        </button>
    </div>

    <!-- Stats -->
    <div class="stats-row">
        <div class="stat-card" style="animation-delay:.0s">
            <div class="stat-icon ic-blue">🚌</div>
            <div><div class="stat-num"><?php echo $total_buses; ?></div><div class="stat-lbl">Total Buses</div></div>
        </div>
        <div class="stat-card" style="animation-delay:.07s">
            <div class="stat-icon ic-green">✅</div>
            <div><div class="stat-num"><?php echo $active_buses; ?></div><div class="stat-lbl">Active</div></div>
        </div>
        <div class="stat-card" style="animation-delay:.14s">
            <div class="stat-icon ic-gold">💤</div>
            <div><div class="stat-num"><?php echo $total_buses - $active_buses; ?></div><div class="stat-lbl">Inactive</div></div>
        </div>
        <div class="stat-card" style="animation-delay:.21s">
            <div class="stat-icon ic-purple">🗺️</div>
            <div><div class="stat-num"><?php echo $routes ? $routes->num_rows : 0; ?></div><div class="stat-lbl">Routes</div></div>
        </div>
    </div>

    <!-- Table -->
    <div class="table-card">
        <div class="table-head-bar">
            <h5><i class="fas fa-bus"></i> All Buses</h5>
            <span style="font-size:13px;color:#8a94a6;"><?php echo $buses ? $buses->num_rows : 0; ?> buses</span>
        </div>
        <div style="overflow-x:auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Bus Name</th>
                    <th>Type</th>
                    <th>Route</th>
                    <th>Departure</th>
                    <th>Arrival</th>
                    <th>Price</th>
                    <th>Seats</th>
                    <th>Amenities</th>
                    <th>Active</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php
            // Reset routes for reuse
            $routes->data_seek(0);

            if($buses && $buses->num_rows > 0):
                $i = 1;
                while($b = $buses->fetch_assoc()):
                    $amenities = array_filter(explode(',', $b['amenities'] ?? ''));
                    $amenityIcons = ['WiFi'=>'fa-wifi','Charging'=>'fa-bolt','Blanket'=>'fa-snowflake','Snacks'=>'fa-cookie-bite','Water'=>'fa-droplet'];
                    $typeClass = match($b['bus_type']) {
                        'AC Sleeper'  => 'tb-ac',
                        'Semi Sleeper'=> 'tb-semi',
                        'Volvo AC'    => 'tb-volvo',
                        default       => 'tb-nonac',
                    };
            ?>
            <tr>
                <td style="color:#a0aabf;font-weight:600;"><?php echo $i++; ?></td>
                <td class="bus-name-cell">
                    <div class="bname"><?php echo htmlspecialchars($b['bus_name']); ?></div>
                    <div class="bnum"><?php echo htmlspecialchars($b['bus_number'] ?? '—'); ?></div>
                </td>
                <td><span class="type-badge <?php echo $typeClass; ?>"><?php echo $b['bus_type']; ?></span></td>
                <td><span class="route-chip"><?php echo htmlspecialchars($b['source']??'—'); ?> → <?php echo htmlspecialchars($b['destination']??'—'); ?></span></td>
                <td><?php echo date("h:i A", strtotime($b['departure_time'])); ?></td>
                <td><?php echo date("h:i A", strtotime($b['arrival_time'])); ?></td>
                <td><strong>₹<?php echo number_format($b['price']); ?></strong></td>
                <td><?php echo $b['total_seats']; ?></td>
                <td>
                    <?php foreach($amenities as $a):
                        $a = trim($a);
                        $icon = $amenityIcons[$a] ?? 'fa-check';
                    ?>
                    <span class="amenity-tag"><i class="fas <?php echo $icon; ?>"></i><?php echo $a; ?></span>
                    <?php endforeach; ?>
                </td>
                <td>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="action" value="toggle">
                        <input type="hidden" name="bus_id" value="<?php echo $b['id']; ?>">
                        <input type="hidden" name="current_active" value="<?php echo $b['is_active']; ?>">
                        <label class="toggle-switch">
                            <input type="checkbox" <?php echo $b['is_active'] ? 'checked' : ''; ?> onchange="this.form.submit()">
                            <span class="toggle-slider"></span>
                        </label>
                    </form>
                </td>
                <td>
                    <div class="action-btns">
                        <button class="btn-sm btn-edit"
                            onclick='openEdit(<?php echo json_encode($b); ?>)'>
                            <i class="fas fa-pen"></i> Edit
                        </button>
                        <button class="btn-sm btn-del"
                            onclick="openDelete(<?php echo $b['id']; ?>, '<?php echo addslashes($b['bus_name']); ?>')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
            <?php endwhile;
            else: ?>
            <tr><td colspan="11" style="text-align:center;color:#8a94a6;padding:40px;">No buses added yet.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>

</main>
</div>

<!-- ── ADD / EDIT MODAL ── -->
<div class="modal-overlay" id="busModal">
<div class="modal-box">
    <h4><i class="fas fa-bus"></i> <span id="modalTitle">Add New Bus</span></h4>
    <form method="POST" action="" id="busForm">
        <input type="hidden" name="action" id="formAction" value="add">
        <input type="hidden" name="bus_id" id="fieldBusId">

        <div class="form-grid">
            <div class="form-group full">
                <label>Bus Name *</label>
                <input type="text" name="bus_name" id="fieldBusName" placeholder="e.g. AC Sleeper - TN Express" required>
            </div>
            <div class="form-group">
                <label>Bus Number</label>
                <input type="text" name="bus_number" id="fieldBusNumber" placeholder="e.g. TN-01-AB-1234">
            </div>
            <div class="form-group">
                <label>Bus Type *</label>
                <select name="bus_type" id="fieldBusType" required>
                    <option value="AC Sleeper">AC Sleeper</option>
                    <option value="Semi Sleeper">Semi Sleeper</option>
                    <option value="Volvo AC">Volvo AC</option>
                    <option value="Non-AC">Non-AC</option>
                </select>
            </div>
            <div class="form-group full">
                <label>Route *</label>
                <select name="route_id" id="fieldRoute" required>
                    <option value="">Select Route</option>
                    <?php
                    $routes->data_seek(0);
                    while($r = $routes->fetch_assoc()):
                    ?>
                    <option value="<?php echo $r['id']; ?>"><?php echo htmlspecialchars($r['source'].' → '.$r['destination']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Departure Time *</label>
                <input type="time" name="departure_time" id="fieldDep" required>
            </div>
            <div class="form-group">
                <label>Arrival Time *</label>
                <input type="time" name="arrival_time" id="fieldArr" required>
            </div>
            <div class="form-group">
                <label>Price per Seat (₹) *</label>
                <input type="number" name="price" id="fieldPrice" placeholder="800" min="1" required>
            </div>
            <div class="form-group">
                <label>Total Seats *</label>
                <input type="number" name="total_seats" id="fieldSeats" placeholder="40" min="1" max="100" required>
            </div>
            <div class="form-group full">
                <label>Amenities</label>
                <div class="amenities-wrap">
                    <?php foreach(['WiFi','Charging','Blanket','Snacks','Water'] as $am): ?>
                    <label class="amenity-check">
                        <input type="checkbox" name="amenities[]" value="<?php echo $am; ?>" class="amenity-cb" data-name="<?php echo $am; ?>">
                        <?php echo $am; ?>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="modal-footer">
            <button type="submit" class="btn-modal-submit" id="submitBtn">
                <i class="fas fa-plus"></i> Add Bus
            </button>
            <button type="button" class="btn-modal-cancel" onclick="closeModal()">Cancel</button>
        </div>
    </form>
</div>
</div>

<!-- ── DELETE MODAL ── -->
<div class="del-modal" id="delModal">
<div class="del-box">
    <div style="font-size:48px;margin-bottom:14px;">🗑️</div>
    <h4>Delete Bus?</h4>
    <p id="delMsg">Are you sure? This cannot be undone.</p>
    <div class="del-btns">
        <form method="POST" style="flex:1;">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="bus_id" id="delBusId">
            <button type="submit" class="btn-del-confirm" style="width:100%;">
                <i class="fas fa-trash"></i> Delete
            </button>
        </form>
        <button class="btn-del-cancel" onclick="closeDelete()">Cancel</button>
    </div>
</div>
</div>

<script>
function openAdd() {
    document.getElementById('modalTitle').textContent = 'Add New Bus';
    document.getElementById('formAction').value = 'add';
    document.getElementById('submitBtn').innerHTML = '<i class="fas fa-plus"></i> Add Bus';
    document.getElementById('busForm').reset();
    document.getElementById('busModal').classList.add('open');
}

function openEdit(bus) {
    document.getElementById('modalTitle').textContent = 'Edit Bus';
    document.getElementById('formAction').value = 'edit';
    document.getElementById('submitBtn').innerHTML = '<i class="fas fa-save"></i> Save Changes';
    document.getElementById('fieldBusId').value    = bus.id;
    document.getElementById('fieldBusName').value  = bus.bus_name;
    document.getElementById('fieldBusNumber').value= bus.bus_number || '';
    document.getElementById('fieldBusType').value  = bus.bus_type;
    document.getElementById('fieldRoute').value    = bus.route_id;
    document.getElementById('fieldDep').value      = bus.departure_time ? bus.departure_time.substring(0,5) : '';
    document.getElementById('fieldArr').value      = bus.arrival_time   ? bus.arrival_time.substring(0,5)   : '';
    document.getElementById('fieldPrice').value    = bus.price;
    document.getElementById('fieldSeats').value    = bus.total_seats;

    // Amenities checkboxes
    const selected = (bus.amenities || '').split(',').map(a => a.trim());
    document.querySelectorAll('.amenity-cb').forEach(cb => {
        cb.checked = selected.includes(cb.dataset.name);
    });

    document.getElementById('busModal').classList.add('open');
}

function closeModal() {
    document.getElementById('busModal').classList.remove('open');
}

function openDelete(id, name) {
    document.getElementById('delBusId').value = id;
    document.getElementById('delMsg').textContent = `Delete "${name}"? This cannot be undone.`;
    document.getElementById('delModal').classList.add('open');
}

function closeDelete() {
    document.getElementById('delModal').classList.remove('open');
}

// Close modals on outside click
document.getElementById('busModal').addEventListener('click', e => { if(e.target === document.getElementById('busModal')) closeModal(); });
document.getElementById('delModal').addEventListener('click', e => { if(e.target === document.getElementById('delModal')) closeDelete(); });
</script>
</body>
</html>