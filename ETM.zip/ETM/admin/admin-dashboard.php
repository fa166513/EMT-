<?php
session_start();
include("../config/config.php");

// Admin auth check
if(!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

$admin_name = $_SESSION['user'] ?? 'Admin';

// ── STATS FROM DB ──
$totalRoutes   = $conn->query("SELECT COUNT(*) as t FROM routes")  ->fetch_assoc()['t'];
$totalBuses    = $conn->query("SELECT COUNT(*) as t FROM buses")   ->fetch_assoc()['t'];
$totalBookings = $conn->query("SELECT COUNT(*) as t FROM bookings")->fetch_assoc()['t'];
$totalUsers    = $conn->query("SELECT COUNT(*) as t FROM users")   ->fetch_assoc()['t'];
$totalRevenue  = $conn->query("SELECT COALESCE(SUM(total_amount),0) as t FROM bookings WHERE payment_status='paid'")->fetch_assoc()['t'];
$pendingPay    = $conn->query("SELECT COUNT(*) as t FROM bookings WHERE payment_status='pending'")->fetch_assoc()['t'];

// Recent bookings
$recentBookings = $conn->query("
    SELECT b.booking_code, b.travel_date, b.total_amount, b.payment_status, b.booking_status,
           b.seats, u.name AS user_name, r.source, r.destination
    FROM bookings b
    JOIN users  u ON b.user_id  = u.id
    JOIN routes r ON b.route_id = r.id
    ORDER BY b.booked_at DESC
    LIMIT 8
");

// Top routes
$topRoutes = $conn->query("
    SELECT r.source, r.destination, COUNT(b.id) AS total
    FROM bookings b
    JOIN routes r ON b.route_id = r.id
    GROUP BY b.route_id
    ORDER BY total DESC
    LIMIT 5
");

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Dashboard — ETrans</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --navy:  #0b1f3a;
    --blue:  #1a5cff;
    --cyan:  #00d4ff;
    --green: #00c48c;
    --gold:  #f5a623;
    --red:   #ff4d6d;
    --light: #f0f4ff;
    --white: #ffffff;
    --sidebar: 260px;
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'DM Sans', sans-serif; background: var(--light); display: flex; min-height: 100vh; }

/* ── SIDEBAR ── */
.sidebar {
    width: var(--sidebar);
    background: var(--navy);
    display: flex; flex-direction: column;
    padding: 28px 16px;
    position: fixed; top: 0; left: 0;
    height: 100vh; overflow-y: auto;
    z-index: 100;
}
.sidebar-brand {
    font-family: 'Syne', sans-serif;
    font-size: 22px; font-weight: 800;
    color: white; padding: 0 10px;
    margin-bottom: 8px;
    text-decoration: none;
    display: flex; align-items: center; gap: 8px;
}
.sidebar-brand span { color: var(--cyan); }
.sidebar-brand .b-icon {
    width: 34px; height: 34px;
    background: linear-gradient(135deg, var(--blue), var(--cyan));
    border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    font-size: 16px;
}
.admin-badge {
    display: inline-flex; align-items: center; gap: 6px;
    background: rgba(255,77,109,0.15);
    border: 1px solid rgba(255,77,109,0.3);
    color: #ff8fa3; font-size: 11px; font-weight: 700;
    padding: 3px 10px; border-radius: 50px;
    margin: 6px 10px 20px;
    letter-spacing: .5px;
}

.nav-section {
    font-size: 10px; font-weight: 700; letter-spacing: 1.5px;
    text-transform: uppercase; color: rgba(255,255,255,0.28);
    padding: 12px 12px 6px;
}
.nav-item {
    display: flex; align-items: center; gap: 11px;
    padding: 11px 14px; border-radius: 10px;
    color: rgba(255,255,255,0.6);
    font-size: 14px; font-weight: 500;
    text-decoration: none;
    transition: all .2s; margin-bottom: 2px;
}
.nav-item:hover  { background: rgba(255,255,255,0.07); color: white; }
.nav-item.active { background: rgba(26,92,255,0.25); border: 1px solid rgba(26,92,255,0.35); color: white; }
.nav-item.active i { color: var(--cyan); }
.nav-item i { width: 17px; text-align: center; color: rgba(255,255,255,0.35); font-size: 14px; }
.nav-item .badge-count {
    margin-left: auto;
    background: var(--red); color: white;
    font-size: 10px; font-weight: 700;
    padding: 2px 7px; border-radius: 50px;
}

.sidebar-admin {
    display: flex; align-items: center; gap: 10px;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 12px; padding: 12px 14px;
    margin: 16px 0;
}
.admin-av {
    width: 36px; height: 36px;
    background: linear-gradient(135deg, var(--red), #ff8fa3);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-family: 'Syne', sans-serif;
    font-size: 14px; font-weight: 800; color: white;
    flex-shrink: 0;
}
.admin-info .admin-name { font-size: 13px; font-weight: 700; color: white; }
.admin-info .admin-role { font-size: 11px; color: rgba(255,255,255,0.4); }

.sidebar-logout {
    margin-top: auto;
    display: flex; align-items: center; gap: 10px;
    padding: 11px 14px; border-radius: 10px;
    color: rgba(255,100,120,0.8); font-size: 14px; font-weight: 500;
    cursor: pointer; text-decoration: none;
    transition: background .2s;
}
.sidebar-logout:hover { background: rgba(255,77,109,0.1); color: var(--red); }

/* ── MAIN ── */
.main {
    margin-left: var(--sidebar);
    flex: 1; padding: 32px 36px 60px;
    min-height: 100vh;
}

/* Top bar */
.topbar {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 32px; flex-wrap: wrap; gap: 14px;
}
.topbar-left h2 {
    font-family: 'Syne', sans-serif;
    font-size: 24px; font-weight: 800; color: var(--navy);
}
.topbar-left p { font-size: 14px; color: #8a94a6; margin-top: 2px; }
.topbar-right { display: flex; gap: 10px; align-items: center; }

.btn-action {
    display: inline-flex; align-items: center; gap: 7px;
    padding: 10px 18px; border-radius: 50px;
    font-family: 'Syne', sans-serif; font-size: 13px; font-weight: 700;
    text-decoration: none; cursor: pointer; border: none;
    transition: transform .2s, box-shadow .2s;
}
.btn-primary-action {
    background: linear-gradient(135deg, var(--blue), #3a7bff);
    color: white;
    box-shadow: 0 4px 14px rgba(26,92,255,0.3);
}
.btn-primary-action:hover { transform: translateY(-2px); box-shadow: 0 8px 22px rgba(26,92,255,0.4); color: white; }
.btn-outline-action {
    background: var(--white); color: var(--navy);
    border: 1.5px solid #dde4f2;
}
.btn-outline-action:hover { border-color: var(--blue); color: var(--blue); }

/* ── STAT CARDS ── */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(6, 1fr);
    gap: 18px; margin-bottom: 28px;
}
.stat-card {
    background: var(--white);
    border-radius: 18px; padding: 22px 20px;
    border: 1.5px solid #edf0f8;
    transition: transform .2s, box-shadow .2s;
    animation: fadeUp .4s ease both;
    grid-column: span 2;
}
.stat-card:hover { transform: translateY(-4px); box-shadow: 0 16px 40px rgba(11,31,58,0.09); }
.stat-card-top {
    display: flex; align-items: flex-start; justify-content: space-between;
    margin-bottom: 14px;
}
.stat-icon {
    width: 46px; height: 46px; border-radius: 12px;
    display: flex; align-items: center; justify-content: center;
    font-size: 20px;
}
.ic-blue  { background: #e8f0ff; }
.ic-green { background: #e0fff5; }
.ic-gold  { background: #fff5e0; }
.ic-red   { background: #fff0f3; }
.ic-cyan  { background: #e0faff; }
.ic-purple{ background: #f3e8ff; }

.stat-trend {
    font-size: 11px; font-weight: 700;
    padding: 3px 8px; border-radius: 50px;
    display: flex; align-items: center; gap: 4px;
}
.trend-up   { background: #e0fff5; color: var(--green); }
.trend-down { background: #fff0f3; color: var(--red); }
.stat-num {
    font-family: 'Syne', sans-serif;
    font-size: 26px; font-weight: 800; color: var(--navy);
    margin-bottom: 4px;
}
.stat-lbl { font-size: 13px; color: #8a94a6; }

/* ── CONTENT GRID ── */
.content-grid {
    display: grid;
    grid-template-columns: 1fr 320px;
    gap: 24px;
}

/* ── SECTION CARD ── */
.section-card {
    background: var(--white);
    border-radius: 20px;
    border: 1.5px solid #edf0f8;
    overflow: hidden;
    animation: fadeUp .4s .1s ease both;
}
.section-head {
    padding: 18px 24px;
    border-bottom: 1.5px solid #f0f4ff;
    display: flex; align-items: center; justify-content: space-between;
}
.section-head h5 {
    font-family: 'Syne', sans-serif;
    font-size: 16px; font-weight: 700; color: var(--navy);
    margin: 0; display: flex; align-items: center; gap: 8px;
}
.section-head h5 i { color: var(--blue); }
.btn-view-all {
    font-size: 13px; color: var(--blue); font-weight: 600;
    text-decoration: none;
}
.btn-view-all:hover { text-decoration: underline; }

/* Table */
.admin-table { width: 100%; border-collapse: collapse; }
.admin-table th {
    background: #f8faff;
    font-size: 11px; font-weight: 700;
    text-transform: uppercase; letter-spacing: 1px;
    color: #8a94a6; padding: 12px 18px;
    border-bottom: 1.5px solid #f0f4ff;
    text-align: left; white-space: nowrap;
}
.admin-table td {
    padding: 14px 18px;
    border-bottom: 1.5px solid #f8faff;
    font-size: 13px; color: var(--navy);
    vertical-align: middle;
}
.admin-table tr:last-child td { border-bottom: none; }
.admin-table tr:hover td { background: #fafbff; }

.code-cell {
    font-family: 'Syne', sans-serif;
    font-size: 13px; font-weight: 700; color: var(--blue);
}
.route-cell { font-weight: 600; font-size: 13px; }
.route-sub  { font-size: 11px; color: #8a94a6; margin-top: 2px; }

.status-pill {
    display: inline-flex; align-items: center; gap: 4px;
    font-size: 11px; font-weight: 700;
    padding: 4px 10px; border-radius: 50px;
}
.sp-paid      { background: #e0fff5; color: var(--green); }
.sp-pending   { background: #fff5e0; color: var(--gold); }
.sp-confirmed { background: #e8f0ff; color: var(--blue); }
.sp-cancelled { background: #fff0f3; color: var(--red); }

/* Top routes card */
.route-list { padding: 16px 20px; }
.route-row {
    display: flex; align-items: center; gap: 12px;
    padding: 12px 0;
    border-bottom: 1px solid #f4f6fc;
}
.route-row:last-child { border-bottom: none; }
.route-rank {
    width: 26px; height: 26px;
    background: var(--light); border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    font-family: 'Syne', sans-serif;
    font-size: 12px; font-weight: 800; color: var(--blue);
    flex-shrink: 0;
}
.route-row-name { flex: 1; font-size: 13px; font-weight: 600; color: var(--navy); }
.route-row-sub  { font-size: 11px; color: #8a94a6; }
.route-row-count {
    font-family: 'Syne', sans-serif;
    font-size: 14px; font-weight: 800; color: var(--blue);
}

/* Quick actions */
.quick-actions {
    display: grid; grid-template-columns: 1fr 1fr;
    gap: 12px; padding: 16px 20px;
}
.quick-btn {
    display: flex; flex-direction: column; align-items: center;
    gap: 8px; padding: 16px 10px;
    background: var(--light); border: 1.5px solid #dde4f2;
    border-radius: 14px; text-decoration: none;
    transition: all .2s; cursor: pointer;
}
.quick-btn:hover { background: #e8f0ff; border-color: var(--blue); transform: translateY(-2px); }
.quick-btn .q-icon { font-size: 22px; }
.quick-btn .q-label {
    font-family: 'Syne', sans-serif;
    font-size: 12px; font-weight: 700; color: var(--navy);
    text-align: center;
}

@keyframes fadeUp {
    from { opacity: 0; transform: translateY(16px); }
    to   { opacity: 1; transform: translateY(0); }
}

@media (max-width: 1100px) {
    .stats-grid { grid-template-columns: repeat(3, 1fr); }
    .stat-card  { grid-column: span 1; }
    .content-grid { grid-template-columns: 1fr; }
}
@media (max-width: 768px) {
    .sidebar { display: none; }
    .main { margin-left: 0; padding: 20px 16px 60px; }
    .stats-grid { grid-template-columns: 1fr 1fr; }
}
</style>

<div style="display:flex; min-height:100vh;">

<!-- ── SIDEBAR ── -->
<aside class="sidebar">
    <a href="admin-dashboard.php" class="sidebar-brand">
        <div class="b-icon">🚌</div>
        E<span>Trans</span>
    </a>
    <div class="admin-badge"><i class="fas fa-shield-halved"></i> ADMIN PANEL</div>

    <div class="sidebar-admin">
        <div class="admin-av"><?php echo strtoupper(substr($admin_name,0,1)); ?></div>
        <div class="admin-info">
            <div class="admin-name"><?php echo htmlspecialchars($admin_name); ?></div>
            <div class="admin-role">Super Administrator</div>
        </div>
    </div>

    <div class="nav-section">Main</div>
    <a class="nav-item active" href="admin-dashboard.php"><i class="fas fa-gauge-high"></i> Dashboard</a>
    <a class="nav-item" href="manage-bookings.php"><i class="fas fa-ticket"></i> Bookings
        <span class="badge-count"><?php echo $pendingPay; ?></span>
    </a>
    <a class="nav-item" href="manage-buses.php"><i class="fas fa-bus"></i> Buses</a>
    <a class="nav-item" href="manage-routes.php"><i class="fas fa-route"></i> Routes</a>

    <div class="nav-section">Users</div>
    <a class="nav-item" href="#"><i class="fas fa-users"></i> All Users</a>
    <a class="nav-item" href="#"><i class="fas fa-user-shield"></i> Admins</a>

    <div class="nav-section">System</div>
    <a class="nav-item" href="#"><i class="fas fa-chart-line"></i> Reports</a>
    <a class="nav-item" href="#"><i class="fas fa-gear"></i> Settings</a>

    <a class="sidebar-logout" href="../auth/logout.php">
        <i class="fas fa-right-from-bracket"></i> Logout
    </a>
</aside>

<!-- ── MAIN ── -->
<main class="main">

    <!-- Topbar -->
    <div class="topbar">
        <div class="topbar-left">
            <h2>Admin Dashboard 🛠️</h2>
            <p><?php echo date("l, d F Y"); ?> — Welcome back, <?php echo htmlspecialchars($admin_name); ?></p>
        </div>
        <div class="topbar-right">
            <a href="manage-buses.php" class="btn-action btn-outline-action">
                <i class="fas fa-plus"></i> Add Bus
            </a>
            <a href="manage-routes.php" class="btn-action btn-primary-action">
                <i class="fas fa-route"></i> Add Route
            </a>
        </div>
    </div>

    <!-- Stats -->
    <div class="stats-grid">
        <div class="stat-card" style="animation-delay:.00s">
            <div class="stat-card-top">
                <div class="stat-icon ic-blue">🎫</div>
                <span class="stat-trend trend-up"><i class="fas fa-arrow-up"></i> 12%</span>
            </div>
            <div class="stat-num"><?php echo number_format($totalBookings); ?></div>
            <div class="stat-lbl">Total Bookings</div>
        </div>
        <div class="stat-card" style="animation-delay:.07s">
            <div class="stat-card-top">
                <div class="stat-icon ic-green">💰</div>
                <span class="stat-trend trend-up"><i class="fas fa-arrow-up"></i> 8%</span>
            </div>
            <div class="stat-num">₹<?php echo number_format($totalRevenue); ?></div>
            <div class="stat-lbl">Total Revenue</div>
        </div>
        <div class="stat-card" style="animation-delay:.14s">
            <div class="stat-card-top">
                <div class="stat-icon ic-cyan">👥</div>
                <span class="stat-trend trend-up"><i class="fas fa-arrow-up"></i> 5%</span>
            </div>
            <div class="stat-num"><?php echo number_format($totalUsers); ?></div>
            <div class="stat-lbl">Registered Users</div>
        </div>
        <div class="stat-card" style="animation-delay:.21s">
            <div class="stat-card-top">
                <div class="stat-icon ic-purple">🚌</div>
                <span class="stat-trend trend-up"><i class="fas fa-arrow-up"></i> 2%</span>
            </div>
            <div class="stat-num"><?php echo number_format($totalBuses); ?></div>
            <div class="stat-lbl">Active Buses</div>
        </div>
        <div class="stat-card" style="animation-delay:.28s">
            <div class="stat-card-top">
                <div class="stat-icon ic-gold">🗺️</div>
                <span class="stat-trend trend-up"><i class="fas fa-arrow-up"></i> 3%</span>
            </div>
            <div class="stat-num"><?php echo number_format($totalRoutes); ?></div>
            <div class="stat-lbl">Total Routes</div>
        </div>
        <div class="stat-card" style="animation-delay:.35s">
            <div class="stat-card-top">
                <div class="stat-icon ic-red">⏳</div>
                <span class="stat-trend trend-down"><i class="fas fa-arrow-down"></i> 2%</span>
            </div>
            <div class="stat-num"><?php echo number_format($pendingPay); ?></div>
            <div class="stat-lbl">Pending Payments</div>
        </div>
    </div>

    <!-- Content Grid -->
    <div class="content-grid">

        <!-- Recent Bookings -->
        <div class="section-card">
            <div class="section-head">
                <h5><i class="fas fa-list"></i> Recent Bookings</h5>
                <a href="manage-bookings.php" class="btn-view-all">View all →</a>
            </div>
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Passenger</th>
                        <th>Route</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php if($recentBookings && $recentBookings->num_rows > 0):
                    while($b = $recentBookings->fetch_assoc()): ?>
                    <tr>
                        <td><span class="code-cell"><?php echo $b['booking_code']; ?></span></td>
                        <td><?php echo htmlspecialchars($b['user_name']); ?></td>
                        <td>
                            <div class="route-cell"><?php echo htmlspecialchars($b['source']); ?> → <?php echo htmlspecialchars($b['destination']); ?></div>
                            <div class="route-sub"><?php echo htmlspecialchars($b['seats']); ?></div>
                        </td>
                        <td><?php echo date("d M Y", strtotime($b['travel_date'])); ?></td>
                        <td><strong>₹<?php echo number_format($b['total_amount']); ?></strong></td>
                        <td>
                            <?php
                            $sc = match($b['payment_status']) {
                                'paid'    => 'sp-paid',
                                'pending' => 'sp-pending',
                                default   => 'sp-cancelled',
                            };
                            ?>
                            <span class="status-pill <?php echo $sc; ?>">
                                <?php echo ucfirst($b['payment_status']); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endwhile;
                else: ?>
                    <tr><td colspan="6" style="text-align:center; color:#8a94a6; padding:30px;">No bookings yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Right column -->
        <div style="display:flex; flex-direction:column; gap:24px;">

            <!-- Quick Actions -->
            <div class="section-card">
                <div class="section-head">
                    <h5><i class="fas fa-bolt"></i> Quick Actions</h5>
                </div>
                <div class="quick-actions">
                    <a href="manage-buses.php" class="quick-btn">
                        <div class="q-icon">🚌</div>
                        <div class="q-label">Add Bus</div>
                    </a>
                    <a href="manage-routes.php" class="quick-btn">
                        <div class="q-icon">🗺️</div>
                        <div class="q-label">Add Route</div>
                    </a>
                    <a href="manage-bookings.php" class="quick-btn">
                        <div class="q-icon">📋</div>
                        <div class="q-label">Bookings</div>
                    </a>
                    <a href="#" class="quick-btn">
                        <div class="q-icon">👥</div>
                        <div class="q-label">Users</div>
                    </a>
                </div>
            </div>

            <!-- Top Routes -->
            <div class="section-card">
                <div class="section-head">
                    <h5><i class="fas fa-fire"></i> Top Routes</h5>
                    <a href="manage-routes.php" class="btn-view-all">All →</a>
                </div>
                <div class="route-list">
                <?php if($topRoutes && $topRoutes->num_rows > 0):
                    $rank = 1;
                    while($r = $topRoutes->fetch_assoc()): ?>
                    <div class="route-row">
                        <div class="route-rank"><?php echo $rank++; ?></div>
                        <div>
                            <div class="route-row-name"><?php echo htmlspecialchars($r['source']); ?> → <?php echo htmlspecialchars($r['destination']); ?></div>
                            <div class="route-row-sub"><?php echo $r['total']; ?> booking<?php echo $r['total'] != 1 ? 's' : ''; ?></div>
                        </div>
                        <div class="route-row-count"><?php echo $r['total']; ?></div>
                    </div>
                    <?php endwhile;
                else: ?>
                    <p style="text-align:center; color:#8a94a6; padding:20px; font-size:13px;">No data yet.</p>
                <?php endif; ?>
                </div>
            </div>

        </div>
    </div>

</main>
</div>

</html>