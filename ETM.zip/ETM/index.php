<?php 
include("config/config.php");
include("includes/header.php"); 
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,300&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --navy:   #0b1f3a;
    --blue:   #1a5cff;
    --cyan:   #00d4ff;
    --gold:   #f5a623;
    --light:  #f0f4ff;
    --white:  #ffffff;
    --glass:  rgba(255,255,255,0.08);
    --radius: 18px;
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'DM Sans', sans-serif; background: var(--light); color: var(--navy); overflow-x: hidden; }

/* ── NAVBAR ── */
.etms-nav {
    position: sticky; top: 0; z-index: 999;
    background: var(--navy);
    padding: 14px 40px;
    display: flex; align-items: center; justify-content: space-between;
    box-shadow: 0 4px 24px rgba(0,0,0,0.18);
}
.etms-nav .brand {
    font-family: 'Syne', sans-serif;
    font-size: 22px; font-weight: 800; color: var(--white);
    text-decoration: none; letter-spacing: -0.5px;
    display: flex; flex-direction: column; line-height: 1.1;
}
.etms-nav .brand span { color: var(--cyan); }
.etms-nav .brand small {
    font-size: 10px; font-weight: 400; letter-spacing: 1.5px;
    text-transform: uppercase; color: rgba(255,255,255,0.4);
    font-family: 'DM Sans', sans-serif;
}
.etms-nav .nav-links { display: flex; gap: 22px; align-items: center; flex-wrap: wrap; }
.etms-nav .nav-links a {
    color: rgba(255,255,255,0.75); text-decoration: none;
    font-size: 14px; font-weight: 500; transition: color .2s;
}
.etms-nav .nav-links a:hover { color: var(--cyan); }
.etms-nav .btn-nav {
    background: var(--blue); color: var(--white) !important;
    padding: 9px 20px; border-radius: 50px;
    font-weight: 600 !important;
    transition: background .2s, transform .15s !important;
}
.etms-nav .btn-nav:hover { background: var(--cyan); color: var(--navy) !important; transform: translateY(-1px); }
.etms-nav .btn-admin {
    background: rgba(245,166,35,0.15);
    border: 1.5px solid rgba(245,166,35,0.4);
    color: var(--gold) !important;
    padding: 8px 18px; border-radius: 50px;
    font-size: 13px; font-weight: 600 !important;
    display: inline-flex; align-items: center; gap: 6px;
    transition: all .2s !important;
}
.etms-nav .btn-admin:hover {
    background: var(--gold); color: var(--navy) !important;
    border-color: var(--gold); transform: translateY(-1px);
}

/* ── HERO ── */
.hero-wrap {
    background: var(--navy); position: relative; overflow: hidden;
    padding: 90px 40px 80px; min-height: 520px;
    display: flex; align-items: center;
}
.hero-bg-dots {
    position: absolute; inset: 0;
    background-image: radial-gradient(circle, rgba(0,212,255,0.13) 1px, transparent 1px);
    background-size: 34px 34px; pointer-events: none;
}
.hero-glow {
    position: absolute; width: 700px; height: 700px;
    background: radial-gradient(circle, rgba(26,92,255,0.35) 0%, transparent 70%);
    top: -200px; right: -200px; pointer-events: none;
}
.hero-content { position: relative; z-index: 2; max-width: 580px; }
.hero-badge {
    display: inline-flex; align-items: center; gap: 8px;
    background: rgba(0,212,255,0.12); border: 1px solid rgba(0,212,255,0.3);
    color: var(--cyan); font-size: 13px; font-weight: 600;
    padding: 6px 16px; border-radius: 50px; margin-bottom: 24px;
    animation: fadeUp .6s ease both;
}
.hero-badge i { font-size: 11px; }
.hero-title {
    font-family: 'Syne', sans-serif;
    font-size: clamp(36px, 5vw, 58px); font-weight: 800;
    color: var(--white); line-height: 1.1; margin-bottom: 20px;
    animation: fadeUp .7s .1s ease both;
}
.hero-title em { font-style: normal; color: var(--cyan); }
.hero-sub {
    color: rgba(255,255,255,0.65); font-size: 17px; line-height: 1.7;
    margin-bottom: 36px; animation: fadeUp .7s .2s ease both;
}
.hero-btns { display: flex; gap: 14px; flex-wrap: wrap; animation: fadeUp .7s .3s ease both; }
.btn-primary-hero {
    background: var(--blue); color: var(--white);
    padding: 14px 30px; border-radius: 50px;
    font-weight: 600; font-size: 15px; text-decoration: none;
    display: inline-flex; align-items: center; gap: 8px;
    transition: transform .2s, box-shadow .2s;
    box-shadow: 0 8px 24px rgba(26,92,255,0.4);
}
.btn-primary-hero:hover { transform: translateY(-3px); box-shadow: 0 12px 32px rgba(26,92,255,0.55); color: #fff; }
.btn-ghost-hero {
    background: transparent; color: rgba(255,255,255,0.8);
    padding: 14px 30px; border-radius: 50px;
    font-weight: 500; font-size: 15px; text-decoration: none;
    border: 1.5px solid rgba(255,255,255,0.2);
    display: inline-flex; align-items: center; gap: 8px;
    transition: border-color .2s, color .2s;
}
.btn-ghost-hero:hover { border-color: var(--cyan); color: var(--cyan); }
.hero-stats { display: flex; gap: 32px; margin-top: 48px; animation: fadeUp .7s .4s ease both; }
.stat-item { text-align: left; }
.stat-num { font-family: 'Syne', sans-serif; font-size: 28px; font-weight: 800; color: var(--white); }
.stat-num span { color: var(--gold); }
.stat-label { font-size: 12px; color: rgba(255,255,255,0.5); text-transform: uppercase; letter-spacing: 1px; }
.hero-visual {
    position: absolute; right: 40px; bottom: 0;
    width: 420px; display: flex; flex-direction: column; align-items: center;
    z-index: 2; animation: float 5s ease-in-out infinite;
}
.hero-bus-card {
    background: rgba(255,255,255,0.06); backdrop-filter: blur(20px);
    border: 1px solid rgba(255,255,255,0.12); border-radius: 20px;
    padding: 24px 28px; color: white; width: 100%;
}
.bus-route-display { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
.bus-city { font-family: 'Syne', sans-serif; font-size: 20px; font-weight: 700; }
.bus-arrow { flex: 1; text-align: center; color: var(--cyan); font-size: 20px; }
.bus-meta { display: flex; gap: 16px; flex-wrap: wrap; }
.bus-meta-item {
    background: rgba(255,255,255,0.08); border-radius: 8px; padding: 8px 14px;
    font-size: 13px; color: rgba(255,255,255,0.8);
    display: flex; align-items: center; gap: 6px;
}
.bus-meta-item i { color: var(--cyan); }
.bus-seats { display: flex; gap: 6px; margin-top: 16px; flex-wrap: wrap; }
.seat-dot { width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 700; }
.seat-dot.taken { background: rgba(255,255,255,0.12); color: rgba(255,255,255,0.3); }
.seat-dot.free  { background: rgba(0,212,255,0.2); color: var(--cyan); border: 1.5px solid rgba(0,212,255,0.4); }
.seat-dot.you   { background: var(--blue); color: #fff; }

/* ── SEARCH ── */
.search-section { max-width: 900px; margin: -50px auto 60px; padding: 0 20px; position: relative; z-index: 10; }
.search-card { background: var(--white); border-radius: 24px; box-shadow: 0 20px 60px rgba(11,31,58,0.14); overflow: hidden; }
.search-card-header {
    background: linear-gradient(90deg, var(--blue), #3a7bff);
    padding: 18px 30px; display: flex; align-items: center; gap: 12px;
}
.search-card-header h5 { font-family: 'Syne', sans-serif; font-size: 17px; font-weight: 700; color: white; margin: 0; }
.search-card-header i { color: rgba(255,255,255,0.8); font-size: 18px; }
.search-card-body { padding: 32px 30px; }
.search-card-body label { font-size: 13px; font-weight: 600; color: #6b7a99; text-transform: uppercase; letter-spacing: .7px; margin-bottom: 8px; display: block; }
.search-card-body .form-control,
.search-card-body .form-select {
    height: 52px; border: 2px solid #e8edf5; border-radius: 12px;
    font-size: 15px; color: var(--navy); background: #f8faff;
    transition: border-color .2s, box-shadow .2s; padding: 0 16px;
}
.search-card-body .form-control:focus,
.search-card-body .form-select:focus {
    border-color: var(--blue); box-shadow: 0 0 0 4px rgba(26,92,255,0.1); background: #fff; outline: none;
}
.swap-btn {
    width: 40px; height: 40px; background: var(--light);
    border: 2px solid #e8edf5; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; color: var(--blue); margin-top: 32px;
    transition: background .2s, transform .3s; font-size: 16px;
}
.swap-btn:hover { background: var(--blue); color: white; transform: rotate(180deg); }
.btn-search-main {
    height: 52px; width: 100%;
    background: linear-gradient(135deg, var(--blue), #3a7bff); color: white;
    font-family: 'Syne', sans-serif; font-size: 16px; font-weight: 700;
    border: none; border-radius: 12px; cursor: pointer;
    display: flex; align-items: center; justify-content: center; gap: 10px;
    margin-top: 29px; transition: transform .2s, box-shadow .2s;
    box-shadow: 0 8px 24px rgba(26,92,255,0.3);
}
.btn-search-main:hover { transform: translateY(-2px); box-shadow: 0 12px 32px rgba(26,92,255,0.45); }
.popular-pills { margin-top: 18px; display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.popular-pills span { font-size: 13px; color: #8a94a6; font-weight: 500; }
.route-pill {
    background: var(--light); border: 1.5px solid #dde4f2; color: var(--blue);
    font-size: 13px; font-weight: 500; padding: 5px 14px; border-radius: 50px;
    cursor: pointer; text-decoration: none; transition: background .2s, border-color .2s;
}
.route-pill:hover { background: var(--blue); color: white; border-color: var(--blue); }

/* ── FEATURES ── */
.section-label { font-size: 13px; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; color: var(--blue); margin-bottom: 10px; }
.section-title { font-family: 'Syne', sans-serif; font-size: clamp(26px, 4vw, 38px); font-weight: 800; color: var(--navy); line-height: 1.2; margin-bottom: 16px; }
.section-sub { color: #6b7a99; font-size: 16px; max-width: 520px; line-height: 1.7; }
.features-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 24px; margin-top: 48px; }
.feature-card {
    background: white; border-radius: 20px; padding: 32px 28px;
    border: 1.5px solid #edf0f8; transition: transform .25s, box-shadow .25s, border-color .25s;
    position: relative; overflow: hidden;
}
.feature-card::before {
    content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px;
    background: linear-gradient(90deg, var(--blue), var(--cyan));
    transform: scaleX(0); transform-origin: left; transition: transform .3s;
}
.feature-card:hover { transform: translateY(-6px); box-shadow: 0 20px 50px rgba(11,31,58,0.1); border-color: transparent; }
.feature-card:hover::before { transform: scaleX(1); }
.feature-icon-wrap { width: 60px; height: 60px; border-radius: 16px; display: flex; align-items: center; justify-content: center; font-size: 26px; margin-bottom: 20px; }
.icon-blue  { background: #e8f0ff; } .icon-cyan  { background: #e0faff; } .icon-gold  { background: #fff4e0; } .icon-green { background: #e4f9ef; }
.feature-card h5 { font-family: 'Syne', sans-serif; font-size: 18px; font-weight: 700; color: var(--navy); margin-bottom: 10px; }
.feature-card p { color: #8a94a6; font-size: 14px; line-height: 1.7; }

/* ── HOW IT WORKS ── */
.how-section { background: var(--navy); padding: 80px 40px; margin-top: 80px; }
.how-steps { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 0; margin-top: 52px; position: relative; }
.how-steps::before { content: ''; position: absolute; top: 36px; left: 10%; right: 10%; height: 2px; background: linear-gradient(90deg, var(--blue), var(--cyan)); z-index: 0; }
.step-item { text-align: center; position: relative; z-index: 1; padding: 0 16px; }
.step-num {
    width: 72px; height: 72px; background: linear-gradient(135deg, var(--blue), #3a7bff);
    border: 4px solid var(--navy); border-radius: 50%;
    display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;
    font-family: 'Syne', sans-serif; font-size: 22px; font-weight: 800; color: white;
    box-shadow: 0 0 0 6px rgba(26,92,255,0.2);
}
.step-title { font-family: 'Syne', sans-serif; font-size: 16px; font-weight: 700; color: white; margin-bottom: 8px; }
.step-desc { font-size: 13px; color: rgba(255,255,255,0.55); line-height: 1.6; }

/* ── ROUTES ── */
.routes-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 20px; margin-top: 40px; }
.route-card {
    background: white; border-radius: 16px; padding: 22px 24px; border: 1.5px solid #edf0f8;
    display: flex; align-items: center; gap: 16px;
    cursor: pointer; text-decoration: none; transition: transform .2s, box-shadow .2s;
}
.route-card:hover { transform: translateY(-4px); box-shadow: 0 16px 40px rgba(11,31,58,0.1); }
.route-icon { width: 50px; height: 50px; background: var(--light); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 22px; flex-shrink: 0; }
.route-info { flex: 1; }
.route-name { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 15px; color: var(--navy); margin-bottom: 4px; }
.route-detail { font-size: 13px; color: #8a94a6; }
.route-price { font-family: 'Syne', sans-serif; font-size: 18px; font-weight: 800; color: var(--blue); }

/* ── CTA ── */
.cta-banner {
    background: linear-gradient(135deg, var(--blue) 0%, #0040cc 100%);
    border-radius: 28px; padding: 60px 50px;
    display: flex; align-items: center; justify-content: space-between;
    gap: 30px; flex-wrap: wrap; margin: 80px 0;
    position: relative; overflow: hidden;
}
.cta-banner::after { content: '🚌'; position: absolute; right: 50px; bottom: -20px; font-size: 140px; opacity: 0.08; pointer-events: none; }
.cta-text h3 { font-family: 'Syne', sans-serif; font-size: 30px; font-weight: 800; color: white; margin-bottom: 10px; }
.cta-text p { color: rgba(255,255,255,0.75); font-size: 16px; }
.btn-cta-white {
    background: white; color: var(--blue); padding: 16px 36px; border-radius: 50px;
    font-family: 'Syne', sans-serif; font-size: 16px; font-weight: 700;
    text-decoration: none; display: inline-flex; align-items: center; gap: 8px;
    white-space: nowrap; transition: transform .2s, box-shadow .2s;
    box-shadow: 0 8px 24px rgba(0,0,0,0.15);
}
.btn-cta-white:hover { transform: translateY(-3px); box-shadow: 0 16px 40px rgba(0,0,0,0.25); color: var(--blue); }

@keyframes fadeUp { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: translateY(0); } }
@keyframes float  { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-14px); } }

@media (max-width: 900px) {
    .hero-visual { display: none; }
    .hero-wrap { padding: 60px 24px; }
    .etms-nav { padding: 14px 20px; }
    .how-steps::before { display: none; }
    .cta-banner { padding: 40px 28px; text-align: center; justify-content: center; }
    .cta-text { text-align: center; }
    .search-section { margin-top: -30px; }
}
@media (max-width: 600px) {
    .hero-stats { gap: 20px; }
    .etms-nav .nav-links { gap: 12px; }
}
</style>

<!-- ══ NAVBAR ══ -->
<nav class="etms-nav">
    <a href="index.php" class="brand">
        E-Transport <span>Management System</span>
        <small>Smart Bus Booking Platform</small>
    </a>
    <div class="nav-links">
        <a href="index.php">Home</a>
        <a href="user/buses.php">Routes</a>
        <?php if(isset($_SESSION['user'])): ?>
            <a href="user/dashboard.php">My Bookings</a>
            <a href="auth/logout.php">Logout</a>
        <?php else: ?>
            <a href="auth/login.php" class="btn-nav">Login / Register</a>
        <?php endif; ?>
        <a href="auth/admin-login.php" class="btn-admin">
            <i class="fas fa-shield-halved"></i> Admin
        </a>
    </div>
</nav>

<!-- ══ HERO ══ -->
<section class="hero-wrap">
    <div class="hero-bg-dots"></div>
    <div class="hero-glow"></div>

    <div class="hero-content">
        <div class="hero-badge"><i class="fas fa-circle-check"></i> Trusted by 50,000+ Passengers</div>
        <h1 class="hero-title">
            Your Smart Way to<br><em>Travel by Bus</em>
        </h1>
        <p class="hero-sub">
            Search routes, pick your seat, and confirm your booking in under 60 seconds.
            Real-time availability. Zero hassle.
        </p>
        <div class="hero-btns">
            <a href="#search" class="btn-primary-hero">
                <i class="fas fa-search"></i> Find a Bus
            </a>
            <a href="auth/register.php" class="btn-ghost-hero">
                <i class="fas fa-user-plus"></i> Create Free Account
            </a>
        </div>
        <div class="hero-stats">
            <div class="stat-item">
                <div class="stat-num">200<span>+</span></div>
                <div class="stat-label">Routes</div>
            </div>
            <div class="stat-item">
                <div class="stat-num">50K<span>+</span></div>
                <div class="stat-label">Bookings</div>
            </div>
            <div class="stat-item">
                <div class="stat-num">99<span>%</span></div>
                <div class="stat-label">On Time</div>
            </div>
        </div>
    </div>

    <!-- Floating Bus Card -->
    <div class="hero-visual">
        <div class="hero-bus-card">
            <div class="bus-route-display">
                <div class="bus-city">Chennai</div>
                <div class="bus-arrow"><i class="fas fa-arrow-right-long"></i></div>
                <div class="bus-city">Bangalore</div>
            </div>
            <div class="bus-meta">
                <div class="bus-meta-item"><i class="fas fa-clock"></i> 08:00 AM</div>
                <div class="bus-meta-item"><i class="fas fa-hourglass-half"></i> 6h 30m</div>
                <div class="bus-meta-item"><i class="fas fa-tag"></i> ₹ 650</div>
            </div>
            <div class="bus-seats">
                <?php
                $pattern = ['taken','taken','free','free','you','taken','free','free','taken','free'];
                foreach($pattern as $i => $s):
                    $label = $s === 'free' ? 'A'.($i+1) : ($s === 'you' ? '✓' : '✕');
                ?>
                <div class="seat-dot <?= $s ?>"><?= $label ?></div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<!-- ══ SEARCH ══ -->
<div class="search-section" id="search">
    <div class="search-card">
        <div class="search-card-header">
            <i class="fas fa-route"></i>
            <h5>Search Available Buses</h5>
        </div>
        <div class="search-card-body">
            <form action="user/buses.php" method="GET">
                <div class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label><i class="fas fa-map-marker-alt me-1"></i> From</label>
                        <input type="text" name="from" class="form-control" placeholder="Origin city" required>
                    </div>
                    <div class="col-auto d-none d-md-flex">
                        <div class="swap-btn" id="swapBtn" title="Swap cities">
                            <i class="fas fa-arrow-right-arrow-left"></i>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label><i class="fas fa-map-pin me-1"></i> To</label>
                        <input type="text" name="to" class="form-control" placeholder="Destination city" required>
                    </div>
                    <div class="col-md-2">
                        <label><i class="fas fa-calendar me-1"></i> Date</label>
                        <input type="date" name="date" class="form-control"
                               min="<?php echo date('Y-m-d'); ?>"
                               value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-2">
                        <label><i class="fas fa-users me-1"></i> Passengers</label>
                        <select name="passengers" class="form-select">
                            <option value="1">1 Passenger</option>
                            <option value="2">2 Passengers</option>
                            <option value="3">3 Passengers</option>
                            <option value="4">4+ Passengers</option>
                        </select>
                    </div>
                    <div class="col-md-1">
                        <button type="submit" class="btn-search-main">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
            </form>
            <div class="popular-pills">
                <span>Popular:</span>
                <a href="user/buses.php?from=Chennai&to=Bangalore&date=<?= date('Y-m-d') ?>&passengers=1" class="route-pill">Chennai → Bangalore</a>
                <a href="user/buses.php?from=Mumbai&to=Pune&date=<?= date('Y-m-d') ?>&passengers=1" class="route-pill">Mumbai → Pune</a>
                <a href="user/buses.php?from=Delhi&to=Agra&date=<?= date('Y-m-d') ?>&passengers=1" class="route-pill">Delhi → Agra</a>
                <a href="user/buses.php?from=Hyderabad&to=Chennai&date=<?= date('Y-m-d') ?>&passengers=1" class="route-pill">Hyderabad → Chennai</a>
            </div>
        </div>
    </div>
</div>

<!-- ══ FEATURES ══ -->
<div class="container" style="padding: 0 24px;">
    <div class="text-center">
        <div class="section-label">Why ETrans?</div>
        <div class="section-title">Everything You Need, Nothing You Don't</div>
        <p class="section-sub mx-auto">A seamless end-to-end bus booking experience designed for everyday travellers.</p>
    </div>
    <div class="features-grid">
        <div class="feature-card">
            <div class="feature-icon-wrap icon-blue">⚡</div>
            <h5>Instant Booking</h5>
            <p>Confirm your seat in seconds with real-time availability updates across all routes.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon-wrap icon-cyan">💺</div>
            <h5>Seat Selector</h5>
            <p>Visualise the bus layout and choose your preferred seat before paying.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon-wrap icon-gold">🛡️</div>
            <h5>Secure Payments</h5>
            <p>Your booking and personal data are protected with industry-grade security.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon-wrap icon-green">📱</div>
            <h5>E-Ticket</h5>
            <p>Receive your booking confirmation instantly. No printing needed — board with your phone.</p>
        </div>
    </div>
</div>

<!-- ══ HOW IT WORKS ══ -->
<section class="how-section">
    <div class="container">
        <div class="text-center">
            <div class="section-label" style="color: var(--cyan);">Simple Process</div>
            <div class="section-title" style="color: white;">How It Works</div>
        </div>
        <div class="how-steps">
            <div class="step-item">
                <div class="step-num">1</div>
                <div class="step-title">Search Route</div>
                <div class="step-desc">Enter your origin, destination, and travel date.</div>
            </div>
            <div class="step-item">
                <div class="step-num">2</div>
                <div class="step-title">Choose Bus</div>
                <div class="step-desc">Pick from available buses with times and pricing.</div>
            </div>
            <div class="step-item">
                <div class="step-num">3</div>
                <div class="step-title">Select Seat</div>
                <div class="step-desc">Pick your preferred seat on the interactive map.</div>
            </div>
            <div class="step-item">
                <div class="step-num">4</div>
                <div class="step-title">Confirm & Go</div>
                <div class="step-desc">Get your e-ticket instantly and board with ease.</div>
            </div>
        </div>
    </div>
</section>

<!-- ══ POPULAR ROUTES ══ -->
<div class="container" style="padding: 80px 24px 0;">
    <div class="section-label">Explore</div>
    <div class="section-title">Popular Routes</div>
    <div class="routes-grid">
        <a href="user/buses.php?from=Chennai&to=Bangalore" class="route-card">
            <div class="route-icon">🏙️</div>
            <div class="route-info">
                <div class="route-name">Chennai → Bangalore</div>
                <div class="route-detail">6h 30m &bull; Daily departures</div>
            </div>
            <div class="route-price">₹650</div>
        </a>
        <a href="user/buses.php?from=Mumbai&to=Pune" class="route-card">
            <div class="route-icon">🌆</div>
            <div class="route-info">
                <div class="route-name">Mumbai → Pune</div>
                <div class="route-detail">3h 00m &bull; 12 trips/day</div>
            </div>
            <div class="route-price">₹350</div>
        </a>
        <a href="user/buses.php?from=Delhi&to=Agra" class="route-card">
            <div class="route-icon">🏔️</div>
            <div class="route-info">
                <div class="route-name">Delhi → Agra</div>
                <div class="route-detail">3h 30m &bull; 8 trips/day</div>
            </div>
            <div class="route-price">₹400</div>
        </a>
        <a href="user/buses.php?from=Hyderabad&to=Chennai" class="route-card">
            <div class="route-icon">🕌</div>
            <div class="route-info">
                <div class="route-name">Hyderabad → Chennai</div>
                <div class="route-detail">8h 00m &bull; Overnight</div>
            </div>
            <div class="route-price">₹850</div>
        </a>
    </div>
</div>

<!-- ══ CTA ══ -->
<div class="container" style="padding: 0 24px;">
    <div class="cta-banner">
        <div class="cta-text">
            <h3>Ready to Book Your Next Journey?</h3>
            <p>Join thousands of travellers who book smarter with ETrans every day.</p>
        </div>
        <a href="auth/register.php" class="btn-cta-white">
            Get Started Free <i class="fas fa-arrow-right"></i>
        </a>
    </div>
</div>

<script>
document.getElementById('swapBtn')?.addEventListener('click', function () {
    const from = document.querySelector('input[name="from"]');
    const to   = document.querySelector('input[name="to"]');
    if (from && to) {
        [from.value, to.value] = [to.value, from.value];
        this.style.transform = 'rotate(180deg)';
        setTimeout(() => this.style.transform = '', 400);
    }
});

const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
        if (e.isIntersecting) {
            e.target.style.animation = 'fadeUp .6s ease both';
            observer.unobserve(e.target);
        }
    });
}, { threshold: 0.15 });
document.querySelectorAll('.feature-card, .route-card, .step-item').forEach(el => observer.observe(el));
</script>

<?php include("includes/footer.php"); ?>