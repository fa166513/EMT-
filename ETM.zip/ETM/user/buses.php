<?php
include("../includes/header.php");

$from = $_GET['from'] ?? '';
$to   = $_GET['to']   ?? '';
$date = $_GET['date'] ?? '';

if(!$from || !$to || !$date){
    echo "<div class='container mt-5'>
            <div class='alert alert-danger text-center p-4'>
                <h5>⚠️ Invalid Search Request</h5>
                <p>Please go back and fill in all fields.</p>
                <a href='../index.php' class='btn btn-primary mt-2'>← Back to Search</a>
            </div>
          </div>";
    include("../includes/footer.php");
    exit();
}

$formatted_date = date("D, d M Y", strtotime($date));

/* -------------------------------------------------------
   DEMO BUS DATA
   [name, departure, arrival, duration, available, total, price, type, amenities]
--------------------------------------------------------*/
$buses = [
    ["AC Sleeper - TN Express",   "22:00","05:30","7h 30m", 12, 32, 800,  "AC Sleeper",  ["WiFi","Charging","Blanket","Water"]],
    ["Semi Sleeper - KSRTC",      "23:00","06:30","7h 30m", 25, 40, 600,  "Semi Sleeper",["Charging","Water"]],
    ["Volvo Multi-Axle - VRL",    "21:00","04:30","7h 30m",  8, 36, 1200, "Volvo AC",    ["WiFi","Charging","Blanket","Snacks","Water"]],
    ["Non-AC Seater - SETC",      "06:00","13:30","7h 30m", 30, 50, 350,  "Non-AC",      ["Water"]],
];
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --navy:  #0b1f3a;
    --blue:  #1a5cff;
    --cyan:  #00d4ff;
    --green: #00c48c;
    --gold:  #f5a623;
    --red:   #ff4d6d;
    --light: #f0f4ff;
    --white: #ffffff;
}

body { font-family: 'DM Sans', sans-serif; background: var(--light); }

/* ── TOP BANNER ── */
.route-banner {
    background: var(--navy);
    padding: 36px 40px;
    position: relative; overflow: hidden;
}
.route-banner::before {
    content: '';
    position: absolute; inset: 0;
    background-image: radial-gradient(circle, rgba(0,212,255,0.1) 1px, transparent 1px);
    background-size: 30px 30px;
    pointer-events: none;
}
.route-banner-inner {
    max-width: 1100px; margin: 0 auto;
    display: flex; align-items: center; justify-content: space-between;
    flex-wrap: wrap; gap: 20px;
    position: relative; z-index: 1;
}
.route-display {
    display: flex; align-items: center; gap: 16px;
}
.route-city-big {
    font-family: 'Syne', sans-serif;
    font-size: 32px; font-weight: 800; color: var(--white);
}
.route-mid {
    display: flex; flex-direction: column; align-items: center; gap: 4px;
    color: var(--cyan);
}
.route-mid i { font-size: 22px; }
.route-mid span { font-size: 11px; letter-spacing: 1px; text-transform: uppercase; opacity: .7; }
.route-meta {
    display: flex; gap: 16px; flex-wrap: wrap; margin-top: 10px;
}
.route-meta-pill {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.15);
    color: rgba(255,255,255,0.75);
    font-size: 13px; padding: 6px 14px;
    border-radius: 50px;
    display: flex; align-items: center; gap: 6px;
}
.route-meta-pill i { color: var(--cyan); }

.btn-new-search {
    background: rgba(255,255,255,0.1);
    border: 1.5px solid rgba(255,255,255,0.25);
    color: white;
    padding: 12px 22px; border-radius: 50px;
    font-family: 'Syne', sans-serif;
    font-size: 14px; font-weight: 600;
    text-decoration: none;
    display: inline-flex; align-items: center; gap: 8px;
    transition: background .2s;
}
.btn-new-search:hover { background: rgba(255,255,255,0.18); color: white; }

/* ── MAIN LAYOUT ── */
.buses-layout {
    max-width: 1100px; margin: 0 auto;
    padding: 32px 20px 80px;
    display: grid;
    grid-template-columns: 240px 1fr;
    gap: 28px;
    align-items: start;
}

/* ── FILTER SIDEBAR ── */
.filter-card {
    background: var(--white);
    border-radius: 20px;
    padding: 24px;
    box-shadow: 0 4px 20px rgba(11,31,58,0.08);
    position: sticky; top: 20px;
}
.filter-title {
    font-family: 'Syne', sans-serif;
    font-size: 16px; font-weight: 700;
    color: var(--navy); margin-bottom: 20px;
    display: flex; align-items: center; gap: 8px;
}
.filter-section { margin-bottom: 22px; }
.filter-label {
    font-size: 11px; font-weight: 700;
    text-transform: uppercase; letter-spacing: 1px;
    color: #8a94a6; margin-bottom: 12px;
}
.filter-check {
    display: flex; align-items: center; gap: 10px;
    margin-bottom: 10px; cursor: pointer;
    font-size: 14px; color: var(--navy);
}
.filter-check input { accent-color: var(--blue); width: 16px; height: 16px; }
.filter-divider { border: none; border-top: 1.5px solid #edf0f8; margin: 18px 0; }
.results-count {
    font-size: 13px; color: #6b7a99;
    margin-bottom: 20px;
    display: flex; align-items: center; justify-content: space-between;
}
.results-count strong { color: var(--navy); font-family: 'Syne', sans-serif; }

/* ── BUS CARDS ── */
.bus-card {
    background: var(--white);
    border-radius: 20px;
    border: 1.5px solid #edf0f8;
    overflow: hidden;
    margin-bottom: 20px;
    transition: transform .25s, box-shadow .25s, border-color .25s;
    animation: fadeUp .4s ease both;
}
.bus-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 20px 50px rgba(11,31,58,0.1);
    border-color: #d0e0ff;
}

.bus-card-top {
    padding: 22px 26px;
    display: flex; align-items: center;
    gap: 20px; flex-wrap: wrap;
}

/* Bus name + type */
.bus-name-col { flex: 0 0 200px; }
.bus-name {
    font-family: 'Syne', sans-serif;
    font-size: 16px; font-weight: 700;
    color: var(--navy); margin-bottom: 6px;
}
.bus-type-badge {
    display: inline-flex; align-items: center; gap: 5px;
    font-size: 12px; font-weight: 600;
    padding: 3px 10px; border-radius: 6px;
}
.badge-ac     { background: #e8f0ff; color: var(--blue); }
.badge-volvo  { background: #e6fff6; color: var(--green); }
.badge-semi   { background: #fff4e0; color: var(--gold); }
.badge-nonac  { background: #f5f5f5; color: #6b7a99; }

/* Time block */
.time-block {
    flex: 1;
    display: flex; align-items: center; gap: 12px;
    justify-content: center;
}
.time-col { text-align: center; }
.time-val {
    font-family: 'Syne', sans-serif;
    font-size: 24px; font-weight: 800;
    color: var(--navy);
}
.time-lbl { font-size: 11px; color: #8a94a6; text-transform: uppercase; letter-spacing: .7px; margin-top: 2px; }
.time-sep {
    flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px;
    color: #c8d3eb;
}
.time-sep .dur {
    font-size: 12px; color: #8a94a6;
    background: var(--light); padding: 2px 10px; border-radius: 50px;
}
.time-sep .dash { width: 100%; height: 1.5px; background: #dde4f2; }

/* Seats indicator */
.seats-col { text-align: center; min-width: 80px; }
.seats-num {
    font-family: 'Syne', sans-serif;
    font-size: 22px; font-weight: 800;
}
.seats-num.low  { color: var(--red); }
.seats-num.mid  { color: var(--gold); }
.seats-num.high { color: var(--green); }
.seats-lbl { font-size: 11px; color: #8a94a6; text-transform: uppercase; letter-spacing: .7px; }
.seats-bar {
    height: 4px; border-radius: 4px;
    background: #edf0f8; margin-top: 6px; overflow: hidden;
}
.seats-fill { height: 100%; border-radius: 4px; transition: width .6s; }
.fill-low  { background: var(--red); }
.fill-mid  { background: var(--gold); }
.fill-high { background: var(--green); }

/* Price + CTA */
.price-col { text-align: right; margin-left: auto; }
.price-val {
    font-family: 'Syne', sans-serif;
    font-size: 28px; font-weight: 800;
    color: var(--blue);
}
.price-lbl { font-size: 11px; color: #8a94a6; }

.btn-select {
    background: linear-gradient(135deg, var(--blue), #3a7bff);
    color: white; border: none;
    padding: 12px 24px; border-radius: 12px;
    font-family: 'Syne', sans-serif;
    font-size: 14px; font-weight: 700;
    text-decoration: none;
    display: inline-flex; align-items: center; gap: 8px;
    margin-top: 10px;
    transition: transform .2s, box-shadow .2s;
    box-shadow: 0 6px 20px rgba(26,92,255,0.3);
    white-space: nowrap;
}
.btn-select:hover { transform: translateY(-2px); box-shadow: 0 10px 28px rgba(26,92,255,0.4); color: white; }

/* Amenities strip */
.bus-card-bottom {
    border-top: 1.5px solid #f0f4ff;
    padding: 12px 26px;
    display: flex; align-items: center; gap: 8px;
    background: #fafbff;
    flex-wrap: wrap;
}
.amenity-tag {
    display: inline-flex; align-items: center; gap: 5px;
    font-size: 12px; color: #6b7a99;
    background: var(--white);
    border: 1.5px solid #edf0f8;
    padding: 4px 12px; border-radius: 50px;
}
.amenity-tag i { color: var(--blue); font-size: 11px; }

/* No results */
.no-results {
    text-align: center; padding: 60px 20px;
    background: var(--white); border-radius: 20px;
}
.no-results .icon { font-size: 64px; margin-bottom: 16px; }
.no-results h4 {
    font-family: 'Syne', sans-serif;
    font-size: 22px; font-weight: 700; color: var(--navy);
}
.no-results p { color: #8a94a6; }

/* Sort bar */
.sort-bar {
    display: flex; align-items: center; gap: 10px;
    margin-bottom: 20px; flex-wrap: wrap;
}
.sort-bar span { font-size: 13px; color: #8a94a6; font-weight: 500; }
.sort-btn {
    background: var(--white); border: 1.5px solid #dde4f2;
    color: var(--navy); font-size: 13px; font-weight: 600;
    padding: 7px 16px; border-radius: 50px;
    cursor: pointer; transition: all .2s;
}
.sort-btn:hover, .sort-btn.active { background: var(--blue); color: white; border-color: var(--blue); }

@keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to   { opacity: 1; transform: translateY(0); }
}

@media (max-width: 768px) {
    .buses-layout { grid-template-columns: 1fr; }
    .filter-card { display: none; }
    .route-banner { padding: 24px 20px; }
    .route-city-big { font-size: 24px; }
    .bus-card-top { gap: 14px; }
    .bus-name-col { flex: 1 1 100%; }
    .price-col { margin-left: 0; }
    .time-val { font-size: 20px; }
}
</style>

<!-- ── ROUTE BANNER ── -->
<div class="route-banner">
    <div class="route-banner-inner">
        <div>
            <div class="route-display">
                <div class="route-city-big"><?php echo htmlspecialchars($from); ?></div>
                <div class="route-mid">
                    <i class="fas fa-arrow-right-long"></i>
                    <span>Direct</span>
                </div>
                <div class="route-city-big"><?php echo htmlspecialchars($to); ?></div>
            </div>
            <div class="route-meta">
                <div class="route-meta-pill"><i class="fas fa-calendar"></i> <?php echo $formatted_date; ?></div>
                <div class="route-meta-pill"><i class="fas fa-bus"></i> <?php echo count($buses); ?> Buses Found</div>
                <?php if(!empty($_GET['passengers'])): ?>
                <div class="route-meta-pill"><i class="fas fa-users"></i> <?php echo htmlspecialchars($_GET['passengers']); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <a href="../index.php" class="btn-new-search">
            <i class="fas fa-search"></i> New Search
        </a>
    </div>
</div>

<!-- ── MAIN CONTENT ── -->
<div class="buses-layout">

    <!-- SIDEBAR FILTERS -->
    <aside class="filter-card">
        <div class="filter-title"><i class="fas fa-sliders" style="color:var(--blue)"></i> Filters</div>

        <div class="filter-section">
            <div class="filter-label">Bus Type</div>
            <label class="filter-check"><input type="checkbox" checked> AC Sleeper</label>
            <label class="filter-check"><input type="checkbox" checked> Semi Sleeper</label>
            <label class="filter-check"><input type="checkbox" checked> Volvo AC</label>
            <label class="filter-check"><input type="checkbox" checked> Non-AC</label>
        </div>

        <hr class="filter-divider">

        <div class="filter-section">
            <div class="filter-label">Departure Time</div>
            <label class="filter-check"><input type="checkbox" checked> Morning (6am–12pm)</label>
            <label class="filter-check"><input type="checkbox" checked> Evening (6pm–12am)</label>
            <label class="filter-check"><input type="checkbox" checked> Night (12am–6am)</label>
        </div>

        <hr class="filter-divider">

        <div class="filter-section">
            <div class="filter-label">Amenities</div>
            <label class="filter-check"><input type="checkbox"> WiFi</label>
            <label class="filter-check"><input type="checkbox"> Charging</label>
            <label class="filter-check"><input type="checkbox"> Blanket</label>
        </div>

        <hr class="filter-divider">

        <div class="filter-section">
            <div class="filter-label">Price Range</div>
            <input type="range" min="300" max="1500" value="1500" style="width:100%; accent-color: var(--blue);">
            <div style="display:flex; justify-content:space-between; font-size:12px; color:#8a94a6; margin-top:6px;">
                <span>₹300</span><span>₹1500</span>
            </div>
        </div>
    </aside>

    <!-- BUS LIST -->
    <div>
        <!-- Sort bar -->
        <div class="sort-bar">
            <span>Sort by:</span>
            <button class="sort-btn active">Price ↑</button>
            <button class="sort-btn">Departure</button>
            <button class="sort-btn">Duration</button>
            <button class="sort-btn">Seats</button>
        </div>

        <?php if(empty($buses)): ?>
        <div class="no-results">
            <div class="icon">🚌</div>
            <h4>No Buses Found</h4>
            <p>Sorry, no buses available for this route and date.<br>Try a different date or route.</p>
            <a href="../index.php" class="btn-select mt-3" style="display:inline-flex">← Search Again</a>
        </div>

        <?php else: ?>

        <?php foreach($buses as $i => $bus):
            $avail   = $bus[4];
            $total   = $bus[5];
            $pct     = ($avail / $total) * 100;
            $seatClass = $pct < 25 ? 'low' : ($pct < 60 ? 'mid' : 'high');
            $fillClass = 'fill-' . $seatClass;

            $amenityIcons = [
                'WiFi'     => 'fa-wifi',
                'Charging' => 'fa-bolt',
                'Blanket'  => 'fa-snowflake',
                'Snacks'   => 'fa-cookie-bite',
                'Water'    => 'fa-droplet',
            ];

            $typeClass = match(true) {
                str_contains($bus[7], 'Volvo') => 'badge-volvo',
                str_contains($bus[7], 'Semi')  => 'badge-semi',
                str_contains($bus[7], 'Non')   => 'badge-nonac',
                default                        => 'badge-ac',
            };

            $delay = $i * 0.1;
        ?>
        <div class="bus-card" style="animation-delay: <?php echo $delay; ?>s">

            <div class="bus-card-top">

                <!-- Name & Type -->
                <div class="bus-name-col">
                    <div class="bus-name"><?php echo htmlspecialchars($bus[0]); ?></div>
                    <span class="bus-type-badge <?php echo $typeClass; ?>">
                        <i class="fas fa-bus"></i> <?php echo $bus[7]; ?>
                    </span>
                </div>

                <!-- Time -->
                <div class="time-block">
                    <div class="time-col">
                        <div class="time-val"><?php echo $bus[1]; ?></div>
                        <div class="time-lbl">Departs</div>
                    </div>
                    <div class="time-sep">
                        <div class="dash"></div>
                        <div class="dur"><i class="fas fa-clock"></i> <?php echo $bus[3]; ?></div>
                        <div class="dash"></div>
                    </div>
                    <div class="time-col">
                        <div class="time-val"><?php echo $bus[2]; ?></div>
                        <div class="time-lbl">Arrives</div>
                    </div>
                </div>

                <!-- Seats -->
                <div class="seats-col">
                    <div class="seats-num <?php echo $seatClass; ?>"><?php echo $avail; ?></div>
                    <div class="seats-lbl">Seats left</div>
                    <div class="seats-bar">
                        <div class="seats-fill <?php echo $fillClass; ?>" style="width:<?php echo $pct; ?>%"></div>
                    </div>
                </div>

                <!-- Price + CTA -->
                <div class="price-col">
                    <div class="price-val">₹<?php echo number_format($bus[6]); ?></div>
                    <div class="price-lbl">per seat</div>
                    <a href="select-seat.php?bus=<?php echo urlencode($bus[0]); ?>&from=<?php echo urlencode($from); ?>&to=<?php echo urlencode($to); ?>&date=<?php echo urlencode($date); ?>&price=<?php echo $bus[6]; ?>"
                       class="btn-select">
                        Select Seats <i class="fas fa-arrow-right"></i>
                    </a>
                </div>

            </div>

            <!-- Amenities -->
            <div class="bus-card-bottom">
                <?php foreach($bus[8] as $amenity):
                    $icon = $amenityIcons[$amenity] ?? 'fa-check';
                ?>
                <span class="amenity-tag">
                    <i class="fas <?php echo $icon; ?>"></i> <?php echo $amenity; ?>
                </span>
                <?php endforeach; ?>
            </div>

        </div>
        <?php endforeach; ?>

        <?php endif; ?>
    </div>

</div>

<script>
// Sort button toggle (UI only — connect to backend when DB is ready)
document.querySelectorAll('.sort-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
    });
});
</script>

<?php include("../includes/footer.php"); ?>