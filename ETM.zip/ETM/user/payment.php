<?php
session_start();
include("../config/config.php");
include("../includes/header.php");

// Get booking details from GET params
$bus         = $_GET['bus']    ?? 'Express Bus';
$from        = $_GET['from']   ?? 'City A';
$to          = $_GET['to']     ?? 'City B';
$date        = $_GET['date']   ?? date('Y-m-d');
$seats       = $_GET['seats']  ?? 'A1';
$price       = (float)($_GET['price'] ?? 800);
$booking_id  = $_GET['booking_id'] ?? 'BK' . rand(100000, 999999);

$seatArray      = explode(",", $seats);
$totalSeats     = count($seatArray);
$subtotal       = $totalSeats * $price;
$convenience    = round($subtotal * 0.02, 2);
$totalAmount    = $subtotal + $convenience;
$formatted_date = date("D, d M Y", strtotime($date));
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root{--navy:#0b1f3a;--blue:#1a5cff;--cyan:#00d4ff;--green:#00c48c;--gold:#f5a623;--red:#ff4d6d;--light:#f0f4ff;--white:#ffffff;}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--light);color:var(--navy);}

.payment-wrap{max-width:960px;margin:40px auto;padding:0 20px 80px;}

/* Page title */
.page-title{font-family:'Syne',sans-serif;font-size:24px;font-weight:800;color:var(--navy);margin-bottom:6px;}
.page-sub{font-size:14px;color:#8a94a6;margin-bottom:28px;}

/* Progress bar */
.progress-bar{display:flex;align-items:center;margin-bottom:36px;}
.progress-step{display:flex;flex-direction:column;align-items:center;gap:6px;flex:1;}
.step-circle{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-size:14px;font-weight:800;}
.step-circle.done{background:var(--green);color:white;}
.step-circle.active{background:var(--blue);color:white;box-shadow:0 0 0 4px rgba(26,92,255,0.2);}
.step-circle.pending{background:#edf0f8;color:#a0aabf;}
.step-label{font-size:11px;font-weight:600;color:#8a94a6;text-transform:uppercase;letter-spacing:.5px;}
.step-label.active{color:var(--blue);}
.step-line{flex:1;height:2px;background:#edf0f8;margin:0 6px;margin-bottom:22px;}
.step-line.done{background:var(--green);}

/* Layout */
.payment-grid{display:grid;grid-template-columns:1fr 380px;gap:24px;}

/* Left — payment form */
.pay-card{background:var(--white);border-radius:20px;border:1.5px solid #edf0f8;overflow:hidden;margin-bottom:20px;}
.pay-card-head{padding:18px 24px;border-bottom:1.5px solid #f0f4ff;display:flex;align-items:center;gap:10px;}
.pay-card-head h5{font-family:'Syne',sans-serif;font-size:16px;font-weight:700;color:var(--navy);margin:0;}
.pay-card-head i{color:var(--blue);font-size:16px;}
.pay-card-body{padding:24px;}

/* Payment method tabs */
.method-tabs{display:flex;gap:12px;margin-bottom:24px;flex-wrap:wrap;}
.method-tab{flex:1;min-width:100px;padding:14px 10px;border:2px solid #e8edf5;border-radius:14px;display:flex;flex-direction:column;align-items:center;gap:7px;cursor:pointer;transition:all .2s;background:#f8faff;}
.method-tab:hover{border-color:var(--blue);}
.method-tab.active{border-color:var(--blue);background:#e8f0ff;}
.method-tab i{font-size:22px;color:#a0aabf;}
.method-tab.active i{color:var(--blue);}
.method-tab span{font-size:12px;font-weight:600;color:#6b7a99;}
.method-tab.active span{color:var(--blue);}

/* Form fields */
.form-group{margin-bottom:18px;}
.form-group label{display:block;font-size:12px;font-weight:700;color:#6b7a99;margin-bottom:7px;text-transform:uppercase;letter-spacing:.7px;}
.input-wrap{position:relative;}
.input-wrap i.icon-left{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#a0aabf;font-size:14px;pointer-events:none;}
.input-wrap input,.input-wrap select{width:100%;height:50px;border:2px solid #e8edf5;border-radius:12px;padding:0 14px 0 42px;font-family:'DM Sans',sans-serif;font-size:14px;color:var(--navy);background:#f8faff;outline:none;transition:border-color .2s;}
.input-wrap input:focus,.input-wrap select:focus{border-color:var(--blue);box-shadow:0 0 0 4px rgba(26,92,255,0.08);background:white;}
.input-wrap input.no-icon{padding-left:14px;}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px;}

/* Card preview */
.card-preview{background:linear-gradient(135deg,var(--navy),#1a3a6b);border-radius:16px;padding:22px 24px;margin-bottom:20px;position:relative;overflow:hidden;}
.card-preview::before{content:'';position:absolute;inset:0;background-image:radial-gradient(circle,rgba(0,212,255,0.07) 1px,transparent 1px);background-size:20px 20px;}
.card-chip{width:36px;height:28px;background:linear-gradient(135deg,var(--gold),#ffcc44);border-radius:6px;margin-bottom:20px;}
.card-number{font-family:'Syne',sans-serif;font-size:18px;font-weight:700;color:white;letter-spacing:3px;margin-bottom:16px;}
.card-bottom{display:flex;justify-content:space-between;align-items:flex-end;}
.card-holder{font-size:12px;color:rgba(255,255,255,0.5);text-transform:uppercase;letter-spacing:1px;}
.card-holder strong{display:block;font-size:14px;color:white;font-weight:600;letter-spacing:1.5px;margin-top:2px;}
.card-expiry{text-align:right;}
.card-expiry .label{font-size:10px;color:rgba(255,255,255,0.4);text-transform:uppercase;letter-spacing:1px;}
.card-expiry strong{display:block;font-size:14px;color:white;font-weight:600;}

/* UPI section */
.upi-section{display:none;}
.upi-section.show{display:block;}
.card-section{display:block;}
.card-section.hide{display:none;}
.netbanking-section{display:none;}
.netbanking-section.show{display:block;}
.wallet-section{display:none;}
.wallet-section.show{display:block;}

.bank-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:18px;}
.bank-btn{padding:12px;border:2px solid #e8edf5;border-radius:12px;text-align:center;cursor:pointer;transition:all .2s;background:#f8faff;}
.bank-btn:hover,.bank-btn.selected{border-color:var(--blue);background:#e8f0ff;}
.bank-btn img{height:28px;object-fit:contain;}
.bank-btn span{display:block;font-size:11px;font-weight:600;color:#6b7a99;margin-top:6px;}

.wallet-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;}
.wallet-btn{padding:12px;border:2px solid #e8edf5;border-radius:12px;text-align:center;cursor:pointer;transition:all .2s;background:#f8faff;display:flex;flex-direction:column;align-items:center;gap:6px;}
.wallet-btn:hover,.wallet-btn.selected{border-color:var(--blue);background:#e8f0ff;}
.wallet-btn i{font-size:22px;color:#a0aabf;}
.wallet-btn.selected i{color:var(--blue);}
.wallet-btn span{font-size:11px;font-weight:600;color:#6b7a99;}

/* Security badge */
.security-note{display:flex;align-items:center;gap:8px;font-size:12px;color:#8a94a6;margin-top:12px;}
.security-note i{color:var(--green);}

/* Right — order summary */
.summary-card{background:var(--white);border-radius:20px;border:1.5px solid #edf0f8;overflow:hidden;position:sticky;top:20px;}
.summary-head{background:linear-gradient(135deg,var(--navy),#162d52);padding:20px 22px;}
.summary-head h5{font-family:'Syne',sans-serif;font-size:16px;font-weight:700;color:white;margin:0 0 14px;}
.summary-route{display:flex;align-items:center;gap:8px;}
.summary-city{font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:white;}
.summary-arrow{color:var(--cyan);font-size:14px;}
.summary-date{font-size:12px;color:rgba(255,255,255,0.5);margin-top:6px;}
.summary-body{padding:20px 22px;}
.summary-row{display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid #f4f6fc;font-size:13px;}
.summary-row:last-child{border-bottom:none;}
.summary-row .label{color:#8a94a6;}
.summary-row .value{font-weight:600;color:var(--navy);}
.summary-row.total{padding-top:14px;margin-top:4px;border-top:2px dashed #edf0f8;border-bottom:none;}
.summary-row.total .label{font-family:'Syne',sans-serif;font-size:15px;font-weight:700;color:var(--navy);}
.summary-row.total .value{font-family:'Syne',sans-serif;font-size:20px;font-weight:800;color:var(--blue);}
.seat-chips{display:flex;gap:5px;flex-wrap:wrap;margin-top:4px;}
.seat-chip{background:#e8f0ff;color:var(--blue);font-size:11px;font-weight:700;padding:3px 8px;border-radius:6px;}

/* Pay button */
.btn-pay-now{width:100%;height:54px;background:linear-gradient(135deg,var(--green),#00e0a0);color:white;border:none;border-radius:14px;font-family:'Syne',sans-serif;font-size:17px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;transition:transform .2s,box-shadow .2s;box-shadow:0 8px 24px rgba(0,196,140,0.4);margin-top:16px;}
.btn-pay-now:hover{transform:translateY(-2px);box-shadow:0 12px 32px rgba(0,196,140,0.5);}
.btn-pay-now:disabled{background:#ccc;box-shadow:none;cursor:not-allowed;transform:none;}
.timer-note{text-align:center;font-size:12px;color:#8a94a6;margin-top:10px;display:flex;align-items:center;justify-content:center;gap:5px;}
.timer-note i{color:var(--gold);}

/* Processing overlay */
.processing-overlay{display:none;position:fixed;inset:0;background:rgba(11,31,58,0.7);z-index:9999;align-items:center;justify-content:center;flex-direction:column;gap:20px;}
.processing-overlay.show{display:flex;}
.processing-spinner{width:70px;height:70px;border:5px solid rgba(255,255,255,0.2);border-top-color:var(--cyan);border-radius:50%;animation:spin 1s linear infinite;}
.processing-text{font-family:'Syne',sans-serif;font-size:18px;font-weight:700;color:white;}
.processing-sub{font-size:14px;color:rgba(255,255,255,0.6);}

@keyframes spin{to{transform:rotate(360deg);}}
@keyframes fadeUp{from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:translateY(0);}}

@media(max-width:768px){
    .payment-grid{grid-template-columns:1fr;}
    .form-row{grid-template-columns:1fr;}
    .method-tab span{display:none;}
}
</style>

<div class="payment-wrap">

    <h2 class="page-title">Complete Your Payment 💳</h2>
    <p class="page-sub">You're one step away from confirming your booking</p>

    <!-- Progress -->
    <div class="progress-bar">
        <div class="progress-step">
            <div class="step-circle done"><i class="fas fa-check"></i></div>
            <div class="step-label">Search</div>
        </div>
        <div class="step-line done"></div>
        <div class="progress-step">
            <div class="step-circle done"><i class="fas fa-check"></i></div>
            <div class="step-label">Select Seat</div>
        </div>
        <div class="step-line done"></div>
        <div class="progress-step">
            <div class="step-circle active">3</div>
            <div class="step-label active">Payment</div>
        </div>
        <div class="step-line"></div>
        <div class="progress-step">
            <div class="step-circle pending">4</div>
            <div class="step-label">E-Ticket</div>
        </div>
    </div>

    <div class="payment-grid">

        <!-- LEFT: Payment Form -->
        <div>

            <!-- Payment Method -->
            <div class="pay-card">
                <div class="pay-card-head">
                    <i class="fas fa-credit-card"></i>
                    <h5>Choose Payment Method</h5>
                </div>
                <div class="pay-card-body">
                    <div class="method-tabs">
                        <div class="method-tab active" onclick="switchMethod('card', this)">
                            <i class="fas fa-credit-card"></i>
                            <span>Card</span>
                        </div>
                        <div class="method-tab" onclick="switchMethod('upi', this)">
                            <i class="fas fa-mobile-screen-button"></i>
                            <span>UPI</span>
                        </div>
                        <div class="method-tab" onclick="switchMethod('netbanking', this)">
                            <i class="fas fa-building-columns"></i>
                            <span>Net Banking</span>
                        </div>
                        <div class="method-tab" onclick="switchMethod('wallet', this)">
                            <i class="fas fa-wallet"></i>
                            <span>Wallet</span>
                        </div>
                    </div>

                    <!-- CARD -->
                    <div class="card-section" id="cardSection">
                        <div class="card-preview" id="cardPreview">
                            <div class="card-chip"></div>
                            <div class="card-number" id="previewNumber">•••• •••• •••• ••••</div>
                            <div class="card-bottom">
                                <div class="card-holder">
                                    Card Holder
                                    <strong id="previewName">YOUR NAME</strong>
                                </div>
                                <div class="card-expiry">
                                    <div class="label">Expires</div>
                                    <strong id="previewExpiry">MM/YY</strong>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Card Number</label>
                            <div class="input-wrap">
                                <i class="fas fa-credit-card icon-left"></i>
                                <input type="text" id="cardNumber" placeholder="1234 5678 9012 3456"
                                       maxlength="19" oninput="formatCard(this)" class="card-field">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Cardholder Name</label>
                            <div class="input-wrap">
                                <i class="fas fa-user icon-left"></i>
                                <input type="text" id="cardName" placeholder="Name on card"
                                       oninput="document.getElementById('previewName').textContent = this.value.toUpperCase() || 'YOUR NAME'" class="card-field">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Expiry Date</label>
                                <div class="input-wrap">
                                    <i class="fas fa-calendar icon-left"></i>
                                    <input type="text" id="cardExpiry" placeholder="MM/YY"
                                           maxlength="5" oninput="formatExpiry(this)" class="card-field">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>CVV</label>
                                <div class="input-wrap">
                                    <i class="fas fa-lock icon-left"></i>
                                    <input type="password" id="cardCvv" placeholder="•••"
                                           maxlength="3" class="card-field">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- UPI -->
                    <div class="upi-section" id="upiSection">
                        <div class="form-group">
                            <label>UPI ID</label>
                            <div class="input-wrap">
                                <i class="fas fa-at icon-left"></i>
                                <input type="text" id="upiId" placeholder="yourname@upi" class="upi-field">
                            </div>
                        </div>
                        <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:8px;">
                            <?php foreach(['GPay','PhonePe','Paytm','BHIM'] as $app): ?>
                            <div onclick="document.getElementById('upiId').value='user@<?= strtolower($app) ?>'; document.querySelectorAll('.upi-app').forEach(e=>e.classList.remove('selected')); this.classList.add('selected');"
                                 class="upi-app" style="padding:10px 18px;border:2px solid #e8edf5;border-radius:10px;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s;background:#f8faff;">
                                <?= $app ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- NET BANKING -->
                    <div class="netbanking-section" id="netbankingSection">
                        <div class="bank-grid">
                            <?php
                            $banks = ['SBI','HDFC','ICICI','Axis','Kotak','PNB'];
                            foreach($banks as $bank):
                            ?>
                            <div class="bank-btn" onclick="selectBank(this)">
                                <span style="font-family:'Syne',sans-serif;font-size:14px;font-weight:800;color:var(--navy);"><?= $bank ?></span>
                                <span>Bank</span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="form-group">
                            <label>Or select other bank</label>
                            <div class="input-wrap">
                                <i class="fas fa-building-columns icon-left"></i>
                                <select style="padding-left:42px;height:50px;border:2px solid #e8edf5;border-radius:12px;width:100%;font-family:'DM Sans',sans-serif;font-size:14px;background:#f8faff;outline:none;">
                                    <option>Select your bank</option>
                                    <option>Bank of Baroda</option>
                                    <option>Canara Bank</option>
                                    <option>Union Bank</option>
                                    <option>IndusInd Bank</option>
                                    <option>Yes Bank</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- WALLET -->
                    <div class="wallet-section" id="walletSection">
                        <div class="wallet-grid">
                            <?php
                            $wallets = [
                                ['Paytm','fa-wallet'],
                                ['PhonePe','fa-mobile'],
                                ['Amazon Pay','fa-amazon'],
                                ['Mobikwik','fa-coins'],
                                ['Freecharge','fa-bolt'],
                                ['Airtel','fa-signal'],
                            ];
                            foreach($wallets as $w):
                            ?>
                            <div class="wallet-btn" onclick="selectWallet(this)">
                                <i class="fas <?= $w[1] ?>"></i>
                                <span><?= $w[0] ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="security-note">
                        <i class="fas fa-shield-halved"></i>
                        Your payment is secured with 256-bit SSL encryption
                    </div>
                </div>
            </div>

        </div>

        <!-- RIGHT: Order Summary -->
        <div>
            <div class="summary-card">
                <div class="summary-head">
                    <h5>Booking Summary</h5>
                    <div class="summary-route">
                        <span class="summary-city"><?php echo htmlspecialchars($from); ?></span>
                        <i class="fas fa-arrow-right summary-arrow"></i>
                        <span class="summary-city"><?php echo htmlspecialchars($to); ?></span>
                    </div>
                    <div class="summary-date">
                        <i class="fas fa-calendar" style="color:var(--cyan);margin-right:5px;"></i>
                        <?php echo $formatted_date; ?>
                    </div>
                </div>
                <div class="summary-body">
                    <div class="summary-row">
                        <span class="label">Bus</span>
                        <span class="value"><?php echo htmlspecialchars($bus); ?></span>
                    </div>
                    <div class="summary-row">
                        <span class="label">Seats</span>
                        <div>
                            <div class="seat-chips">
                                <?php foreach($seatArray as $s): ?>
                                <span class="seat-chip"><?php echo trim($s); ?></span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <div class="summary-row">
                        <span class="label"><?php echo $totalSeats; ?> × ₹<?php echo number_format($price); ?></span>
                        <span class="value">₹<?php echo number_format($subtotal); ?></span>
                    </div>
                    <div class="summary-row">
                        <span class="label">Convenience Fee (2%)</span>
                        <span class="value">₹<?php echo number_format($convenience, 2); ?></span>
                    </div>
                    <div class="summary-row total">
                        <span class="label">Total Payable</span>
                        <span class="value">₹<?php echo number_format($totalAmount, 2); ?></span>
                    </div>

                    <button class="btn-pay-now" id="payBtn" onclick="processPayment()">
                        <i class="fas fa-lock"></i>
                        Pay ₹<?php echo number_format($totalAmount, 2); ?>
                    </button>

                    <div class="timer-note">
                        <i class="fas fa-clock"></i>
                        <span>Booking held for <strong id="timer">09:59</strong></span>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Processing Overlay -->
<div class="processing-overlay" id="processingOverlay">
    <div class="processing-spinner"></div>
    <div class="processing-text">Processing Payment...</div>
    <div class="processing-sub">Please do not close this window</div>
</div>

<script>
// Payment method switcher
function switchMethod(method, el) {
    currentMethod = method;
    document.querySelectorAll('.method-tab').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('cardSection').style.display        = method === 'card'        ? 'block' : 'none';
    document.getElementById('upiSection').style.display         = method === 'upi'         ? 'block' : 'none';
    document.getElementById('netbankingSection').style.display  = method === 'netbanking'  ? 'block' : 'none';
    document.getElementById('walletSection').style.display      = method === 'wallet'      ? 'block' : 'none';
}

// Format card number
function formatCard(input) {
    let val = input.value.replace(/\D/g, '').substring(0, 16);
    input.value = val.replace(/(.{4})/g, '$1 ').trim();
    const display = val.padEnd(16, '•').replace(/(.{4})/g, '$1 ').trim();
    document.getElementById('previewNumber').textContent = display;
}

// Format expiry
function formatExpiry(input) {
    let val = input.value.replace(/\D/g, '').substring(0, 4);
    if(val.length >= 2) val = val.substring(0,2) + '/' + val.substring(2);
    input.value = val;
    document.getElementById('previewExpiry').textContent = val || 'MM/YY';
}

function selectBank(el) {
    document.querySelectorAll('.bank-btn').forEach(b => b.classList.remove('selected'));
    el.classList.add('selected');
}

function selectWallet(el) {
    document.querySelectorAll('.wallet-btn').forEach(b => b.classList.remove('selected'));
    el.classList.add('selected');
}

// ── VALIDATION ──
let currentMethod = 'card';

function showError(msg) {
    // Remove existing toast
    const old = document.getElementById('toast-error');
    if(old) old.remove();

    const toast = document.createElement('div');
    toast.id = 'toast-error';
    toast.innerHTML = `<i class="fas fa-circle-exclamation"></i> ${msg}`;
    toast.style.cssText = `
        position:fixed; bottom:30px; left:50%; transform:translateX(-50%);
        background:#ff4d6d; color:white; padding:14px 24px; border-radius:12px;
        font-family:'DM Sans',sans-serif; font-size:14px; font-weight:600;
        display:flex; align-items:center; gap:10px; z-index:99999;
        box-shadow:0 8px 24px rgba(255,77,109,0.4);
        animation:fadeUp .3s ease;
    `;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3500);
}

function validateCard() {
    const num  = document.getElementById('cardNumber').value.replace(/\s/g,'');
    const name = document.getElementById('cardName').value.trim();
    const exp  = document.getElementById('cardExpiry').value.trim();
    const cvv  = document.getElementById('cardCvv').value.trim();

    if(num.length < 16)          { showError('Enter a valid 16-digit card number'); return false; }
    if(name.length < 3)          { showError('Enter the cardholder name'); return false; }
    if(!/^\d{2}\/\d{2}$/.test(exp)) { showError('Enter expiry in MM/YY format'); return false; }

    // Check expiry not in past
    const [mm, yy] = exp.split('/').map(Number);
    const now = new Date();
    const expDate = new Date(2000 + yy, mm - 1);
    if(expDate < now)            { showError('Your card has expired'); return false; }
    if(mm < 1 || mm > 12)       { showError('Invalid expiry month'); return false; }
    if(cvv.length < 3)           { showError('Enter valid 3-digit CVV'); return false; }

    return true;
}

function validateUPI() {
    const upi = document.getElementById('upiId').value.trim();
    if(!upi.includes('@') || upi.length < 5) {
        showError('Enter a valid UPI ID (e.g. name@upi)');
        return false;
    }
    return true;
}

function validateNetbanking() {
    const selected = document.querySelector('.bank-btn.selected');
    if(!selected) { showError('Please select a bank to continue'); return false; }
    return true;
}

function validateWallet() {
    const selected = document.querySelector('.wallet-btn.selected');
    if(!selected) { showError('Please select a wallet to continue'); return false; }
    return true;
}

// Process payment — dummy simulation
function processPayment() {
    // Run validation based on active method
    let valid = false;
    if(currentMethod === 'card')        valid = validateCard();
    else if(currentMethod === 'upi')    valid = validateUPI();
    else if(currentMethod === 'netbanking') valid = validateNetbanking();
    else if(currentMethod === 'wallet') valid = validateWallet();

    if(!valid) return; // stop if validation fails

    // All good — show processing overlay
    document.getElementById('processingOverlay').classList.add('show');
    document.getElementById('payBtn').disabled = true;

    // Simulate 2.5 second payment processing then redirect
    setTimeout(() => {
        const params = new URLSearchParams({
            bus:        '<?php echo urlencode($bus); ?>',
            from:       '<?php echo urlencode($from); ?>',
            to:         '<?php echo urlencode($to); ?>',
            date:       '<?php echo urlencode($date); ?>',
            seats:      '<?php echo urlencode($seats); ?>',
            total:      '<?php echo $totalAmount; ?>',
            booking_id: '<?php echo $booking_id; ?>'
        });
        window.location.href = '../user/confirm.php?' + params.toString();
    }, 2500);
}

// Countdown timer
let timeLeft = 599;
const timerEl = document.getElementById('timer');
const interval = setInterval(() => {
    timeLeft--;
    if(timeLeft <= 0) { clearInterval(interval); timerEl.textContent = '00:00'; return; }
    const m = String(Math.floor(timeLeft/60)).padStart(2,'0');
    const s = String(timeLeft % 60).padStart(2,'0');
    timerEl.textContent = m + ':' + s;
    if(timeLeft <= 60) timerEl.style.color = 'var(--red)';
}, 1000);
</script>

<?php include("../includes/footer.php"); ?>