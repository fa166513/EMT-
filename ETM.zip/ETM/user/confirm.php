<?php
include("../config/config.php");
include("../includes/header.php");

// Read from GET (sent by payment.php redirect)
$bus        = $_GET['bus']        ?? 'E-Transport Bus';
$from       = $_GET['from']       ?? 'City A';
$to         = $_GET['to']         ?? 'City B';
$date       = $_GET['date']       ?? date('Y-m-d');
$seats      = $_GET['seats']      ?? 'A1';
$total      = $_GET['total']      ?? '0';
$booking_id = $_GET['booking_id'] ?? 'BK' . rand(100000, 999999);

// Passenger name from session or fallback
$passenger_name = $_SESSION['user'] ?? 'Passenger';

$seatArray      = explode(",", $seats);
$totalSeats     = count($seatArray);
$formatted_date = date("D, d M Y", strtotime($date));
$time_now       = date("h:i A");
$booked_on      = date("d M Y");
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --navy:  #0b1f3a;
    --blue:  #1a5cff;
    --cyan:  #00d4ff;
    --green: #00c48c;
    --gold:  #f5a623;
    --light: #f0f4ff;
    --white: #ffffff;
}

body { font-family: 'DM Sans', sans-serif; background: var(--light); }

/* ── PAGE ── */
.confirm-page {
    max-width: 700px;
    margin: 0 auto;
    padding: 48px 20px 80px;
}

/* ── SUCCESS ANIM ── */
.success-header {
    text-align: center;
    margin-bottom: 32px;
    animation: popIn .5s cubic-bezier(.175,.885,.32,1.275) both;
}
.checkmark-ring {
    width: 96px; height: 96px;
    background: linear-gradient(135deg, #d4fff0, #a0f4d8);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 20px;
    box-shadow: 0 0 0 14px rgba(0,196,140,0.1), 0 0 0 28px rgba(0,196,140,0.05);
    animation: pulseRing 2s ease-in-out infinite;
}
.checkmark-ring i { font-size: 42px; color: var(--green); }

.success-header h2 {
    font-family: 'Syne', sans-serif;
    font-size: 32px; font-weight: 800; color: var(--navy);
    margin-bottom: 8px;
}
.success-header p { color: #6b7a99; font-size: 15px; }

/* Booking ID pill */
.bid-pill {
    display: inline-flex; align-items: center; gap: 10px;
    background: var(--navy);
    color: var(--cyan);
    font-family: 'Syne', sans-serif;
    font-size: 16px; font-weight: 700;
    padding: 12px 28px; border-radius: 50px;
    margin-bottom: 32px;
    letter-spacing: 1.5px;
    cursor: pointer;
    position: relative;
}
.bid-pill i { font-size: 13px; opacity: .6; }
.bid-copy {
    font-size: 11px; color: rgba(0,212,255,0.7);
    margin-left: 6px; font-weight: 500;
    letter-spacing: 0;
}

/* ── STATUS STEPS ── */
.status-bar {
    display: flex; align-items: center;
    background: var(--white);
    border-radius: 16px;
    padding: 20px 24px;
    margin-bottom: 24px;
    box-shadow: 0 4px 20px rgba(11,31,58,0.07);
    gap: 0;
}
.status-step {
    flex: 1; text-align: center;
    display: flex; flex-direction: column; align-items: center; gap: 6px;
}
.status-dot {
    width: 36px; height: 36px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 16px;
}
.status-dot.done  { background: var(--green); color: white; }
.status-dot.now   { background: var(--blue);  color: white; box-shadow: 0 0 0 6px rgba(26,92,255,0.15); }
.status-dot.next  { background: #edf0f8; color: #a0aabf; }
.status-label { font-size: 11px; font-weight: 600; color: #8a94a6; text-transform: uppercase; letter-spacing: .7px; }
.status-label.active { color: var(--blue); }
.status-label.done-l { color: var(--green); }
.status-connector {
    flex: 0 0 40px; height: 2px;
    background: linear-gradient(90deg, var(--green), #dde4f2);
    margin-bottom: 22px;
}
.status-connector.pending { background: #dde4f2; }

/* ── TICKET ── */
.ticket-wrap {
    background: var(--white);
    border-radius: 24px;
    box-shadow: 0 20px 60px rgba(11,31,58,0.12);
    overflow: hidden;
    animation: fadeUp .5s .1s ease both;
}

/* Header */
.ticket-top {
    background: linear-gradient(135deg, var(--navy) 0%, #1a3560 100%);
    padding: 30px 32px;
    position: relative; overflow: hidden;
}
.ticket-top::before {
    content: '';
    position: absolute; inset: 0;
    background-image: radial-gradient(circle, rgba(0,212,255,0.08) 1px, transparent 1px);
    background-size: 24px 24px;
}
.ticket-top::after {
    content: '🚌';
    position: absolute; right: 20px; bottom: -10px;
    font-size: 100px; opacity: .06; pointer-events: none;
}
.ticket-route {
    display: flex; align-items: center; gap: 20px;
    position: relative; z-index: 1;
}
.t-city {
    font-family: 'Syne', sans-serif;
    font-size: 30px; font-weight: 800; color: white;
}
.t-arrow {
    flex: 1; display: flex; flex-direction: column; align-items: center; gap: 6px;
}
.t-arrow .aline {
    width: 100%; height: 1.5px;
    background: linear-gradient(90deg, rgba(255,255,255,0.15), var(--cyan), rgba(255,255,255,0.15));
}
.t-arrow i { color: var(--cyan); font-size: 20px; }
.t-bus-tag {
    margin-top: 12px; position: relative; z-index: 1;
    display: flex; align-items: center; gap: 8px;
    color: rgba(255,255,255,0.55); font-size: 13px;
}
.t-bus-tag i { color: var(--cyan); }
.paid-badge {
    display: inline-flex; align-items: center; gap: 6px;
    background: rgba(0,196,140,0.2); border: 1px solid rgba(0,196,140,0.4);
    color: #4dffc0; font-size: 12px; font-weight: 700;
    padding: 4px 12px; border-radius: 50px; margin-left: auto;
}

/* Tear */
.tear-row { display: flex; align-items: center; background: var(--light); }
.tear-circle { width: 28px; height: 28px; border-radius: 50%; background: var(--light); flex-shrink: 0; }
.tear-circle.l { margin-left: -14px; }
.tear-circle.r { margin-right: -14px; }
.tear-dash { flex: 1; border-top: 2.5px dashed #c8d3eb; }

/* Body */
.ticket-body { padding: 28px 32px; }

.info-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 18px;
    margin-bottom: 24px;
}
.info-cell { }
.info-cell-label {
    font-size: 11px; font-weight: 700;
    text-transform: uppercase; letter-spacing: 1px;
    color: #a0aabf; margin-bottom: 5px;
    display: flex; align-items: center; gap: 5px;
}
.info-cell-value {
    font-family: 'Syne', sans-serif;
    font-size: 16px; font-weight: 700; color: var(--navy);
}

/* Seat chips */
.seat-chips { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 4px; }
.seat-chip {
    background: #e8f0ff; border: 1.5px solid #c0d0ff;
    color: var(--blue);
    font-family: 'Syne', sans-serif;
    font-size: 13px; font-weight: 700;
    padding: 5px 14px; border-radius: 8px;
}

/* Amount box */
.amount-box {
    background: linear-gradient(135deg, #f0f7ff, #e4edff);
    border: 1.5px solid #cddcff;
    border-radius: 16px;
    padding: 20px 24px;
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 28px;
}
.amount-label { font-size: 14px; color: #6b7a99; }
.amount-label strong { display: block; color: var(--navy); font-family: 'Syne', sans-serif; font-size: 13px; margin-top: 3px; }
.amount-val {
    font-family: 'Syne', sans-serif;
    font-size: 34px; font-weight: 800; color: var(--green);
}

/* Barcode strip */
.barcode-strip {
    text-align: center; margin-bottom: 24px;
    padding: 16px;
    border: 1.5px dashed #dde4f2;
    border-radius: 12px;
    background: #fafbff;
}
.barcode-bars {
    display: flex; justify-content: center; align-items: flex-end;
    gap: 2px; height: 48px; margin-bottom: 8px;
}
.barcode-bars span {
    display: inline-block;
    width: 3px; background: var(--navy);
    border-radius: 2px;
}
.barcode-num { font-size: 12px; color: #8a94a6; letter-spacing: 3px; font-family: monospace; }

/* Action buttons */
.action-row { display: flex; gap: 12px; flex-wrap: wrap; }
.btn-print {
    flex: 1;
    background: var(--navy); color: white;
    border: none; padding: 16px;
    border-radius: 14px;
    font-family: 'Syne', sans-serif; font-size: 15px; font-weight: 700;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center; gap: 8px;
    transition: background .2s, transform .2s;
    text-decoration: none;
}
.btn-print:hover { background: #1a3560; transform: translateY(-2px); color: white; }

.btn-home {
    flex: 1;
    background: var(--white); color: var(--navy);
    border: 2px solid #dde4f2;
    padding: 16px; border-radius: 14px;
    font-family: 'Syne', sans-serif; font-size: 15px; font-weight: 700;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center; gap: 8px;
    transition: all .2s;
    text-decoration: none;
}
.btn-home:hover { border-color: var(--blue); color: var(--blue); background: #f0f7ff; }

/* Success toast */
.toast-msg {
    position: fixed; top: 24px; right: 24px;
    background: var(--green); color: white;
    font-family: 'Syne', sans-serif; font-size: 14px; font-weight: 700;
    padding: 14px 22px; border-radius: 14px;
    display: flex; align-items: center; gap: 10px;
    box-shadow: 0 8px 28px rgba(0,196,140,0.4);
    animation: slideIn .4s ease both, fadeOut .4s 3s ease forwards;
    z-index: 9999;
}

/* Animations */
@keyframes popIn {
    from { opacity: 0; transform: scale(.75); }
    to   { opacity: 1; transform: scale(1); }
}
@keyframes fadeUp {
    from { opacity: 0; transform: translateY(24px); }
    to   { opacity: 1; transform: translateY(0); }
}
@keyframes pulseRing {
    0%, 100% { box-shadow: 0 0 0 14px rgba(0,196,140,0.1), 0 0 0 28px rgba(0,196,140,0.05); }
    50%       { box-shadow: 0 0 0 18px rgba(0,196,140,0.15), 0 0 0 36px rgba(0,196,140,0.07); }
}
@keyframes slideIn {
    from { opacity: 0; transform: translateX(40px); }
    to   { opacity: 1; transform: translateX(0); }
}
@keyframes fadeOut {
    to { opacity: 0; transform: translateX(40px); }
}

@media print {
    .action-row, .status-bar, .toast-msg, nav, footer { display: none !important; }
    body { background: white; }
    .ticket-wrap { box-shadow: none; }
    .confirm-page { padding: 0; }
}

@media (max-width: 500px) {
    .info-grid { grid-template-columns: 1fr; }
    .t-city { font-size: 24px; }
    .ticket-top, .ticket-body { padding: 20px; }
    .action-row { flex-direction: column; }
}
</style>

<!-- Toast notification -->
<div class="toast-msg"><i class="fas fa-circle-check"></i> Payment Successful!</div>

<div class="confirm-page">

    <!-- SUCCESS HEADER -->
    <div class="success-header">
        <div class="checkmark-ring"><i class="fas fa-check"></i></div>
        <h2>Booking Confirmed!</h2>
        <p>Your seats are reserved. E-ticket is ready below.</p>
        <div class="bid-pill" onclick="copyBookingId(this)" title="Click to copy">
            <i class="fas fa-ticket"></i>
            <span id="bidText"><?php echo $booking_id; ?></span>
            <span class="bid-copy">tap to copy</span>
        </div>
    </div>

    <!-- STATUS STEPS -->
    <div class="status-bar">
        <div class="status-step">
            <div class="status-dot done"><i class="fas fa-magnifying-glass"></i></div>
            <div class="status-label done-l">Searched</div>
        </div>
        <div class="status-connector"></div>
        <div class="status-step">
            <div class="status-dot done"><i class="fas fa-chair"></i></div>
            <div class="status-label done-l">Seat Chosen</div>
        </div>
        <div class="status-connector"></div>
        <div class="status-step">
            <div class="status-dot done"><i class="fas fa-credit-card"></i></div>
            <div class="status-label done-l">Paid</div>
        </div>
        <div class="status-connector pending"></div>
        <div class="status-step">
            <div class="status-dot now"><i class="fas fa-ticket"></i></div>
            <div class="status-label active">E-Ticket</div>
        </div>
    </div>

    <!-- TICKET -->
    <div class="ticket-wrap">

        <!-- Route header -->
        <div class="ticket-top">
            <div class="ticket-route">
                <div class="t-city"><?php echo htmlspecialchars($from); ?></div>
                <div class="t-arrow">
                    <div class="aline"></div>
                    <i class="fas fa-bus"></i>
                    <div class="aline"></div>
                </div>
                <div class="t-city"><?php echo htmlspecialchars($to); ?></div>
            </div>
            <div class="t-bus-tag">
                <i class="fas fa-circle-check"></i>
                <?php echo htmlspecialchars($bus); ?>
                <span class="paid-badge ms-auto"><i class="fas fa-lock"></i> PAID</span>
            </div>
        </div>

        <!-- Tear line -->
        <div class="tear-row">
            <div class="tear-circle l"></div>
            <div class="tear-dash"></div>
            <div class="tear-circle r"></div>
        </div>

        <!-- Body -->
        <div class="ticket-body">

            <div class="info-grid">
                <div class="info-cell">
                    <div class="info-cell-label"><i class="fas fa-hashtag"></i> Booking ID</div>
                    <div class="info-cell-value"><?php echo $booking_id; ?></div>
                </div>
                <div class="info-cell">
                    <div class="info-cell-label"><i class="fas fa-calendar"></i> Journey Date</div>
                    <div class="info-cell-value"><?php echo $formatted_date; ?></div>
                </div>
                <div class="info-cell">
                    <div class="info-cell-label"><i class="fas fa-user"></i> Passenger</div>
                    <div class="info-cell-value"><?php echo htmlspecialchars($passenger_name); ?></div>
                </div>
                <div class="info-cell">
                    <div class="info-cell-label"><i class="fas fa-users"></i> Passengers</div>
                    <div class="info-cell-value"><?php echo $totalSeats; ?> Passenger<?php echo $totalSeats > 1 ? 's' : ''; ?></div>
                </div>
                <div class="info-cell">
                    <div class="info-cell-label"><i class="fas fa-clock"></i> Booked At</div>
                    <div class="info-cell-value"><?php echo $time_now; ?>, <?php echo $booked_on; ?></div>
                </div>
                <div class="info-cell">
                    <div class="info-cell-label"><i class="fas fa-shield-halved"></i> Status</div>
                    <div class="info-cell-value" style="color:var(--green);">✅ Confirmed</div>
                </div>
                <div class="info-cell" style="grid-column: 1 / -1;">
                    <div class="info-cell-label"><i class="fas fa-chair"></i> Seat<?php echo $totalSeats > 1 ? 's' : ''; ?> Reserved</div>
                    <div class="seat-chips">
                        <?php foreach($seatArray as $s): ?>
                            <span class="seat-chip"><?php echo htmlspecialchars(trim($s)); ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Amount -->
            <div class="amount-box">
                <div class="amount-label">
                    Total Paid
                    <strong><?php echo $totalSeats; ?> seat<?php echo $totalSeats > 1 ? 's' : ''; ?> — All inclusive</strong>
                </div>
                <div class="amount-val">₹<?php echo number_format((float)$total); ?></div>
            </div>

            <!-- Barcode -->
            <div class="barcode-strip">
                <div class="barcode-bars">
                    <?php
                    $heights = [48,32,40,48,24,36,48,28,44,48,32,40,24,48,36,28,44,48,32,40,48,24];
                    foreach($heights as $h): ?>
                        <span style="height:<?php echo $h; ?>px"></span>
                    <?php endforeach; ?>
                </div>
                <div class="barcode-num"><?php echo $booking_id; ?>-<?php echo strtoupper(substr(md5($booking_id), 0, 8)); ?></div>
            </div>

            <!-- Buttons -->
            <div class="action-row">
                <button onclick="window.print()" class="btn-print">
                    <i class="fas fa-print"></i> Print Ticket
                </button>
                <a href="../index.php" class="btn-home">
                    <i class="fas fa-house"></i> Back to Home
                </a>
            </div>

        </div>
    </div>

</div>

<script>
function copyBookingId(el) {
    const id = document.getElementById('bidText').textContent;
    navigator.clipboard.writeText(id).then(() => {
        const copy = el.querySelector('.bid-copy');
        copy.textContent = '✓ copied!';
        setTimeout(() => copy.textContent = 'tap to copy', 2000);
    });
}
</script>

<?php include("../includes/footer.php"); ?>