<?php
session_start();
include("../config/config.php");
include("../includes/header.php");

/* -------------------------------
   GET BOOKING DATA
--------------------------------*/
$bus         = $_GET['bus']   ?? 'Express Bus';
$from        = $_GET['from']  ?? 'City A';
$to          = $_GET['to']    ?? 'City B';
$date        = $_GET['date']  ?? date('Y-m-d');
$seats       = $_GET['seats'] ?? 'A1';
$price       = $_GET['price'] ?? 800;

$seatArray   = explode(",", $seats);
$totalSeats  = count($seatArray);
$totalAmount = $totalSeats * $price;
$booking_id  = "BK" . rand(100000, 999999);
$formatted_date = date("D, d M Y", strtotime($date));
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --navy:  #0b1f3a;
    --blue:  #1a5cff;
    --cyan:  #00d4ff;
    --green: #00c48c;
    --gold:  #f5a623;
    --light: #f0f4ff;
    --white: #ffffff;
}

body {
    font-family: 'DM Sans', sans-serif;
    background: var(--light);
    min-height: 100vh;
}

/* ── PAGE WRAPPER ── */
.confirm-page {
    padding: 48px 20px 80px;
    max-width: 680px;
    margin: 0 auto;
}

/* ── SUCCESS HEADER ── */
.success-header {
    text-align: center;
    margin-bottom: 32px;
    animation: popIn .5s cubic-bezier(.175,.885,.32,1.275) both;
}
.success-ring {
    width: 90px; height: 90px;
    background: linear-gradient(135deg, #e6fff6, #b2f5e1);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 20px;
    box-shadow: 0 0 0 12px rgba(0,196,140,0.1);
    font-size: 40px;
}
.success-header h2 {
    font-family: 'Syne', sans-serif;
    font-size: 30px; font-weight: 800;
    color: var(--navy); margin-bottom: 6px;
}
.success-header p { color: #6b7a99; font-size: 15px; }

/* ── BOOKING ID BADGE ── */
.booking-id-badge {
    display: inline-flex; align-items: center; gap: 10px;
    background: var(--navy);
    color: var(--cyan);
    font-family: 'Syne', sans-serif;
    font-size: 15px; font-weight: 700;
    padding: 10px 24px;
    border-radius: 50px;
    margin-bottom: 28px;
    letter-spacing: 1px;
}
.booking-id-badge i { font-size: 13px; color: rgba(0,212,255,0.6); }

/* ── TICKET CARD ── */
.ticket-card {
    background: var(--white);
    border-radius: 24px;
    box-shadow: 0 20px 60px rgba(11,31,58,0.12);
    overflow: hidden;
    animation: fadeUp .5s .1s ease both;
}

.ticket-header {
    background: linear-gradient(135deg, var(--navy), #1a3560);
    padding: 28px 32px;
    position: relative; overflow: hidden;
}
.ticket-header::after {
    content: '🚌';
    position: absolute; right: 24px; top: 50%;
    transform: translateY(-50%);
    font-size: 72px; opacity: 0.07;
}
.ticket-route {
    display: flex; align-items: center; gap: 16px;
}
.route-city {
    font-family: 'Syne', sans-serif;
    font-size: 28px; font-weight: 800; color: var(--white);
}
.route-arrow {
    flex: 1;
    display: flex; flex-direction: column; align-items: center; gap: 4px;
}
.route-arrow .line {
    width: 100%; height: 2px;
    background: linear-gradient(90deg, rgba(255,255,255,0.2), var(--cyan), rgba(255,255,255,0.2));
}
.route-arrow i { color: var(--cyan); font-size: 18px; }
.route-bus-name {
    color: rgba(255,255,255,0.55);
    font-size: 13px; margin-top: 8px;
    display: flex; align-items: center; gap: 6px;
}
.route-bus-name i { color: var(--cyan); }

/* Tear line */
.tear-line {
    display: flex; align-items: center;
    background: var(--light);
}
.tear-circle {
    width: 28px; height: 28px;
    background: var(--light);
    border-radius: 50%;
    flex-shrink: 0;
}
.tear-circle.left  { margin-left: -14px; }
.tear-circle.right { margin-right: -14px; }
.tear-dashes {
    flex: 1; border: none;
    border-top: 2.5px dashed #c8d3eb;
    margin: 0 4px;
}

/* Ticket body */
.ticket-body { padding: 28px 32px; }

.detail-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-bottom: 24px;
}
.detail-item { }
.detail-label {
    font-size: 11px; font-weight: 700;
    text-transform: uppercase; letter-spacing: 1px;
    color: #8a94a6; margin-bottom: 4px;
}
.detail-value {
    font-family: 'Syne', sans-serif;
    font-size: 16px; font-weight: 700;
    color: var(--navy);
}
.detail-value.highlight { color: var(--green); font-size: 20px; }

/* Seat chips */
.seat-chips { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 4px; }
.seat-chip {
    background: var(--light);
    border: 1.5px solid #c8d3eb;
    color: var(--blue);
    font-family: 'Syne', sans-serif;
    font-size: 13px; font-weight: 700;
    padding: 4px 12px; border-radius: 8px;
}

/* Total row */
.total-row {
    background: linear-gradient(135deg, #f0f7ff, #e8f0ff);
    border-radius: 14px;
    padding: 18px 22px;
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 28px;
    border: 1.5px solid #d0e0ff;
}
.total-label {
    font-size: 14px; color: #6b7a99; font-weight: 500;
}
.total-label strong {
    display: block;
    font-family: 'Syne', sans-serif;
    font-size: 13px; color: var(--navy);
    margin-top: 2px;
}
.total-amount {
    font-family: 'Syne', sans-serif;
    font-size: 32px; font-weight: 800;
    color: var(--blue);
}

/* Action buttons */
.action-btns { display: flex; flex-direction: column; gap: 12px; }

.btn-pay {
    background: linear-gradient(135deg, var(--green), #00a87a);
    color: white; border: none;
    padding: 18px; border-radius: 14px;
    font-family: 'Syne', sans-serif;
    font-size: 17px; font-weight: 700;
    cursor: pointer; width: 100%;
    display: flex; align-items: center; justify-content: center; gap: 10px;
    transition: transform .2s, box-shadow .2s;
    box-shadow: 0 8px 24px rgba(0,196,140,0.35);
    text-decoration: none;
}
.btn-pay:hover {
    transform: translateY(-3px);
    box-shadow: 0 14px 36px rgba(0,196,140,0.45);
    color: white;
}

.btn-home {
    background: var(--white);
    color: var(--navy); border: 2px solid #dde4f2;
    padding: 15px; border-radius: 14px;
    font-family: 'Syne', sans-serif;
    font-size: 15px; font-weight: 600;
    cursor: pointer; width: 100%;
    display: flex; align-items: center; justify-content: center; gap: 10px;
    transition: border-color .2s, background .2s, color .2s;
    text-decoration: none;
}
.btn-home:hover {
    border-color: var(--blue);
    color: var(--blue);
    background: #f0f7ff;
}

/* ── NOTICE ── */
.notice-bar {
    display: flex; align-items: center; gap: 12px;
    background: #fffbf0;
    border: 1.5px solid #ffe5a0;
    border-radius: 12px;
    padding: 14px 18px;
    margin-top: 20px;
    font-size: 13px; color: #7a5c00;
}
.notice-bar i { color: var(--gold); font-size: 18px; flex-shrink: 0; }

/* ── ANIMATIONS ── */
@keyframes popIn {
    from { opacity: 0; transform: scale(.8); }
    to   { opacity: 1; transform: scale(1); }
}
@keyframes fadeUp {
    from { opacity: 0; transform: translateY(24px); }
    to   { opacity: 1; transform: translateY(0); }
}

/* ── PRINT ── */
@media print {
    .action-btns, .notice-bar, nav, footer { display: none !important; }
    .ticket-card { box-shadow: none; }
    body { background: white; }
}

@media (max-width: 500px) {
    .detail-grid { grid-template-columns: 1fr; gap: 16px; }
    .route-city { font-size: 22px; }
    .ticket-body, .ticket-header { padding: 20px; }
}
</style>

<div class="confirm-page">

    <!-- SUCCESS HEADER -->
    <div class="success-header">
        <div class="success-ring">✅</div>
        <h2>Booking Confirmed!</h2>
        <p>Your seat is reserved. Complete payment to get your e-ticket.</p>
        <div class="booking-id-badge">
            <i class="fas fa-ticket"></i>
            <?php echo $booking_id; ?>
        </div>
    </div>

    <!-- TICKET CARD -->
    <div class="ticket-card">

        <!-- Route Header -->
        <div class="ticket-header">
            <div class="ticket-route">
                <div>
                    <div class="route-city"><?php echo htmlspecialchars($from); ?></div>
                </div>
                <div class="route-arrow">
                    <div class="line"></div>
                    <i class="fas fa-bus"></i>
                    <div class="line"></div>
                </div>
                <div style="text-align:right">
                    <div class="route-city"><?php echo htmlspecialchars($to); ?></div>
                </div>
            </div>
            <div class="route-bus-name">
                <i class="fas fa-circle-check"></i>
                <?php echo htmlspecialchars($bus); ?>
            </div>
        </div>

        <!-- Tear Line -->
        <div class="tear-line">
            <div class="tear-circle left"></div>
            <div class="tear-dashes"></div>
            <div class="tear-circle right"></div>
        </div>

        <!-- Ticket Body -->
        <div class="ticket-body">

            <div class="detail-grid">
                <div class="detail-item">
                    <div class="detail-label"><i class="fas fa-calendar-alt"></i> Journey Date</div>
                    <div class="detail-value"><?php echo $formatted_date; ?></div>
                </div>
                <div class="detail-item">
                    <div class="detail-label"><i class="fas fa-users"></i> Passengers</div>
                    <div class="detail-value"><?php echo $totalSeats; ?> Passenger<?php echo $totalSeats > 1 ? 's' : ''; ?></div>
                </div>
                <div class="detail-item" style="grid-column: 1 / -1;">
                    <div class="detail-label"><i class="fas fa-chair"></i> Seat<?php echo $totalSeats > 1 ? 's' : ''; ?></div>
                    <div class="seat-chips">
                        <?php foreach($seatArray as $s): ?>
                            <span class="seat-chip"><?php echo htmlspecialchars(trim($s)); ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="detail-item">
                    <div class="detail-label"><i class="fas fa-tag"></i> Price per Seat</div>
                    <div class="detail-value">₹<?php echo number_format($price); ?></div>
                </div>
                <div class="detail-item">
                    <div class="detail-label"><i class="fas fa-layer-group"></i> Booking Status</div>
                    <div class="detail-value" style="color: var(--gold);">⏳ Pending Payment</div>
                </div>
            </div>

            <!-- Total -->
            <div class="total-row">
                <div class="total-label">
                    Total Amount
                    <strong><?php echo $totalSeats; ?> seat<?php echo $totalSeats > 1 ? 's' : ''; ?> × ₹<?php echo number_format($price); ?></strong>
                </div>
                <div class="total-amount">₹<?php echo number_format($totalAmount); ?></div>
            </div>

            <!-- Buttons -->
            <div class="action-btns">
                <a href="payment.php?bus=<?php echo urlencode($bus); ?>&from=<?php echo urlencode($from); ?>&to=<?php echo urlencode($to); ?>&date=<?php echo urlencode($date); ?>&seats=<?php echo urlencode($seats); ?>&price=<?php echo $price; ?>&booking_id=<?php echo $booking_id; ?>" class="btn-pay">
                    <i class="fas fa-credit-card"></i>
                    Pay Now — ₹<?php echo number_format($totalAmount); ?>
                </a>
                <a href="../index.php" class="btn-home">
                    <i class="fas fa-house"></i> Back to Home
                </a>
            </div>

            <!-- Notice -->
            <div class="notice-bar">
                <i class="fas fa-triangle-exclamation"></i>
                <span>Your seat is held for <strong>10 minutes</strong>. Please complete payment before the timer expires to confirm your booking.</span>
            </div>

        </div>
    </div>

</div>

<?php include("../includes/footer.php"); ?>