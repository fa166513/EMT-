<?php
session_start();
include("../includes/header.php");

$username = $_SESSION['username'] ?? "Guest";
$email    = $_SESSION['email']    ?? "guest@etrans.com";

// Sample booking data (replace with DB query)
$bookings = [
    ["id"=>"BK102341","from"=>"Kuala Lumpur","to"=>"Penang",      "seats"=>2,"date"=>"2026-02-20","status"=>"Confirmed","amount"=>1600,"bus"=>"AC Sleeper - TN Express"],
    ["id"=>"BK458217","from"=>"Penang",       "to"=>"Ipoh",        "seats"=>1,"date"=>"2026-03-05","status"=>"Confirmed","amount"=>600, "bus"=>"Semi Sleeper - KSRTC"],
    ["id"=>"BK774832","from"=>"KL",           "to"=>"Johor Bahru", "seats"=>3,"date"=>"2026-03-20","status"=>"Pending",  "amount"=>2400,"bus"=>"Volvo Multi-Axle - VRL"],
];

$total_bookings = count($bookings);
$total_spent    = array_sum(array_column($bookings, 'amount'));
$total_seats    = array_sum(array_column($bookings, 'seats'));
$confirmed      = count(array_filter($bookings, fn($b) => $b['status'] === 'Confirmed'));
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --navy:  #0b1f3a;
    --blue:  #1a5cff;
    --cyan:  #00d4ff;
    --green: #00c48c;
    --gold:  #f5a623;
    --red:   #ff4d6d;
    --light: #f0f4ff;
    --white: #ffffff;
}
body { font-family: 'DM Sans', sans-serif; background: var(--light); }

/* ── LAYOUT ── */
.dash-wrap {
    display: grid;
    grid-template-columns: 260px 1fr;
    min-height: calc(100vh - 60px);
}

/* ── SIDEBAR ── */
.dash-sidebar {
    background: var(--navy);
    padding: 32px 20px;
    position: sticky; top: 0;
    height: 100vh;
    display: flex; flex-direction: column;
    gap: 6px;
}
.sidebar-logo {
    font-family: 'Syne', sans-serif;
    font-size: 22px; font-weight: 800;
    color: white; margin-bottom: 28px;
    padding: 0 8px;
}
.sidebar-logo span { color: var(--cyan); }

.sidebar-avatar {
    display: flex; align-items: center; gap: 12px;
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 14px;
    padding: 14px 16px;
    margin-bottom: 24px;
}
.avatar-circle {
    width: 42px; height: 42px;
    background: linear-gradient(135deg, var(--blue), var(--cyan));
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-family: 'Syne', sans-serif;
    font-size: 17px; font-weight: 800; color: white;
    flex-shrink: 0;
}
.avatar-info { overflow: hidden; }
.avatar-name {
    font-family: 'Syne', sans-serif;
    font-size: 14px; font-weight: 700; color: white;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.avatar-email { font-size: 11px; color: rgba(255,255,255,0.45); }

.nav-section-label {
    font-size: 10px; font-weight: 700; letter-spacing: 1.5px;
    text-transform: uppercase; color: rgba(255,255,255,0.3);
    padding: 12px 12px 6px;
}
.nav-item {
    display: flex; align-items: center; gap: 12px;
    padding: 12px 16px; border-radius: 12px;
    color: rgba(255,255,255,0.6);
    font-size: 14px; font-weight: 500;
    text-decoration: none;
    transition: all .2s; cursor: pointer;
}
.nav-item:hover { background: rgba(255,255,255,0.07); color: white; }
.nav-item.active {
    background: rgba(26,92,255,0.25);
    border: 1px solid rgba(26,92,255,0.4);
    color: white;
}
.nav-item.active i { color: var(--cyan); }
.nav-item i { width: 18px; text-align: center; font-size: 15px; color: rgba(255,255,255,0.4); }

.sidebar-logout {
    margin-top: auto;
    display: flex; align-items: center; gap: 10px;
    padding: 12px 16px; border-radius: 12px;
    color: rgba(255,100,120,0.8);
    font-size: 14px; font-weight: 500;
    cursor: pointer; text-decoration: none;
    transition: background .2s;
}
.sidebar-logout:hover { background: rgba(255,77,109,0.1); color: var(--red); }
.sidebar-logout i { font-size: 15px; }

/* ── MAIN CONTENT ── */
.dash-main { padding: 36px 36px 60px; overflow-y: auto; }

/* Top bar */
.dash-topbar {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 32px; flex-wrap: wrap; gap: 16px;
}
.dash-title {
    font-family: 'Syne', sans-serif;
    font-size: 26px; font-weight: 800; color: var(--navy);
}
.dash-date { font-size: 14px; color: #8a94a6; margin-top: 2px; }
.btn-new-booking {
    background: linear-gradient(135deg, var(--blue), #3a7bff);
    color: white; border: none;
    padding: 12px 24px; border-radius: 50px;
    font-family: 'Syne', sans-serif;
    font-size: 14px; font-weight: 700;
    text-decoration: none;
    display: inline-flex; align-items: center; gap: 8px;
    box-shadow: 0 6px 20px rgba(26,92,255,0.3);
    transition: transform .2s, box-shadow .2s;
}
.btn-new-booking:hover { transform: translateY(-2px); box-shadow: 0 10px 28px rgba(26,92,255,0.4); color: white; }

/* ── STAT CARDS ── */
.stats-row {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 18px; margin-bottom: 32px;
}
.stat-card {
    background: var(--white);
    border-radius: 18px;
    padding: 22px 22px;
    border: 1.5px solid #edf0f8;
    transition: transform .2s, box-shadow .2s;
    animation: fadeUp .4s ease both;
}
.stat-card:hover { transform: translateY(-4px); box-shadow: 0 16px 40px rgba(11,31,58,0.09); }
.stat-icon {
    width: 48px; height: 48px; border-radius: 14px;
    display: flex; align-items: center; justify-content: center;
    font-size: 22px; margin-bottom: 16px;
}
.icon-blue  { background: #e8f0ff; }
.icon-green { background: #e0fff5; }
.icon-gold  { background: #fff5e0; }
.icon-red   { background: #fff0f3; }
.stat-num {
    font-family: 'Syne', sans-serif;
    font-size: 28px; font-weight: 800; color: var(--navy);
    margin-bottom: 4px;
}
.stat-lbl { font-size: 13px; color: #8a94a6; }

/* ── BOOKINGS TABLE SECTION ── */
.section-card {
    background: var(--white);
    border-radius: 20px;
    border: 1.5px solid #edf0f8;
    overflow: hidden;
    margin-bottom: 24px;
    animation: fadeUp .4s .1s ease both;
}
.section-head {
    padding: 20px 26px;
    display: flex; align-items: center; justify-content: space-between;
    border-bottom: 1.5px solid #f0f4ff;
}
.section-head h5 {
    font-family: 'Syne', sans-serif;
    font-size: 17px; font-weight: 700; color: var(--navy);
    margin: 0; display: flex; align-items: center; gap: 10px;
}
.section-head h5 i { color: var(--blue); }
.filter-tabs { display: flex; gap: 6px; }
.tab-btn {
    background: var(--light); border: none;
    color: #6b7a99; font-size: 12px; font-weight: 600;
    padding: 6px 14px; border-radius: 50px;
    cursor: pointer; transition: all .2s;
}
.tab-btn.active { background: var(--blue); color: white; }

/* Table */
.booking-table { width: 100%; border-collapse: collapse; }
.booking-table th {
    background: #f8faff;
    font-size: 11px; font-weight: 700;
    text-transform: uppercase; letter-spacing: 1px;
    color: #8a94a6; padding: 14px 20px;
    border-bottom: 1.5px solid #f0f4ff;
    text-align: left;
}
.booking-table td {
    padding: 16px 20px;
    border-bottom: 1.5px solid #f8faff;
    font-size: 14px; color: var(--navy);
    vertical-align: middle;
}
.booking-table tr:last-child td { border-bottom: none; }
.booking-table tr:hover td { background: #fafbff; }

.bid-code {
    font-family: 'Syne', sans-serif;
    font-size: 14px; font-weight: 700; color: var(--blue);
}
.route-cell { }
.route-from-to {
    font-weight: 600; color: var(--navy); font-size: 14px;
    display: flex; align-items: center; gap: 6px;
}
.route-bus-sub { font-size: 12px; color: #8a94a6; margin-top: 2px; }
.route-arrow-small { color: var(--blue); font-size: 12px; }

.status-pill {
    display: inline-flex; align-items: center; gap: 5px;
    font-size: 12px; font-weight: 700;
    padding: 5px 12px; border-radius: 50px;
}
.status-confirmed { background: #e0fff5; color: var(--green); }
.status-pending   { background: #fff5e0; color: var(--gold); }
.status-cancelled { background: #fff0f3; color: var(--red); }

.amount-cell {
    font-family: 'Syne', sans-serif;
    font-weight: 700; font-size: 15px; color: var(--navy);
}

.btn-view {
    background: var(--light); color: var(--blue);
    border: 1.5px solid #d0deff;
    padding: 6px 14px; border-radius: 8px;
    font-size: 12px; font-weight: 600;
    text-decoration: none; cursor: pointer;
    transition: all .2s;
    white-space: nowrap;
}
.btn-view:hover { background: var(--blue); color: white; border-color: var(--blue); }

/* ── QUICK ACTIONS ── */
.quick-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px; margin-bottom: 24px;
    animation: fadeUp .4s .15s ease both;
}
.quick-card {
    background: var(--white);
    border: 1.5px solid #edf0f8;
    border-radius: 18px;
    padding: 22px;
    text-align: center;
    text-decoration: none;
    transition: transform .2s, box-shadow .2s;
    display: flex; flex-direction: column; align-items: center; gap: 10px;
}
.quick-card:hover { transform: translateY(-4px); box-shadow: 0 16px 40px rgba(11,31,58,0.09); border-color: #d0e0ff; }
.quick-icon { font-size: 28px; }
.quick-label {
    font-family: 'Syne', sans-serif;
    font-size: 14px; font-weight: 700; color: var(--navy);
}
.quick-sub { font-size: 12px; color: #8a94a6; }

/* Empty state */
.empty-state {
    text-align: center; padding: 50px 20px;
}
.empty-state .empty-icon { font-size: 56px; margin-bottom: 14px; }
.empty-state h5 {
    font-family: 'Syne', sans-serif;
    font-size: 18px; font-weight: 700; color: var(--navy); margin-bottom: 8px;
}
.empty-state p { color: #8a94a6; font-size: 14px; }

@keyframes fadeUp {
    from { opacity: 0; transform: translateY(18px); }
    to   { opacity: 1; transform: translateY(0); }
}

@media (max-width: 900px) {
    .dash-wrap { grid-template-columns: 1fr; }
    .dash-sidebar { display: none; }
    .stats-row { grid-template-columns: 1fr 1fr; }
    .quick-grid { grid-template-columns: 1fr 1fr; }
    .dash-main { padding: 24px 16px 60px; }
}
@media (max-width: 500px) {
    .stats-row { grid-template-columns: 1fr; }
    .quick-grid { grid-template-columns: 1fr; }
}
</style>

<div class="dash-wrap">

    <!-- ── SIDEBAR ── -->
    <aside class="dash-sidebar">
        <div class="sidebar-logo">E<span>Trans</span></div>

        <div class="sidebar-avatar">
            <div class="avatar-circle"><?php echo strtoupper(substr($username, 0, 1)); ?></div>
            <div class="avatar-info">
                <div class="avatar-name"><?php echo htmlspecialchars($username); ?></div>
                <div class="avatar-email"><?php echo htmlspecialchars($email); ?></div>
            </div>
        </div>

        <div class="nav-section-label">Main</div>
        <a class="nav-item active" href="dashboard.php">
            <i class="fas fa-gauge-high"></i> Dashboard
        </a>
        <a class="nav-item" href="#">
            <i class="fas fa-ticket"></i> My Bookings
        </a>
        <a class="nav-item" href="../index.php">
            <i class="fas fa-magnifying-glass"></i> Search Buses
        </a>

        <div class="nav-section-label">Account</div>
        <a class="nav-item" href="#">
            <i class="fas fa-user"></i> Profile
        </a>
        <a class="nav-item" href="#">
            <i class="fas fa-bell"></i> Notifications
            <span style="margin-left:auto; background:var(--red); color:white; font-size:10px; font-weight:700; padding:2px 7px; border-radius:50px;">2</span>
        </a>
        <a class="nav-item" href="#">
            <i class="fas fa-gear"></i> Settings
        </a>

        <a class="sidebar-logout" href="../auth/logout.php">
            <i class="fas fa-right-from-bracket"></i> Logout
        </a>
    </aside>

    <!-- ── MAIN ── -->
    <main class="dash-main">

        <!-- Top bar -->
        <div class="dash-topbar">
            <div>
                <div class="dash-title">Welcome back, <?php echo htmlspecialchars($username); ?> 👋</div>
                <div class="dash-date"><?php echo date("l, d F Y"); ?></div>
            </div>
            <a href="../index.php" class="btn-new-booking">
                <i class="fas fa-plus"></i> New Booking
            </a>
        </div>

        <!-- Stats -->
        <div class="stats-row">
            <div class="stat-card" style="animation-delay:.0s">
                <div class="stat-icon icon-blue">🎫</div>
                <div class="stat-num"><?php echo $total_bookings; ?></div>
                <div class="stat-lbl">Total Bookings</div>
            </div>
            <div class="stat-card" style="animation-delay:.1s">
                <div class="stat-icon icon-green">✅</div>
                <div class="stat-num"><?php echo $confirmed; ?></div>
                <div class="stat-lbl">Confirmed</div>
            </div>
            <div class="stat-card" style="animation-delay:.2s">
                <div class="stat-icon icon-gold">💺</div>
                <div class="stat-num"><?php echo $total_seats; ?></div>
                <div class="stat-lbl">Seats Booked</div>
            </div>
            <div class="stat-card" style="animation-delay:.3s">
                <div class="stat-icon icon-red">💰</div>
                <div class="stat-num">₹<?php echo number_format($total_spent); ?></div>
                <div class="stat-lbl">Total Spent</div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-grid">
            <a class="quick-card" href="../index.php">
                <div class="quick-icon">🔍</div>
                <div class="quick-label">Search Buses</div>
                <div class="quick-sub">Find & book a route</div>
            </a>
            <a class="quick-card" href="#">
                <div class="quick-icon">📋</div>
                <div class="quick-label">My Tickets</div>
                <div class="quick-sub">View all e-tickets</div>
            </a>
            <a class="quick-card" href="#">
                <div class="quick-icon">⚙️</div>
                <div class="quick-label">Account Settings</div>
                <div class="quick-sub">Update your profile</div>
            </a>
        </div>

        <!-- Bookings Table -->
        <div class="section-card">
            <div class="section-head">
                <h5><i class="fas fa-list"></i> My Bookings</h5>
                <div class="filter-tabs">
                    <button class="tab-btn active">All</button>
                    <button class="tab-btn">Confirmed</button>
                    <button class="tab-btn">Pending</button>
                </div>
            </div>

            <?php if(!empty($bookings)): ?>
            <table class="booking-table">
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Route</th>
                        <th>Date</th>
                        <th>Seats</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($bookings as $i => $b):
                        $statusClass = match($b['status']) {
                            'Confirmed' => 'status-confirmed',
                            'Pending'   => 'status-pending',
                            default     => 'status-cancelled',
                        };
                        $statusIcon = match($b['status']) {
                            'Confirmed' => '✅',
                            'Pending'   => '⏳',
                            default     => '❌',
                        };
                        $fmt_date = date("d M Y", strtotime($b['date']));
                    ?>
                    <tr style="animation: fadeUp .3s <?php echo $i*0.07; ?>s ease both;">
                        <td><span class="bid-code"><?php echo $b['id']; ?></span></td>
                        <td class="route-cell">
                            <div class="route-from-to">
                                <?php echo htmlspecialchars($b['from']); ?>
                                <i class="fas fa-arrow-right route-arrow-small"></i>
                                <?php echo htmlspecialchars($b['to']); ?>
                            </div>
                            <div class="route-bus-sub"><?php echo htmlspecialchars($b['bus']); ?></div>
                        </td>
                        <td><?php echo $fmt_date; ?></td>
                        <td><?php echo $b['seats']; ?> seat<?php echo $b['seats'] > 1 ? 's' : ''; ?></td>
                        <td class="amount-cell">₹<?php echo number_format($b['amount']); ?></td>
                        <td>
                            <span class="status-pill <?php echo $statusClass; ?>">
                                <?php echo $statusIcon; ?> <?php echo $b['status']; ?>
                            </span>
                        </td>
                        <td>
                            <a href="booking-confirmation.php?bus=<?php echo urlencode($b['bus']); ?>&from=<?php echo urlencode($b['from']); ?>&to=<?php echo urlencode($b['to']); ?>&date=<?php echo urlencode($b['date']); ?>&price=<?php echo $b['amount']/$b['seats']; ?>&seats=A1" class="btn-view">
                                View <i class="fas fa-arrow-right" style="font-size:10px"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">🎫</div>
                <h5>No Bookings Yet</h5>
                <p>You haven't made any bookings. Start by searching for a bus!</p>
                <a href="../index.php" class="btn-new-booking mt-3" style="display:inline-flex">Search Buses</a>
            </div>
            <?php endif; ?>
        </div>

    </main>
</div>

<script>
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
    });
});
</script>

<?php include("../includes/footer.php"); ?>