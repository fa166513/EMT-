<?php
session_start();
include("../includes/header.php");

$bus   = $_GET['bus']   ?? 'Express Bus';
$from  = $_GET['from']  ?? 'City A';
$to    = $_GET['to']    ?? 'City B';
$date  = $_GET['date']  ?? date('Y-m-d');
$price = $_GET['price'] ?? 800;

$formatted_date = date("D, d M Y", strtotime($date));

// Simulate already-taken seats (replace with DB query)
$taken_seats = ['A2','A3','B1','C3','D2','E1','E3','F2','G1','H3','I2','J1','K2','L3','M1','N2','P3','Q1'];
$taken_json  = json_encode($taken_seats);
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --navy:  #0b1f3a;
    --blue:  #1a5cff;
    --cyan:  #00d4ff;
    --green: #00c48c;
    --gold:  #f5a623;
    --red:   #ff4d6d;
    --light: #f0f4ff;
    --white: #ffffff;
}
body { font-family: 'DM Sans', sans-serif; background: var(--light); }

/* ── TOP BANNER ── */
.seat-banner {
    background: var(--navy);
    padding: 28px 40px;
    position: relative; overflow: hidden;
}
.seat-banner::before {
    content: '';
    position: absolute; inset: 0;
    background-image: radial-gradient(circle, rgba(0,212,255,0.08) 1px, transparent 1px);
    background-size: 28px 28px;
    pointer-events: none;
}
.seat-banner-inner {
    max-width: 1100px; margin: 0 auto;
    display: flex; align-items: center; justify-content: space-between;
    flex-wrap: wrap; gap: 16px;
    position: relative; z-index: 1;
}
.banner-route {
    display: flex; align-items: center; gap: 14px;
}
.banner-city {
    font-family: 'Syne', sans-serif;
    font-size: 26px; font-weight: 800; color: white;
}
.banner-arrow { color: var(--cyan); font-size: 20px; }
.banner-meta {
    display: flex; gap: 14px; margin-top: 8px; flex-wrap: wrap;
}
.banner-pill {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.14);
    color: rgba(255,255,255,0.7);
    font-size: 12px; padding: 5px 14px;
    border-radius: 50px;
    display: flex; align-items: center; gap: 6px;
}
.banner-pill i { color: var(--cyan); }
.btn-back {
    background: rgba(255,255,255,0.1);
    border: 1.5px solid rgba(255,255,255,0.2);
    color: white; padding: 10px 20px;
    border-radius: 50px; font-size: 13px; font-weight: 600;
    text-decoration: none;
    display: inline-flex; align-items: center; gap: 8px;
    transition: background .2s;
}
.btn-back:hover { background: rgba(255,255,255,0.18); color: white; }

/* ── LAYOUT ── */
.seat-layout {
    max-width: 1100px; margin: 32px auto 80px;
    padding: 0 20px;
    display: grid;
    grid-template-columns: 1fr 340px;
    gap: 28px;
    align-items: start;
}

/* ── BUS BODY ── */
.bus-card {
    background: var(--white);
    border-radius: 24px;
    border: 1.5px solid #edf0f8;
    overflow: hidden;
    box-shadow: 0 8px 32px rgba(11,31,58,0.08);
}
.bus-card-header {
    background: linear-gradient(90deg, var(--blue), #3a7bff);
    padding: 16px 24px;
    display: flex; align-items: center; justify-content: space-between;
}
.bus-card-header h6 {
    font-family: 'Syne', sans-serif;
    font-size: 15px; font-weight: 700; color: white; margin: 0;
    display: flex; align-items: center; gap: 8px;
}

/* Legend */
.legend {
    display: flex; gap: 20px; align-items: center; flex-wrap: wrap;
}
.legend-item {
    display: flex; align-items: center; gap: 6px;
    font-size: 12px; color: rgba(255,255,255,0.8);
}
.legend-dot {
    width: 22px; height: 22px; border-radius: 6px;
    display: flex; align-items: center; justify-content: center;
    font-size: 9px; font-weight: 700;
}
.ld-free   { background: rgba(255,255,255,0.2); border: 1.5px solid rgba(255,255,255,0.4); color: rgba(255,255,255,0.8); }
.ld-taken  { background: rgba(255,255,255,0.08); color: rgba(255,255,255,0.3); }
.ld-yours  { background: var(--green); color: white; }

/* Bus interior */
.bus-interior {
    padding: 24px 32px 28px;
}

/* Driver area */
.driver-area {
    display: flex; align-items: center; gap: 12px;
    margin-bottom: 24px; padding-bottom: 18px;
    border-bottom: 2px dashed #e0e8f8;
}
.driver-wheel {
    width: 56px; height: 56px;
    border-radius: 50%;
    border: 4px solid #dde4f2;
    display: flex; align-items: center; justify-content: center;
    font-size: 24px; color: #8a94a6;
    margin-left: auto;
}
.driver-label { font-size: 11px; color: #a0aabf; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }
.front-label {
    font-size: 11px; font-weight: 700; letter-spacing: 2px;
    text-transform: uppercase; color: #a0aabf;
}

/* Seat grid — 2+1 layout */
.seat-rows { display: flex; flex-direction: column; gap: 10px; }

.seat-row {
    display: flex;
    align-items: center;
    gap: 6px;
}
.row-num {
    font-size: 11px; color: #c0cadf; font-weight: 600;
    width: 20px; text-align: right; flex-shrink: 0;
    margin-right: 4px;
}
.seat-group-left  { display: flex; gap: 6px; }
.seat-aisle       { width: 28px; flex-shrink: 0; }
.seat-group-right { display: flex; gap: 6px; }

/* Individual seat */
.seat {
    width: 46px; height: 46px;
    border-radius: 10px 10px 8px 8px;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    cursor: pointer;
    font-size: 11px; font-weight: 700;
    position: relative;
    transition: transform .15s, box-shadow .15s;
    user-select: none;
    border: 2px solid transparent;
}
/* Seat back detail */
.seat::before {
    content: '';
    position: absolute; top: 0; left: 4px; right: 4px;
    height: 8px; border-radius: 4px 4px 0 0;
    background: rgba(0,0,0,0.08);
}
.seat-label { margin-top: 6px; font-size: 10px; }

/* States */
.seat.free {
    background: #f0f4ff;
    border-color: #c8d3f0;
    color: #4a6299;
}
.seat.free:hover {
    background: #dce6ff;
    border-color: var(--blue);
    transform: translateY(-3px);
    box-shadow: 0 6px 18px rgba(26,92,255,0.2);
    color: var(--blue);
}
.seat.taken {
    background: #f0f2f5;
    border-color: #dde0e8;
    color: #c0c8d8;
    cursor: not-allowed;
}
.seat.taken::after {
    content: '✕';
    position: absolute;
    font-size: 14px; color: #c0c8d8;
}
.seat.selected {
    background: linear-gradient(135deg, var(--green), #00a87a);
    border-color: var(--green);
    color: white;
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(0,196,140,0.35);
}
.seat.selected::before { background: rgba(255,255,255,0.15); }

/* ── SUMMARY PANEL ── */
.summary-panel {
    display: flex; flex-direction: column; gap: 20px;
}

.info-card {
    background: var(--white);
    border-radius: 20px;
    border: 1.5px solid #edf0f8;
    overflow: hidden;
    box-shadow: 0 4px 20px rgba(11,31,58,0.06);
}
.info-card-head {
    background: #f8faff;
    border-bottom: 1.5px solid #edf0f8;
    padding: 14px 20px;
    font-family: 'Syne', sans-serif;
    font-size: 14px; font-weight: 700; color: var(--navy);
    display: flex; align-items: center; gap: 8px;
}
.info-card-head i { color: var(--blue); }
.info-card-body { padding: 18px 20px; }

/* Journey info rows */
.info-row {
    display: flex; align-items: center; justify-content: space-between;
    padding: 10px 0;
    border-bottom: 1px solid #f4f6fc;
    font-size: 13px;
}
.info-row:last-child { border-bottom: none; padding-bottom: 0; }
.info-row-label { color: #8a94a6; display: flex; align-items: center; gap: 6px; }
.info-row-label i { color: var(--blue); font-size: 12px; width: 14px; }
.info-row-val { font-weight: 600; color: var(--navy); text-align: right; }

/* Selected seats display */
.selected-seats-display {
    min-height: 60px;
    display: flex; flex-wrap: wrap; gap: 8px;
    align-items: flex-start;
}
.sel-chip {
    background: linear-gradient(135deg, var(--green), #00a87a);
    color: white;
    font-family: 'Syne', sans-serif;
    font-size: 13px; font-weight: 700;
    padding: 6px 14px; border-radius: 8px;
    display: flex; align-items: center; gap: 6px;
    animation: popIn .2s ease both;
}
.sel-chip button {
    background: none; border: none; color: rgba(255,255,255,0.7);
    cursor: pointer; font-size: 14px; padding: 0; line-height: 1;
    transition: color .15s;
}
.sel-chip button:hover { color: white; }
.no-seat-msg {
    color: #b0bac8; font-size: 13px;
    width: 100%; text-align: center; padding: 12px 0;
}

/* Price breakdown */
.price-row {
    display: flex; justify-content: space-between;
    font-size: 13px; padding: 8px 0;
    border-bottom: 1px solid #f4f6fc;
}
.price-row:last-child { border: none; }
.price-row.total {
    font-family: 'Syne', sans-serif;
    font-size: 18px; font-weight: 800;
    color: var(--navy); margin-top: 4px;
}
.price-row.total .amt { color: var(--blue); }

/* Proceed button */
.btn-proceed {
    width: 100%;
    background: linear-gradient(135deg, var(--blue), #3a7bff);
    color: white; border: none;
    padding: 18px; border-radius: 14px;
    font-family: 'Syne', sans-serif;
    font-size: 16px; font-weight: 800;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center; gap: 10px;
    transition: transform .2s, box-shadow .2s, opacity .2s;
    box-shadow: 0 8px 24px rgba(26,92,255,0.35);
}
.btn-proceed:hover:not(:disabled) {
    transform: translateY(-3px);
    box-shadow: 0 14px 36px rgba(26,92,255,0.45);
}
.btn-proceed:disabled {
    opacity: .5; cursor: not-allowed;
    box-shadow: none; transform: none;
}

/* Availability bar */
.avail-bar-wrap {
    margin-top: 10px;
}
.avail-bar-label {
    display: flex; justify-content: space-between;
    font-size: 12px; color: #8a94a6; margin-bottom: 6px;
}
.avail-bar {
    height: 6px; background: #edf0f8;
    border-radius: 6px; overflow: hidden;
}
.avail-fill {
    height: 100%; border-radius: 6px;
    background: linear-gradient(90deg, var(--green), #00d4a0);
    transition: width .6s ease;
}

/* Animations */
@keyframes popIn {
    from { opacity: 0; transform: scale(.7); }
    to   { opacity: 1; transform: scale(1); }
}
@keyframes fadeUp {
    from { opacity: 0; transform: translateY(18px); }
    to   { opacity: 1; transform: translateY(0); }
}

@media (max-width: 900px) {
    .seat-layout { grid-template-columns: 1fr; }
    .summary-panel { order: -1; }
    .seat-banner { padding: 20px; }
    .banner-city { font-size: 20px; }
}
@media (max-width: 480px) {
    .bus-interior { padding: 16px; }
    .seat { width: 38px; height: 38px; }
    .seat-aisle { width: 16px; }
}
</style>

<!-- ── BANNER ── -->
<div class="seat-banner">
    <div class="seat-banner-inner">
        <div>
            <div class="banner-route">
                <div class="banner-city"><?php echo htmlspecialchars($from); ?></div>
                <div class="banner-arrow"><i class="fas fa-arrow-right-long"></i></div>
                <div class="banner-city"><?php echo htmlspecialchars($to); ?></div>
            </div>
            <div class="banner-meta">
                <div class="banner-pill"><i class="fas fa-bus"></i> <?php echo htmlspecialchars($bus); ?></div>
                <div class="banner-pill"><i class="fas fa-calendar"></i> <?php echo $formatted_date; ?></div>
                <div class="banner-pill"><i class="fas fa-tag"></i> ₹<?php echo number_format($price); ?> / seat</div>
            </div>
        </div>
        <a href="javascript:history.back()" class="btn-back">
            <i class="fas fa-arrow-left"></i> Back
        </a>
    </div>
</div>

<!-- ── MAIN ── -->
<div class="seat-layout">

    <!-- BUS SEAT MAP -->
    <div class="bus-card" style="animation: fadeUp .4s ease both;">
        <div class="bus-card-header">
            <h6><i class="fas fa-bus"></i> Select Your Seats — 2+1 Layout</h6>
            <div class="legend">
                <div class="legend-item"><div class="legend-dot ld-free">A</div> Available</div>
                <div class="legend-item"><div class="legend-dot ld-taken"></div> Taken</div>
                <div class="legend-item"><div class="legend-dot ld-yours">✓</div> Yours</div>
            </div>
        </div>

        <div class="bus-interior">
            <!-- Driver -->
            <div class="driver-area">
                <div class="front-label">🚪 Door</div>
                <div class="driver-wheel">🚌</div>
                <div class="driver-label">Driver</div>
            </div>

            <!-- Seat rows — 2+1 layout, 17 rows = 51 seats, we use 50 -->
            <div class="seat-rows" id="seatMap">
                <?php
                // 2+1 layout: Left = 2 seats (col A, B), Right = 1 seat (col C)
                // 17 rows × 3 = 51 → skip last seat to make 50
                $rows = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17'];
                $cols_left  = ['A','B'];
                $cols_right = ['C'];
                $count = 0;
                foreach($rows as $row):
                    echo '<div class="seat-row">';
                    echo '<div class="row-num">'.$row.'</div>';

                    // Left 2 seats
                    echo '<div class="seat-group-left">';
                    foreach($cols_left as $col):
                        $sid = $col.$row;
                        $count++;
                        if($count > 50) break;
                        $state = in_array($sid, $taken_seats) ? 'taken' : 'free';
                        echo "<div class='seat $state' data-seat='$sid' data-price='$price' onclick='toggleSeat(this)'>
                                <span class='seat-label'>$sid</span>
                              </div>";
                    endforeach;
                    echo '</div>';

                    // Aisle
                    echo '<div class="seat-aisle"></div>';

                    // Right 1 seat
                    echo '<div class="seat-group-right">';
                    foreach($cols_right as $col):
                        $sid = $col.$row;
                        $count++;
                        if($count > 50) break;
                        $state = in_array($sid, $taken_seats) ? 'taken' : 'free';
                        echo "<div class='seat $state' data-seat='$sid' data-price='$price' onclick='toggleSeat(this)'>
                                <span class='seat-label'>$sid</span>
                              </div>";
                    endforeach;
                    echo '</div>';

                    echo '</div>';
                endforeach;
                ?>
            </div>
        </div>
    </div>

    <!-- SUMMARY PANEL -->
    <div class="summary-panel">

        <!-- Journey Info -->
        <div class="info-card" style="animation: fadeUp .4s .1s ease both;">
            <div class="info-card-head"><i class="fas fa-route"></i> Journey Details</div>
            <div class="info-card-body">
                <div class="info-row">
                    <div class="info-row-label"><i class="fas fa-map-marker-alt"></i> From</div>
                    <div class="info-row-val"><?php echo htmlspecialchars($from); ?></div>
                </div>
                <div class="info-row">
                    <div class="info-row-label"><i class="fas fa-map-pin"></i> To</div>
                    <div class="info-row-val"><?php echo htmlspecialchars($to); ?></div>
                </div>
                <div class="info-row">
                    <div class="info-row-label"><i class="fas fa-calendar"></i> Date</div>
                    <div class="info-row-val"><?php echo $formatted_date; ?></div>
                </div>
                <div class="info-row">
                    <div class="info-row-label"><i class="fas fa-bus"></i> Bus</div>
                    <div class="info-row-val" style="font-size:12px; max-width:160px; text-align:right;"><?php echo htmlspecialchars($bus); ?></div>
                </div>

                <!-- Availability bar -->
                <?php
                $taken_count = count($taken_seats);
                $free_count  = 50 - $taken_count;
                $pct_free    = round(($free_count / 50) * 100);
                ?>
                <div class="avail-bar-wrap">
                    <div class="avail-bar-label">
                        <span><?php echo $free_count; ?> seats available</span>
                        <span><?php echo $taken_count; ?> taken</span>
                    </div>
                    <div class="avail-bar">
                        <div class="avail-fill" style="width:<?php echo $pct_free; ?>%"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Selected Seats -->
        <div class="info-card" style="animation: fadeUp .4s .15s ease both;">
            <div class="info-card-head"><i class="fas fa-chair"></i> Selected Seats <span id="seatCount" style="margin-left:auto; background:var(--blue); color:white; font-size:11px; padding:2px 10px; border-radius:50px;">0</span></div>
            <div class="info-card-body">
                <div class="selected-seats-display" id="selectedDisplay">
                    <div class="no-seat-msg">No seats selected yet.<br>Click on a seat to choose.</div>
                </div>
            </div>
        </div>

        <!-- Price Breakdown -->
        <div class="info-card" style="animation: fadeUp .4s .2s ease both;">
            <div class="info-card-head"><i class="fas fa-receipt"></i> Price Summary</div>
            <div class="info-card-body">
                <div class="price-row">
                    <span style="color:#8a94a6;">Price per seat</span>
                    <span>₹<?php echo number_format($price); ?></span>
                </div>
                <div class="price-row">
                    <span style="color:#8a94a6;">Seats selected</span>
                    <span id="seatsCountLabel">0</span>
                </div>
                <div class="price-row">
                    <span style="color:#8a94a6;">Convenience fee</span>
                    <span id="feeLabel">₹0</span>
                </div>
                <div class="price-row total">
                    <span>Total</span>
                    <span class="amt" id="totalLabel">₹0</span>
                </div>
            </div>
        </div>

        <!-- Proceed -->
        <div style="animation: fadeUp .4s .25s ease both;">
            <button class="btn-proceed" id="proceedBtn" disabled onclick="proceedToBooking()">
                <i class="fas fa-lock"></i>
                <span id="proceedLabel">Select a Seat to Continue</span>
            </button>
            <p style="text-align:center; font-size:12px; color:#a0aabf; margin-top:10px;">
                <i class="fas fa-shield-halved" style="color:var(--green)"></i>
                Secure booking — seats held for 10 minutes
            </p>
        </div>

    </div>
</div>

<script>
const PRICE      = <?php echo (int)$price; ?>;
const FEE_RATE   = 0.02; // 2% convenience fee
const MAX_SEATS  = 6;
const taken      = <?php echo $taken_json; ?>;

let selected = [];

function toggleSeat(el) {
    if (el.classList.contains('taken')) return;

    const sid = el.dataset.seat;

    if (el.classList.contains('selected')) {
        // Deselect
        el.classList.remove('selected');
        el.classList.add('free');
        selected = selected.filter(s => s !== sid);
    } else {
        if (selected.length >= MAX_SEATS) {
            showToast(`Max ${MAX_SEATS} seats per booking`, 'warn');
            return;
        }
        el.classList.remove('free');
        el.classList.add('selected');
        selected.push(sid);
    }

    updateSummary();
}

function updateSummary() {
    const count   = selected.length;
    const subtotal = count * PRICE;
    const fee      = Math.round(subtotal * FEE_RATE);
    const total    = subtotal + fee;

    // Count badge
    document.getElementById('seatCount').textContent = count;
    document.getElementById('seatsCountLabel').textContent = count;
    document.getElementById('feeLabel').textContent = '₹' + fee.toLocaleString();
    document.getElementById('totalLabel').textContent = '₹' + total.toLocaleString();

    // Chips display
    const display = document.getElementById('selectedDisplay');
    if (count === 0) {
        display.innerHTML = '<div class="no-seat-msg">No seats selected yet.<br>Click on a seat to choose.</div>';
    } else {
        display.innerHTML = selected.map(sid =>
            `<div class="sel-chip">
                ${sid}
                <button onclick="removeSeat('${sid}')" title="Remove">×</button>
             </div>`
        ).join('');
    }

    // Proceed button
    const btn = document.getElementById('proceedBtn');
    const lbl = document.getElementById('proceedLabel');
    if (count === 0) {
        btn.disabled = true;
        lbl.textContent = 'Select a Seat to Continue';
    } else {
        btn.disabled = false;
        lbl.textContent = `Book ${count} Seat${count>1?'s':''} — ₹${total.toLocaleString()}`;
    }
}

function removeSeat(sid) {
    const el = document.querySelector(`.seat[data-seat="${sid}"]`);
    if (el) { el.classList.remove('selected'); el.classList.add('free'); }
    selected = selected.filter(s => s !== sid);
    updateSummary();
}

function proceedToBooking() {
    if (!selected.length) return;

    const count    = selected.length;
    const subtotal = count * PRICE;
    const fee      = Math.round(subtotal * FEE_RATE);
    const total    = subtotal + fee;

    const params = new URLSearchParams({
        bus:   '<?php echo addslashes($bus); ?>',
        from:  '<?php echo addslashes($from); ?>',
        to:    '<?php echo addslashes($to); ?>',
        date:  '<?php echo $date; ?>',
        seats: selected.join(','),
        price: PRICE,
        total: total
    });

    window.location.href = 'booking-confirmation.php?' + params.toString();
}

// Toast helper
function showToast(msg, type = 'info') {
    const t = document.createElement('div');
    t.style.cssText = `
        position:fixed; top:24px; right:24px; z-index:9999;
        background:${type==='warn' ? '#f5a623' : '#1a5cff'};
        color:white; font-family:'Syne',sans-serif; font-weight:700;
        font-size:14px; padding:14px 22px; border-radius:14px;
        display:flex; align-items:center; gap:10px;
        box-shadow:0 8px 28px rgba(0,0,0,0.2);
        animation: slideIn .3s ease both;
    `;
    t.innerHTML = `<i class="fas fa-triangle-exclamation"></i> ${msg}`;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3000);
}
</script>

<?php include("../includes/footer.php"); ?>