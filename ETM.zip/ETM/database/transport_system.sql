-- ==========================================
-- E-TRANSPORT MANAGEMENT SYSTEM DATABASE
-- Version 2.0
-- ==========================================
-- LOGIN CREDENTIALS:
--   Admin  → username : admin
--             password : Admin@123
--
--   User 1 → email    : arjun@example.com
--             password : Password@123
--
--   User 2 → email    : priya@example.com
--             password : Password@123
-- ==========================================

CREATE DATABASE IF NOT EXISTS transport_system
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE transport_system;

-- ==========================================
-- USERS TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS users (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100)  NOT NULL,
    email        VARCHAR(120)  UNIQUE NOT NULL,
    password     VARCHAR(255)  NOT NULL,
    phone        VARCHAR(15)   DEFAULT NULL,
    gender       ENUM('male','female','other') DEFAULT NULL,
    role         ENUM('user','admin') DEFAULT 'user',
    is_active    TINYINT(1)    DEFAULT 1,
    created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==========================================
-- ADMINS TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS admins (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    username     VARCHAR(50)  UNIQUE NOT NULL,
    email        VARCHAR(120) UNIQUE NOT NULL,
    password     VARCHAR(255) NOT NULL,
    created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- ROUTES TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS routes (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    source       VARCHAR(100) NOT NULL,
    destination  VARCHAR(100) NOT NULL,
    distance_km  INT          DEFAULT NULL,
    duration_hrs DECIMAL(4,1) DEFAULT NULL,
    is_active    TINYINT(1)   DEFAULT 1,
    created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- BUSES TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS buses (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    bus_name       VARCHAR(120)  NOT NULL,
    bus_number     VARCHAR(20)   DEFAULT NULL,
    bus_type       ENUM('AC Sleeper','Semi Sleeper','Volvo AC','Non-AC') DEFAULT 'AC Sleeper',
    route_id       INT           NOT NULL,
    departure_time TIME          NOT NULL,
    arrival_time   TIME          NOT NULL,
    price          DECIMAL(10,2) NOT NULL,
    total_seats    INT           DEFAULT 40,
    amenities      VARCHAR(255)  DEFAULT NULL,
    is_active      TINYINT(1)    DEFAULT 1,
    created_at     TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE
);

-- ==========================================
-- SEATS TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS seats (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    bus_id      INT         NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    seat_type   ENUM('window','aisle','middle') DEFAULT 'window',
    status      ENUM('available','reserved','blocked') DEFAULT 'available',

    FOREIGN KEY (bus_id) REFERENCES buses(id) ON DELETE CASCADE,
    UNIQUE KEY unique_bus_seat (bus_id, seat_number)
);

-- ==========================================
-- BOOKINGS TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS bookings (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    booking_code    VARCHAR(20)   UNIQUE NOT NULL,
    user_id         INT           NOT NULL,
    bus_id          INT           NOT NULL,
    route_id        INT           NOT NULL,
    travel_date     DATE          NOT NULL,
    seats           VARCHAR(100)  NOT NULL,
    seat_count      INT           DEFAULT 1,
    price_per_seat  DECIMAL(10,2) NOT NULL,
    convenience_fee DECIMAL(10,2) DEFAULT 0.00,
    total_amount    DECIMAL(10,2) NOT NULL,
    payment_status  ENUM('pending','paid','failed','refunded') DEFAULT 'pending',
    booking_status  ENUM('confirmed','cancelled','completed')  DEFAULT 'confirmed',
    payment_method  VARCHAR(50)   DEFAULT NULL,
    booked_at       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id)  REFERENCES users(id)   ON DELETE CASCADE,
    FOREIGN KEY (bus_id)   REFERENCES buses(id)   ON DELETE CASCADE,
    FOREIGN KEY (route_id) REFERENCES routes(id)  ON DELETE CASCADE
);

-- ==========================================
-- PAYMENTS TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS payments (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    booking_id     INT           NOT NULL,
    user_id        INT           NOT NULL,
    amount         DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50)   DEFAULT 'Online',
    transaction_id VARCHAR(100)  DEFAULT NULL,
    status         ENUM('success','failed','pending','refunded') DEFAULT 'pending',
    paid_at        TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE
);

-- ==========================================
-- ROUTES DATA
-- ==========================================
INSERT INTO routes (source, destination, distance_km, duration_hrs) VALUES
('Kuala Lumpur', 'Penang',      367, 4.5),
('Kuala Lumpur', 'Johor Bahru', 330, 4.0),
('Kuala Lumpur', 'Ipoh',        205, 2.5),
('Kuala Lumpur', 'Melaka',      145, 2.0),
('Penang',       'Ipoh',        160, 2.3),
('Penang',       'Kuantan',     440, 5.5),
('Chennai',      'Bangalore',   350, 6.0),
('Mumbai',       'Pune',        150, 3.0);

-- ==========================================
-- BUSES DATA
-- ==========================================
INSERT INTO buses (bus_name, bus_number, bus_type, route_id, departure_time, arrival_time, price, total_seats, amenities) VALUES
('AC Sleeper - TN Express',  'TN-01-AB-1234', 'AC Sleeper',  7, '22:00:00', '05:00:00', 800.00, 32, 'WiFi,Charging,Blanket,Water'),
('Semi Sleeper - KSRTC',     'KA-02-CD-5678', 'Semi Sleeper',7, '23:00:00', '06:30:00', 600.00, 40, 'Charging,Water'),
('Volvo Multi-Axle - VRL',   'MH-03-EF-9012', 'Volvo AC',    8, '06:00:00', '09:30:00', 450.00, 36, 'WiFi,Charging,Blanket,Snacks,Water'),
('AC Sleeper - KL Penang',   'WA-04-GH-3456', 'AC Sleeper',  1, '22:30:00', '03:00:00', 120.00, 32, 'WiFi,Charging,Blanket,Water'),
('Semi Sleeper - KL Penang', 'WB-05-IJ-7890', 'Semi Sleeper',1, '23:00:00', '03:30:00',  90.00, 40, 'Charging,Water'),
('Volvo AC - KL JB Express', 'WC-06-KL-2345', 'Volvo AC',    2, '08:00:00', '12:00:00', 150.00, 36, 'WiFi,Charging,Blanket,Snacks,Water'),
('Non-AC Seater - KL Ipoh',  'WD-07-MN-6789', 'Non-AC',      3, '07:00:00', '09:30:00',  45.00, 50, 'Water'),
('AC Sleeper - KL Melaka',   'WE-08-OP-0123', 'AC Sleeper',  4, '09:00:00', '11:00:00',  60.00, 32, 'WiFi,Charging,Water');

-- ==========================================
-- ADMIN DATA
-- password stored as plain text here
-- auth/login.php will use password_verify()
-- when you register via PHP it will bcrypt automatically
-- ==========================================
INSERT INTO admins (username, email, password) VALUES
('admin', 'admin@etrans.com', 'Admin@123');

-- ==========================================
-- USERS DATA
-- passwords stored as plain text here
-- auth/register.php will bcrypt on real signups
-- ==========================================
INSERT INTO users (name, email, password, phone, gender, role) VALUES
('Arjun Kumar',  'arjun@example.com', 'Password@123', '9876543210', 'male',   'user'),
('Priya Sharma', 'priya@example.com', 'Password@123', '9123456789', 'female', 'user');

-- ==========================================
-- SAMPLE BOOKINGS
-- ==========================================
INSERT INTO bookings (booking_code, user_id, bus_id, route_id, travel_date, seats, seat_count, price_per_seat, convenience_fee, total_amount, payment_status, booking_status) VALUES
('BK102341', 1, 1, 7, '2026-02-20', 'A1,A2',    2, 800.00, 32.00, 1632.00, 'paid',    'confirmed'),
('BK458217', 1, 3, 8, '2026-03-05', 'B1',       1, 450.00,  9.00,  459.00, 'paid',    'confirmed'),
('BK774832', 2, 4, 1, '2026-03-20', 'C1,C2,C3', 3, 120.00,  7.20,  367.20, 'pending', 'confirmed');

-- ==========================================
-- VIEWS
-- ==========================================
CREATE OR REPLACE VIEW v_booking_details AS
SELECT
    b.id, b.booking_code, b.travel_date, b.seats, b.seat_count,
    b.total_amount, b.payment_status, b.booking_status, b.booked_at,
    u.name AS user_name, u.email AS user_email, u.phone AS user_phone,
    bs.bus_name, bs.bus_type, bs.departure_time, bs.arrival_time,
    r.source, r.destination, r.distance_km
FROM bookings b
JOIN users  u  ON b.user_id  = u.id
JOIN buses  bs ON b.bus_id   = bs.id
JOIN routes r  ON b.route_id = r.id;

CREATE OR REPLACE VIEW v_available_buses AS
SELECT
    bs.id, bs.bus_name, bs.bus_type, bs.departure_time, bs.arrival_time,
    bs.price, bs.total_seats, bs.amenities,
    r.source, r.destination, r.distance_km, r.duration_hrs,
    (bs.total_seats - COALESCE(
        (SELECT SUM(bk.seat_count) FROM bookings bk
         WHERE bk.bus_id = bs.id AND bk.booking_status = 'confirmed'), 0)
    ) AS available_seats
FROM buses bs
JOIN routes r ON bs.route_id = r.id
WHERE bs.is_active = 1;

-- ==========================================
-- INDEXES
-- ==========================================
CREATE INDEX idx_bookings_user      ON bookings(user_id);
CREATE INDEX idx_bookings_bus       ON bookings(bus_id);
CREATE INDEX idx_bookings_date      ON bookings(travel_date);
CREATE INDEX idx_bookings_code      ON bookings(booking_code);
CREATE INDEX idx_buses_route        ON buses(route_id);
CREATE INDEX idx_routes_source_dest ON routes(source, destination);
CREATE INDEX idx_seats_bus          ON seats(bus_id);