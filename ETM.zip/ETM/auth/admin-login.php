<?php
include("../config/config.php");

// Redirect if already logged in as admin
if(isset($_SESSION['user']) && $_SESSION['role'] === 'admin') {
    header("Location: ../admin/admin-dashboard.php");
    exit();
}

$error   = '';
$success = '';

if(isset($_GET['logout'])) {
    $success = 'You have been logged out successfully.';
}

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if(empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        $stmt = $conn->prepare("SELECT * FROM admins WHERE username = ? OR email = ? LIMIT 1");
        $stmt->bind_param("ss", $username, $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $admin  = $result->fetch_assoc();
        $stmt->close();

        if($admin) {
            $valid = false;
            if(password_verify($password, $admin['password'])) {
                $valid = true;
            } elseif($password === $admin['password']) {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $conn->query("UPDATE admins SET password='$hashed' WHERE id={$admin['id']}");
                $valid = true;
            }

            if($valid) {
                $_SESSION['user']    = $admin['name'];
                $_SESSION['user_id'] = $admin['id'];
                $_SESSION['email']   = $admin['email'];
                $_SESSION['role']    = 'admin';
                header("Location: ../admin/admin-dashboard.php");
                exit();
            } else {
                $error = 'Invalid username or password.';
            }
        } else {
            $error = 'No admin account found with those credentials.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Login — E-Transport Management System</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root{--navy:#0b1f3a;--blue:#1a5cff;--cyan:#00d4ff;--green:#00c48c;--gold:#f5a623;--red:#ff4d6d;--light:#f0f4ff;--white:#ffffff;}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--navy);min-height:100vh;display:flex;overflow:hidden;}

/* LEFT PANEL */
.left-panel{width:45%;background:var(--navy);display:flex;flex-direction:column;justify-content:center;align-items:center;padding:60px 50px;position:relative;overflow:hidden;}
.left-panel::before{content:'';position:absolute;inset:0;background-image:radial-gradient(circle,rgba(245,166,35,0.06) 1px,transparent 1px);background-size:28px 28px;pointer-events:none;}
.left-glow{position:absolute;width:500px;height:500px;background:radial-gradient(circle,rgba(245,166,35,0.15) 0%,transparent 70%);bottom:-100px;right:-100px;pointer-events:none;}
.left-content{position:relative;z-index:1;max-width:380px;}
.brand-logo{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;color:white;margin-bottom:8px;display:flex;align-items:center;gap:10px;text-decoration:none;}
.brand-logo .logo-icon{width:38px;height:38px;background:linear-gradient(135deg,var(--gold),#ffcc44);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;}
.brand-logo span{color:var(--gold);}
.brand-sub{font-size:11px;color:rgba(255,255,255,0.35);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:40px;margin-left:48px;}
.left-title{font-family:'Syne',sans-serif;font-size:32px;font-weight:800;color:white;line-height:1.2;margin-bottom:16px;}
.left-title em{font-style:normal;color:var(--gold);}
.left-sub{color:rgba(255,255,255,0.5);font-size:15px;line-height:1.7;margin-bottom:36px;}
.feature-list{display:flex;flex-direction:column;gap:16px;}
.feature-item{display:flex;align-items:center;gap:12px;}
.feature-icon{width:36px;height:36px;border-radius:10px;background:rgba(245,166,35,0.15);border:1px solid rgba(245,166,35,0.25);display:flex;align-items:center;justify-content:center;color:var(--gold);font-size:14px;flex-shrink:0;}
.feature-text{color:rgba(255,255,255,0.65);font-size:14px;}
.feature-text strong{color:white;display:block;font-size:14px;margin-bottom:2px;}
.back-link{display:inline-flex;align-items:center;gap:8px;margin-top:40px;color:rgba(255,255,255,0.4);font-size:13px;text-decoration:none;transition:color .2s;}
.back-link:hover{color:var(--cyan);}

/* RIGHT PANEL */
.right-panel{width:55%;background:var(--light);display:flex;flex-direction:column;justify-content:center;align-items:center;padding:60px 50px;overflow-y:auto;}
.login-card{background:var(--white);border-radius:24px;padding:44px 38px;width:100%;max-width:420px;box-shadow:0 20px 60px rgba(11,31,58,0.12);animation:fadeUp .5s ease both;}
.admin-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(245,166,35,0.12);border:1px solid rgba(245,166,35,0.3);color:var(--gold);font-size:11px;font-weight:700;padding:4px 12px;border-radius:50px;margin-bottom:20px;letter-spacing:.5px;}
.login-card h2{font-family:'Syne',sans-serif;font-size:26px;font-weight:800;color:var(--navy);margin-bottom:4px;}
.login-card .subtitle{color:#8a94a6;font-size:14px;margin-bottom:28px;}
.alert-box{border-radius:12px;padding:12px 16px;font-size:13px;font-weight:500;display:flex;align-items:center;gap:10px;margin-bottom:18px;}
.alert-error{background:#fff0f3;color:var(--red);border:1.5px solid #ffd0d8;}
.alert-success{background:#e6fff6;color:var(--green);border:1.5px solid #b2f5e1;}
.form-group{margin-bottom:18px;}
.form-group label{display:block;font-size:12px;font-weight:700;color:#6b7a99;margin-bottom:7px;text-transform:uppercase;letter-spacing:.7px;}
.input-wrap{position:relative;}
.input-wrap i.icon-left{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#a0aabf;font-size:14px;pointer-events:none;}
.input-wrap input{width:100%;height:52px;border:2px solid #e8edf5;border-radius:12px;padding:0 44px 0 42px;font-family:'DM Sans',sans-serif;font-size:14px;color:var(--navy);background:#f8faff;transition:border-color .2s,box-shadow .2s;outline:none;}
.input-wrap input:focus{border-color:var(--gold);box-shadow:0 0 0 4px rgba(245,166,35,0.12);background:var(--white);}
.toggle-pass{position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:#a0aabf;cursor:pointer;font-size:14px;padding:4px;transition:color .2s;}
.toggle-pass:hover{color:var(--gold);}
.btn-login{width:100%;height:54px;background:linear-gradient(135deg,var(--gold),#ffcc44);color:var(--navy);border:none;border-radius:12px;font-family:'Syne',sans-serif;font-size:16px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;transition:transform .2s,box-shadow .2s;box-shadow:0 8px 24px rgba(245,166,35,0.4);margin-top:8px;margin-bottom:20px;}
.btn-login:hover{transform:translateY(-2px);box-shadow:0 12px 32px rgba(245,166,35,0.5);}
.user-login-link{text-align:center;font-size:14px;color:#8a94a6;}
.user-login-link a{color:var(--blue);font-weight:700;text-decoration:none;}
.user-login-link a:hover{text-decoration:underline;}

@keyframes fadeUp{from{opacity:0;transform:translateY(20px);}to{opacity:1;transform:translateY(0);}}
@media(max-width:900px){.left-panel{display:none;}.right-panel{width:100%;padding:40px 20px;}body{overflow:auto;}}
</style>
</head>
<body>

<!-- LEFT PANEL -->
<div class="left-panel">
    <div class="left-glow"></div>
    <div class="left-content">
        <a href="../index.php" class="brand-logo">
            <div class="logo-icon">🚌</div>
            E-Transport <span>Mgmt</span>
        </a>
        <div class="brand-sub">E-Transport Management System</div>

        <h1 class="left-title">
            <em>Admin</em><br>Control Panel
        </h1>
        <p class="left-sub">
            Manage buses, routes, bookings and users from one powerful dashboard.
        </p>

        <div class="feature-list">
            <div class="feature-item">
                <div class="feature-icon"><i class="fas fa-gauge-high"></i></div>
                <div class="feature-text"><strong>Live Dashboard</strong>Real-time stats and booking overview</div>
            </div>
            <div class="feature-item">
                <div class="feature-icon"><i class="fas fa-bus"></i></div>
                <div class="feature-text"><strong>Fleet Management</strong>Add, edit and manage all buses</div>
            </div>
            <div class="feature-item">
                <div class="feature-icon"><i class="fas fa-route"></i></div>
                <div class="feature-text"><strong>Route Control</strong>Manage routes and schedules</div>
            </div>
            <div class="feature-item">
                <div class="feature-icon"><i class="fas fa-ticket"></i></div>
                <div class="feature-text"><strong>Booking Manager</strong>View and manage all bookings</div>
            </div>
        </div>

        <a href="../index.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to main site
        </a>
    </div>
</div>

<!-- RIGHT PANEL -->
<div class="right-panel">
    <div class="login-card">
        <div class="admin-badge"><i class="fas fa-shield-halved"></i> ADMIN ACCESS ONLY</div>
        <h2>Admin Login 🛡️</h2>
        <p class="subtitle">Enter your administrator credentials</p>

        <?php if($error): ?>
        <div class="alert-box alert-error"><i class="fas fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if($success): ?>
        <div class="alert-box alert-success"><i class="fas fa-circle-check"></i> <?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label>Username or Email</label>
                <div class="input-wrap">
                    <i class="fas fa-user icon-left"></i>
                    <input type="text" name="username" placeholder="admin"
                           value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label>Password</label>
                <div class="input-wrap">
                    <i class="fas fa-lock icon-left"></i>
                    <input type="password" name="password" id="passField" placeholder="••••••••" required>
                    <button type="button" class="toggle-pass" onclick="togglePass()">
                        <i class="fas fa-eye" id="eyeIcon"></i>
                    </button>
                </div>
            </div>

            <!-- Default Credentials Box -->
            <div style="background:#fffbea;border:1.5px dashed #f5a623;border-radius:12px;padding:12px 16px;margin-bottom:16px;font-size:13px;">
                <div style="font-weight:700;color:#b37700;margin-bottom:6px;display:flex;align-items:center;gap:6px;">
                    <i class="fas fa-key"></i> Default Credentials
                </div>
                <div style="display:flex;gap:20px;flex-wrap:wrap;">
                    <div>
                        <span style="color:#8a94a6;">Username:</span>
                        <strong style="color:#0b1f3a;margin-left:6px;cursor:pointer;" onclick="document.querySelector('[name=username]').value='admin'" title="Click to fill">
                            admin
                        </strong>
                    </div>
                    <div>
                        <span style="color:#8a94a6;">Password:</span>
                        <strong style="color:#0b1f3a;margin-left:6px;cursor:pointer;" onclick="document.getElementById('passField').value='Admin@123'" title="Click to fill">
                            Admin@123
                        </strong>
                    </div>
                </div>
                <div style="font-size:11px;color:#aaa;margin-top:6px;">💡 Click username or password above to auto-fill</div>
            </div>

            <button type="submit" class="btn-login">
                <i class="fas fa-shield-halved"></i> Login to Admin Panel
            </button>
        </form>

        <div class="user-login-link">
            Not an admin? <a href="login.php">User Login →</a>
        </div>
    </div>
</div>

<script>
function togglePass() {
    const f = document.getElementById('passField');
    const i = document.getElementById('eyeIcon');
    f.type = f.type === 'password' ? 'text' : 'password';
    i.className = f.type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
}
</script>
</body>
</html>