<?php
session_start();
include("../config/config.php");

// Redirect if already logged in
if(isset($_SESSION['user'])) {
    header("Location: ../user/dashboard.php");
    exit();
}

$error   = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name']     ?? '');
    $email    = trim($_POST['email']    ?? '');
    $phone    = trim($_POST['phone']    ?? '');
    $gender   = trim($_POST['gender']   ?? '');
    $password = trim($_POST['password'] ?? '');
    $confirm  = trim($_POST['confirm']  ?? '');

    // Validation
    if(empty($name) || empty($email) || empty($password) || empty($confirm)) {
        $error = 'Please fill in all required fields.';

    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';

    } elseif(strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';

    } elseif($password !== $confirm) {
        $error = 'Passwords do not match.';

    } else {
        // Check if email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if($stmt->num_rows > 0) {
            $error = 'An account with this email already exists.';
        } else {
            // Hash password and insert
            $hashed = password_hash($password, PASSWORD_BCRYPT);
            $stmt->close();

            $ins = $conn->prepare("INSERT INTO users (name, email, password, phone, gender) VALUES (?, ?, ?, ?, ?)");
            $ins->bind_param("sssss", $name, $email, $hashed, $phone, $gender);

            if($ins->execute()) {
                $success = 'Account created successfully! You can now log in.';
            } else {
                $error = 'Something went wrong. Please try again.';
            }
            $ins->close();
        }
        if(isset($stmt) && !$stmt->error) $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Register — E-Transport Management System</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --navy:  #0b1f3a;
    --blue:  #1a5cff;
    --cyan:  #00d4ff;
    --green: #00c48c;
    --red:   #ff4d6d;
    --gold:  #f5a623;
    --light: #f0f4ff;
    --white: #ffffff;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: 'DM Sans', sans-serif;
    background: var(--navy);
    min-height: 100vh;
    display: flex;
    overflow: hidden;
}

/* ── LEFT PANEL ── */
.left-panel {
    width: 45%;
    background: var(--navy);
    display: flex; flex-direction: column;
    justify-content: center; align-items: center;
    padding: 60px 50px;
    position: relative; overflow: hidden;
}
.left-panel::before {
    content: '';
    position: absolute; inset: 0;
    background-image: radial-gradient(circle, rgba(0,212,255,0.07) 1px, transparent 1px);
    background-size: 28px 28px;
    pointer-events: none;
}
.left-glow {
    position: absolute;
    width: 500px; height: 500px;
    background: radial-gradient(circle, rgba(26,92,255,0.2) 0%, transparent 70%);
    bottom: -100px; right: -100px;
    pointer-events: none;
}
.left-content { position: relative; z-index: 1; max-width: 380px; }

.brand-logo {
    font-family: 'Syne', sans-serif;
    font-size: 26px; font-weight: 800;
    color: white; margin-bottom: 44px;
    display: flex; align-items: center; gap: 10px;
    text-decoration: none;
}
.brand-logo .logo-icon {
    width: 38px; height: 38px;
    background: linear-gradient(135deg, var(--blue), var(--cyan));
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 18px;
}
.brand-logo span { color: var(--cyan); }

.left-title {
    font-family: 'Syne', sans-serif;
    font-size: 34px; font-weight: 800;
    color: white; line-height: 1.2;
    margin-bottom: 16px;
}
.left-title em { font-style: normal; color: var(--cyan); }
.left-sub {
    color: rgba(255,255,255,0.5);
    font-size: 15px; line-height: 1.7;
    margin-bottom: 36px;
}

/* Steps */
.steps { display: flex; flex-direction: column; gap: 18px; }
.step-item {
    display: flex; align-items: center; gap: 14px;
}
.step-num {
    width: 34px; height: 34px; border-radius: 50%;
    background: linear-gradient(135deg, var(--blue), #3a7bff);
    display: flex; align-items: center; justify-content: center;
    font-family: 'Syne', sans-serif;
    font-size: 14px; font-weight: 800; color: white;
    flex-shrink: 0;
    box-shadow: 0 4px 14px rgba(26,92,255,0.4);
}
.step-text { color: rgba(255,255,255,0.65); font-size: 14px; line-height: 1.5; }
.step-text strong { color: white; display: block; font-size: 14px; margin-bottom: 2px; }

/* Stats */
.stats-row {
    display: flex; gap: 24px; margin-top: 44px;
    padding-top: 32px;
    border-top: 1px solid rgba(255,255,255,0.08);
}
.stat-item { text-align: left; }
.stat-num {
    font-family: 'Syne', sans-serif;
    font-size: 24px; font-weight: 800; color: white;
}
.stat-num span { color: var(--cyan); }
.stat-lbl { font-size: 11px; color: rgba(255,255,255,0.4); text-transform: uppercase; letter-spacing: 1px; }

/* ── RIGHT PANEL ── */
.right-panel {
    width: 55%;
    background: var(--light);
    display: flex; flex-direction: column;
    justify-content: center; align-items: center;
    padding: 40px 50px;
    overflow-y: auto;
}

.register-card {
    background: var(--white);
    border-radius: 24px;
    padding: 40px 38px;
    width: 100%; max-width: 460px;
    box-shadow: 0 20px 60px rgba(11,31,58,0.12);
    animation: fadeUp .5s ease both;
}

.register-card h2 {
    font-family: 'Syne', sans-serif;
    font-size: 24px; font-weight: 800;
    color: var(--navy); margin-bottom: 4px;
}
.register-card .subtitle {
    color: #8a94a6; font-size: 14px; margin-bottom: 26px;
}

/* Alert */
.alert-box {
    border-radius: 12px; padding: 12px 16px;
    font-size: 13px; font-weight: 500;
    display: flex; align-items: center; gap: 10px;
    margin-bottom: 18px;
}
.alert-error   { background: #fff0f3; color: var(--red);   border: 1.5px solid #ffd0d8; }
.alert-success { background: #e6fff6; color: var(--green); border: 1.5px solid #b2f5e1; }

/* Form grid */
.form-row-2 {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}
.form-group { margin-bottom: 16px; }
.form-group label {
    display: block;
    font-size: 12px; font-weight: 700;
    color: #6b7a99; margin-bottom: 7px;
    text-transform: uppercase; letter-spacing: .7px;
}
.input-wrap { position: relative; }
.input-wrap i.icon-left {
    position: absolute; left: 14px; top: 50%;
    transform: translateY(-50%);
    color: #a0aabf; font-size: 14px;
    pointer-events: none;
}
.input-wrap input,
.input-wrap select {
    width: 100%; height: 50px;
    border: 2px solid #e8edf5;
    border-radius: 12px;
    padding: 0 14px 0 40px;
    font-family: 'DM Sans', sans-serif;
    font-size: 14px; color: var(--navy);
    background: #f8faff;
    transition: border-color .2s, box-shadow .2s, background .2s;
    outline: none;
    appearance: none;
}
.input-wrap input:focus,
.input-wrap select:focus {
    border-color: var(--blue);
    box-shadow: 0 0 0 4px rgba(26,92,255,0.1);
    background: var(--white);
}
.input-wrap input.error-input { border-color: var(--red); }

/* Password strength */
.strength-bar {
    height: 4px; border-radius: 4px;
    background: #edf0f8; margin-top: 8px;
    overflow: hidden;
}
.strength-fill {
    height: 100%; border-radius: 4px;
    width: 0%; transition: width .3s, background .3s;
}
.strength-label {
    font-size: 11px; margin-top: 4px;
    font-weight: 600; color: #a0aabf;
}

/* Toggle password */
.toggle-pass {
    position: absolute; right: 12px; top: 50%;
    transform: translateY(-50%);
    background: none; border: none;
    color: #a0aabf; cursor: pointer; font-size: 14px;
    padding: 4px; transition: color .2s;
}
.toggle-pass:hover { color: var(--blue); }

/* Terms */
.terms-wrap {
    display: flex; align-items: flex-start; gap: 10px;
    margin-bottom: 20px;
    font-size: 13px; color: #6b7a99;
}
.terms-wrap input { accent-color: var(--blue); width: 16px; height: 16px; margin-top: 2px; flex-shrink: 0; cursor: pointer; }
.terms-wrap a { color: var(--blue); text-decoration: none; font-weight: 600; }
.terms-wrap a:hover { text-decoration: underline; }

/* Submit */
.btn-register {
    width: 100%; height: 52px;
    background: linear-gradient(135deg, var(--blue), #3a7bff);
    color: white; border: none;
    border-radius: 12px;
    font-family: 'Syne', sans-serif;
    font-size: 16px; font-weight: 700;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center; gap: 10px;
    transition: transform .2s, box-shadow .2s;
    box-shadow: 0 8px 24px rgba(26,92,255,0.35);
    margin-bottom: 20px;
}
.btn-register:hover { transform: translateY(-2px); box-shadow: 0 12px 32px rgba(26,92,255,0.45); }

/* Login link */
.login-prompt {
    text-align: center;
    font-size: 14px; color: #8a94a6;
}
.login-prompt a {
    color: var(--blue); font-weight: 700; text-decoration: none;
}
.login-prompt a:hover { text-decoration: underline; }

@keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to   { opacity: 1; transform: translateY(0); }
}

@media (max-width: 900px) {
    .left-panel { display: none; }
    .right-panel { width: 100%; padding: 40px 20px; }
    body { overflow: auto; }
}
@media (max-width: 480px) {
    .form-row-2 { grid-template-columns: 1fr; }
    .register-card { padding: 28px 20px; }
}
</style>
</head>
<body>

<!-- ── LEFT PANEL ── -->
<div class="left-panel">
    <div class="left-glow"></div>
    <div class="left-content">

        <a href="../index.php" class="brand-logo">
            <div class="logo-icon">🚌</div>
            E-Transport <span>Mgmt</span>
        </a>

        <h1 class="left-title">
            Join <em>E-Transport</em><br>Travel Better
        </h1>
        <p class="left-sub">
            Create your free account in seconds and start booking bus tickets across hundreds of routes instantly.
        </p>

        <div class="steps">
            <div class="step-item">
                <div class="step-num">1</div>
                <div class="step-text">
                    <strong>Create your account</strong>
                    Fill in your details below — takes under a minute
                </div>
            </div>
            <div class="step-item">
                <div class="step-num">2</div>
                <div class="step-text">
                    <strong>Search your route</strong>
                    Find buses across hundreds of routes
                </div>
            </div>
            <div class="step-item">
                <div class="step-num">3</div>
                <div class="step-text">
                    <strong>Book & travel</strong>
                    Pick your seat and get your e-ticket instantly
                </div>
            </div>
        </div>

        <div class="stats-row">
            <div class="stat-item">
                <div class="stat-num">50K<span>+</span></div>
                <div class="stat-lbl">Users</div>
            </div>
            <div class="stat-item">
                <div class="stat-num">200<span>+</span></div>
                <div class="stat-lbl">Routes</div>
            </div>
            <div class="stat-item">
                <div class="stat-num">99<span>%</span></div>
                <div class="stat-lbl">Uptime</div>
            </div>
        </div>

    </div>
</div>

<!-- ── RIGHT PANEL ── -->
<div class="right-panel">
    <div class="register-card">

        <h2>Create Account 🚀</h2>
        <p class="subtitle">Start booking buses in under a minute</p>

        <!-- Alerts -->
        <?php if($error): ?>
        <div class="alert-box alert-error">
            <i class="fas fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
        </div>
        <?php endif; ?>

        <?php if($success): ?>
        <div class="alert-box alert-success">
            <i class="fas fa-circle-check"></i>
            <?php echo htmlspecialchars($success); ?>
            <a href="login.php" style="color:var(--green); font-weight:700; margin-left:6px;">Login now →</a>
        </div>
        <?php endif; ?>

        <form method="POST" action="" novalidate>

            <!-- Name & Phone -->
            <div class="form-row-2">
                <div class="form-group">
                    <label>Full Name <span style="color:var(--red)">*</span></label>
                    <div class="input-wrap">
                        <i class="fas fa-user icon-left"></i>
                        <input type="text" name="name"
                               placeholder="Your full name"
                               value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>"
                               required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Phone</label>
                    <div class="input-wrap">
                        <i class="fas fa-phone icon-left"></i>
                        <input type="tel" name="phone"
                               placeholder="+91 98765 43210"
                               value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
                    </div>
                </div>
            </div>

            <!-- Email -->
            <div class="form-group">
                <label>Email Address <span style="color:var(--red)">*</span></label>
                <div class="input-wrap">
                    <i class="fas fa-envelope icon-left"></i>
                    <input type="email" name="email"
                           placeholder="you@example.com"
                           value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                           required>
                </div>
            </div>

            <!-- Gender -->
            <div class="form-group">
                <label>Gender</label>
                <div class="input-wrap">
                    <i class="fas fa-venus-mars icon-left"></i>
                    <select name="gender">
                        <option value="">Select gender</option>
                        <option value="male"   <?php echo ($_POST['gender'] ?? '') === 'male'   ? 'selected' : ''; ?>>Male</option>
                        <option value="female" <?php echo ($_POST['gender'] ?? '') === 'female' ? 'selected' : ''; ?>>Female</option>
                        <option value="other"  <?php echo ($_POST['gender'] ?? '') === 'other'  ? 'selected' : ''; ?>>Other</option>
                    </select>
                </div>
            </div>

            <!-- Password -->
            <div class="form-group">
                <label>Password <span style="color:var(--red)">*</span></label>
                <div class="input-wrap">
                    <i class="fas fa-lock icon-left"></i>
                    <input type="password" name="password" id="passField"
                           placeholder="Min. 6 characters"
                           oninput="checkStrength(this.value)"
                           required>
                    <button type="button" class="toggle-pass" onclick="togglePass('passField','eyePass')">
                        <i class="fas fa-eye" id="eyePass"></i>
                    </button>
                </div>
                <div class="strength-bar"><div class="strength-fill" id="strengthFill"></div></div>
                <div class="strength-label" id="strengthLabel">Enter a password</div>
            </div>

            <!-- Confirm Password -->
            <div class="form-group">
                <label>Confirm Password <span style="color:var(--red)">*</span></label>
                <div class="input-wrap">
                    <i class="fas fa-lock icon-left"></i>
                    <input type="password" name="confirm" id="confirmField"
                           placeholder="Re-enter your password"
                           required>
                    <button type="button" class="toggle-pass" onclick="togglePass('confirmField','eyeConfirm')">
                        <i class="fas fa-eye" id="eyeConfirm"></i>
                    </button>
                </div>
            </div>

            <!-- Terms -->
            <div class="terms-wrap">
                <input type="checkbox" name="terms" id="terms" required>
                <label for="terms">
                    I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
                </label>
            </div>

            <button type="submit" class="btn-register">
                <i class="fas fa-user-plus"></i> Create My Account
            </button>

        </form>

        <div class="login-prompt">
            Already have an account? <a href="login.php">Sign in →</a>
        </div>

    </div>
</div>

<script>
function togglePass(fieldId, iconId) {
    const field = document.getElementById(fieldId);
    const icon  = document.getElementById(iconId);
    field.type  = field.type === 'password' ? 'text' : 'password';
    icon.className = field.type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
}

function checkStrength(val) {
    const fill  = document.getElementById('strengthFill');
    const label = document.getElementById('strengthLabel');
    let strength = 0;

    if(val.length >= 6)                        strength++;
    if(val.length >= 10)                       strength++;
    if(/[A-Z]/.test(val))                      strength++;
    if(/[0-9]/.test(val))                      strength++;
    if(/[^A-Za-z0-9]/.test(val))              strength++;

    const levels = [
        { pct: '0%',   color: '#edf0f8', text: 'Enter a password',  textColor: '#a0aabf' },
        { pct: '25%',  color: '#ff4d6d', text: 'Weak',              textColor: '#ff4d6d' },
        { pct: '50%',  color: '#f5a623', text: 'Fair',              textColor: '#f5a623' },
        { pct: '75%',  color: '#00d4ff', text: 'Good',              textColor: '#00d4ff' },
        { pct: '90%',  color: '#00c48c', text: 'Strong',            textColor: '#00c48c' },
        { pct: '100%', color: '#00c48c', text: '💪 Very Strong',    textColor: '#00c48c' },
    ];

    const lvl = levels[Math.min(strength, 5)];
    fill.style.width      = lvl.pct;
    fill.style.background = lvl.color;
    label.textContent     = lvl.text;
    label.style.color     = lvl.textColor;
}
</script>

</body>
</html>