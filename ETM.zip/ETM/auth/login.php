<?php
session_start();
include("../config/config.php");

// Redirect if already logged in
if(isset($_SESSION['user'])) {
    header("Location: ../user/dashboard.php");
    exit();
}

$error   = '';
$success = '';

// Show logout success message
if(isset($_GET['logout'])) {
    $success = 'You have been logged out successfully.';
}

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if(empty($email) || empty($password)) {
        $error = 'Please fill in all fields.';

    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';

    } else {
        // Check users table
        $stmt = $conn->prepare("SELECT id, name, email, password, role FROM users WHERE email = ? AND is_active = 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user   = $result->fetch_assoc();
        $stmt->close();

        if($user) {
            // Support both plain text (sample data) and bcrypt (registered users)
            $valid = password_verify($password, $user['password'])
                  || $password === $user['password'];

            if($valid) {
                // If plain text matched, upgrade to bcrypt now
                if($password === $user['password']) {
                    $new_hash = password_hash($password, PASSWORD_BCRYPT);
                    $upd = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $upd->bind_param("si", $new_hash, $user['id']);
                    $upd->execute();
                    $upd->close();
                }

                $_SESSION['user']    = $user['name'];
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['email']   = $user['email'];
                $_SESSION['role']    = $user['role'];

                header("Location: ../user/dashboard.php");
                exit();
            } else {
                $error = 'Incorrect password. Please try again.';
            }
        } else {
            $error = 'No account found with that email.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login — E-Transport Management System</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --navy:  #0b1f3a;
    --blue:  #1a5cff;
    --cyan:  #00d4ff;
    --green: #00c48c;
    --red:   #ff4d6d;
    --light: #f0f4ff;
    --white: #ffffff;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: 'DM Sans', sans-serif;
    background: var(--navy);
    min-height: 100vh;
    display: flex;
    overflow: hidden;
}

/* ── LEFT PANEL ── */
.left-panel {
    width: 50%;
    background: var(--navy);
    display: flex; flex-direction: column;
    justify-content: center; align-items: center;
    padding: 60px 50px;
    position: relative; overflow: hidden;
}
.left-panel::before {
    content: '';
    position: absolute; inset: 0;
    background-image: radial-gradient(circle, rgba(0,212,255,0.07) 1px, transparent 1px);
    background-size: 28px 28px;
    pointer-events: none;
}
.left-glow {
    position: absolute;
    width: 500px; height: 500px;
    background: radial-gradient(circle, rgba(26,92,255,0.2) 0%, transparent 70%);
    top: -100px; left: -100px;
    pointer-events: none;
}
.left-content { position: relative; z-index: 1; max-width: 420px; }

.brand-logo {
    font-family: 'Syne', sans-serif;
    font-size: 28px; font-weight: 800;
    color: white; margin-bottom: 48px;
    display: flex; align-items: center; gap: 10px;
    text-decoration: none;
}
.brand-logo .logo-icon {
    width: 40px; height: 40px;
    background: linear-gradient(135deg, var(--blue), var(--cyan));
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 20px;
}
.brand-logo span { color: var(--cyan); }

.left-title {
    font-family: 'Syne', sans-serif;
    font-size: 38px; font-weight: 800;
    color: white; line-height: 1.15;
    margin-bottom: 18px;
}
.left-title em { font-style: normal; color: var(--cyan); }
.left-sub {
    color: rgba(255,255,255,0.55);
    font-size: 16px; line-height: 1.7;
    margin-bottom: 40px;
}

/* Feature list */
.feature-list { display: flex; flex-direction: column; gap: 16px; }
.feature-item {
    display: flex; align-items: center; gap: 14px;
    color: rgba(255,255,255,0.7); font-size: 14px;
}
.feature-dot {
    width: 36px; height: 36px; border-radius: 10px;
    background: rgba(26,92,255,0.2);
    border: 1px solid rgba(26,92,255,0.3);
    display: flex; align-items: center; justify-content: center;
    font-size: 16px; flex-shrink: 0;
}

/* ── RIGHT PANEL ── */
.right-panel {
    width: 50%;
    background: var(--light);
    display: flex; flex-direction: column;
    justify-content: center; align-items: center;
    padding: 60px 50px;
}

.login-card {
    background: var(--white);
    border-radius: 24px;
    padding: 44px 40px;
    width: 100%; max-width: 420px;
    box-shadow: 0 20px 60px rgba(11,31,58,0.12);
    animation: fadeUp .5s ease both;
}

.login-card h2 {
    font-family: 'Syne', sans-serif;
    font-size: 26px; font-weight: 800;
    color: var(--navy); margin-bottom: 6px;
}
.login-card .subtitle {
    color: #8a94a6; font-size: 14px; margin-bottom: 30px;
}

/* Alert */
.alert-box {
    border-radius: 12px; padding: 12px 16px;
    font-size: 13px; font-weight: 500;
    display: flex; align-items: center; gap: 10px;
    margin-bottom: 20px;
}
.alert-error   { background: #fff0f3; color: var(--red);   border: 1.5px solid #ffd0d8; }
.alert-success { background: #e6fff6; color: var(--green); border: 1.5px solid #b2f5e1; }

/* Form */
.form-group { margin-bottom: 20px; }
.form-group label {
    display: block;
    font-size: 13px; font-weight: 600;
    color: #6b7a99; margin-bottom: 8px;
    text-transform: uppercase; letter-spacing: .7px;
}
.input-wrap {
    position: relative;
}
.input-wrap i {
    position: absolute; left: 16px; top: 50%;
    transform: translateY(-50%);
    color: #a0aabf; font-size: 15px;
    pointer-events: none;
}
.input-wrap input {
    width: 100%; height: 52px;
    border: 2px solid #e8edf5;
    border-radius: 12px;
    padding: 0 44px 0 44px;
    font-family: 'DM Sans', sans-serif;
    font-size: 15px; color: var(--navy);
    background: #f8faff;
    transition: border-color .2s, box-shadow .2s, background .2s;
    outline: none;
}
.input-wrap input:focus {
    border-color: var(--blue);
    box-shadow: 0 0 0 4px rgba(26,92,255,0.1);
    background: var(--white);
}
.input-wrap input.error-input { border-color: var(--red); }
.toggle-pass {
    position: absolute; right: 14px; top: 50%;
    transform: translateY(-50%);
    background: none; border: none;
    color: #a0aabf; cursor: pointer; font-size: 15px;
    padding: 4px;
    transition: color .2s;
}
.toggle-pass:hover { color: var(--blue); }

/* Remember / Forgot row */
.form-row {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 24px;
}
.remember-wrap {
    display: flex; align-items: center; gap: 8px;
    font-size: 13px; color: #6b7a99; cursor: pointer;
}
.remember-wrap input { accent-color: var(--blue); width: 16px; height: 16px; cursor: pointer; }
.forgot-link {
    font-size: 13px; color: var(--blue);
    text-decoration: none; font-weight: 600;
    transition: color .2s;
}
.forgot-link:hover { color: var(--cyan); }

/* Submit button */
.btn-login {
    width: 100%; height: 52px;
    background: linear-gradient(135deg, var(--blue), #3a7bff);
    color: white; border: none;
    border-radius: 12px;
    font-family: 'Syne', sans-serif;
    font-size: 16px; font-weight: 700;
    cursor: pointer;
    display: flex; align-items: center; justify-content: center; gap: 10px;
    transition: transform .2s, box-shadow .2s;
    box-shadow: 0 8px 24px rgba(26,92,255,0.35);
    margin-bottom: 24px;
}
.btn-login:hover { transform: translateY(-2px); box-shadow: 0 12px 32px rgba(26,92,255,0.45); }
.btn-login:active { transform: translateY(0); }

/* Divider */
.divider {
    display: flex; align-items: center; gap: 12px;
    margin-bottom: 20px; color: #c0cadc; font-size: 12px;
}
.divider::before, .divider::after {
    content: ''; flex: 1;
    height: 1.5px; background: #edf0f8;
}

/* Admin login link */
.admin-link {
    display: flex; align-items: center; justify-content: center; gap: 8px;
    background: #f8faff; border: 1.5px solid #dde4f2;
    border-radius: 12px; padding: 13px;
    color: var(--navy); font-size: 14px; font-weight: 600;
    text-decoration: none;
    transition: border-color .2s, background .2s;
    margin-bottom: 28px;
}
.admin-link:hover { border-color: var(--blue); background: #f0f4ff; color: var(--blue); }
.admin-link i { color: var(--blue); }

/* Register link */
.register-prompt {
    text-align: center;
    font-size: 14px; color: #8a94a6;
}
.register-prompt a {
    color: var(--blue); font-weight: 700;
    text-decoration: none;
}
.register-prompt a:hover { text-decoration: underline; }

@keyframes fadeUp {
    from { opacity: 0; transform: translateY(20px); }
    to   { opacity: 1; transform: translateY(0); }
}

@media (max-width: 768px) {
    body { flex-direction: column; overflow: auto; }
    .left-panel  { display: none; }
    .right-panel { width: 100%; padding: 40px 20px; min-height: 100vh; }
}
</style>
</head>
<body>

<!-- ── LEFT PANEL ── -->
<div class="left-panel">
    <div class="left-glow"></div>
    <div class="left-content">

        <a href="../index.php" class="brand-logo">
            <div class="logo-icon">🚌</div>
            E-Transport <span>Mgmt</span>
        </a>

        <h1 class="left-title">
            Travel Smarter,<br>Book <em>Faster</em>
        </h1>
        <p class="left-sub">
            Log in to access your bookings, manage trips, and get exclusive deals on bus routes across the country.
        </p>

        <div class="feature-list">
            <div class="feature-item">
                <div class="feature-dot">⚡</div>
                Real-time seat availability across all routes
            </div>
            <div class="feature-item">
                <div class="feature-dot">🎫</div>
                Instant e-ticket after booking confirmation
            </div>
            <div class="feature-item">
                <div class="feature-dot">🔒</div>
                Secure login and encrypted bookings
            </div>
            <div class="feature-item">
                <div class="feature-dot">📱</div>
                Access your dashboard from any device
            </div>
        </div>

    </div>
</div>

<!-- ── RIGHT PANEL ── -->
<div class="right-panel">
    <div class="login-card">

        <h2>Welcome Back 👋</h2>
        <p class="subtitle">Sign in to your account</p>

        <!-- Alerts -->
        <?php if($error): ?>
        <div class="alert-box alert-error">
            <i class="fas fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
        </div>
        <?php endif; ?>

        <?php if($success): ?>
        <div class="alert-box alert-success">
            <i class="fas fa-circle-check"></i> <?php echo htmlspecialchars($success); ?>
        </div>
        <?php endif; ?>

        <!-- Login Form -->
        <form method="POST" action="" novalidate>

            <div class="form-group">
                <label>Email Address</label>
                <div class="input-wrap">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email"
                           placeholder="you@example.com"
                           value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                           <?php echo $error ? 'class="error-input"' : ''; ?>
                           autocomplete="email" required>
                </div>
            </div>

            <div class="form-group">
                <label>Password</label>
                <div class="input-wrap">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password"
                           id="passwordField"
                           placeholder="Enter your password"
                           <?php echo $error ? 'class="error-input"' : ''; ?>
                           autocomplete="current-password" required>
                    <button type="button" class="toggle-pass" onclick="togglePassword()">
                        <i class="fas fa-eye" id="eyeIcon"></i>
                    </button>
                </div>
            </div>

            <div class="form-row">
                <label class="remember-wrap">
                    <input type="checkbox" name="remember"> Remember me
                </label>
                <a href="#" class="forgot-link">Forgot password?</a>
            </div>

            <button type="submit" class="btn-login">
                <i class="fas fa-right-to-bracket"></i> Sign In
            </button>

        </form>

        <div class="divider">or</div>

        <!-- Admin login -->
        <a href="admin-login.php" class="admin-link">
            <i class="fas fa-shield-halved"></i> Login as Administrator
        </a>

        <div class="register-prompt">
            Don't have an account?
            <a href="register.php">Create one free →</a>
        </div>

    </div>
</div>

<script>
function togglePassword() {
    const field = document.getElementById('passwordField');
    const icon  = document.getElementById('eyeIcon');
    if (field.type === 'password') {
        field.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        field.type = 'password';
        icon.className = 'fas fa-eye';
    }
}
</script>

</body>
</html>