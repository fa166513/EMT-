```php
<?php
// ============================================
//   E-Transport Management System
//   config/config.php — Database Connection
// ============================================

define('DB_HOST',     '127.0.0.1');
define('DB_USER',     'root');
define('DB_PASS',     '');           
define('DB_NAME',     'transport_system');
define('DB_PORT',     3307); // MySQL Port (change to 3307 if your MySQL uses that)

define('BASE_URL',    'http://localhost/ETM/');
define('SITE_NAME',   'E-Transport Management System');
define('SITE_SHORT',  'ETrans');

// Connect
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);

// Check connection
if ($conn->connect_error) {
    die("
    <div style='font-family:sans-serif;background:#fff0f3;color:#cc0033;
                border:2px solid #ffb3c1;border-radius:12px;
                padding:24px 32px;max-width:500px;margin:60px auto;'>
        <h3>⚠️ Database Connection Failed</h3>
        <p style='margin-top:8px;font-size:14px;'>
            <strong>Error:</strong> " . $conn->connect_error . "
        </p>
        <p style='margin-top:12px;font-size:13px;color:#888;'>
            Make sure MySQL is running and the database
            <strong>transport_system</strong> exists in phpMyAdmin.
        </p>
    </div>
    ");
}

// Set charset
$conn->set_charset("utf8mb4");

// Start session safely
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
```
