<!-- ================= FOOTER START ================= -->

<footer style="
    background: #0b1f3a;
    color: white;
    padding: 60px 0 0;
    margin-top: 80px;
    font-family: 'DM Sans', sans-serif;
    border-top: 1px solid rgba(255,255,255,0.06);
">
    <div style="max-width:1100px; margin:0 auto; padding:0 32px;">

        <div style="display:grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap:40px; flex-wrap:wrap;">

            <!-- Brand -->
            <div>
                <div style="font-family:'Syne',sans-serif; font-size:24px; font-weight:800; margin-bottom:14px;">
                    E<span style="color:#00d4ff;">Trans</span>
                </div>
                <p style="color:rgba(255,255,255,0.5); font-size:14px; line-height:1.8; max-width:260px; margin-bottom:20px;">
                    A smart online bus booking system designed for easy, fast, and secure travel reservations. Book buses anytime, anywhere.
                </p>
                <!-- Social icons -->
                <div style="display:flex; gap:10px;">
                    <?php
                    $socials = [
                        ['fab fa-facebook-f', '#'],
                        ['fab fa-twitter',    '#'],
                        ['fab fa-instagram',  '#'],
                        ['fab fa-linkedin-in','#'],
                    ];
                    foreach($socials as $s): ?>
                    <a href="<?php echo $s[1]; ?>" style="
                        width:36px; height:36px; border-radius:50%;
                        background:rgba(255,255,255,0.07);
                        border:1px solid rgba(255,255,255,0.12);
                        display:flex; align-items:center; justify-content:center;
                        color:rgba(255,255,255,0.6); font-size:13px;
                        text-decoration:none;
                        transition:background .2s, color .2s;
                    " onmouseover="this.style.background='#1a5cff';this.style.color='white';"
                       onmouseout="this.style.background='rgba(255,255,255,0.07)';this.style.color='rgba(255,255,255,0.6)';">
                        <i class="<?php echo $s[0]; ?>"></i>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Quick Links -->
            <div>
                <div style="font-family:'Syne',sans-serif; font-size:13px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; color:rgba(255,255,255,0.35); margin-bottom:18px;">
                    Navigation
                </div>
                <ul style="list-style:none; padding:0; margin:0; display:flex; flex-direction:column; gap:12px;">
                    <?php
                    $links = [
                        ['Home',          '/index.php'],
                        ['Search Buses',  '/user/buses.php'],
                        ['My Dashboard',  '/user/dashboard.php'],
                        ['My Bookings',   '#'],
                        ['About',         '#'],
                    ];
                    foreach($links as $l): ?>
                    <li>
                        <a href="<?php echo $l[1]; ?>" style="
                            color:rgba(255,255,255,0.55); text-decoration:none;
                            font-size:14px; transition:color .2s;
                            display:flex; align-items:center; gap:8px;
                        " onmouseover="this.style.color='#00d4ff';"
                           onmouseout="this.style.color='rgba(255,255,255,0.55)';">
                            <i class="fas fa-chevron-right" style="font-size:10px; color:#1a5cff;"></i>
                            <?php echo $l[0]; ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <!-- Support -->
            <div>
                <div style="font-family:'Syne',sans-serif; font-size:13px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; color:rgba(255,255,255,0.35); margin-bottom:18px;">
                    Support
                </div>
                <ul style="list-style:none; padding:0; margin:0; display:flex; flex-direction:column; gap:12px;">
                    <?php
                    $support = [
                        ['Help Center',      '#'],
                        ['Cancellation Policy','#'],
                        ['Privacy Policy',   '#'],
                        ['Terms of Service', '#'],
                        ['Contact Us',       '#'],
                    ];
                    foreach($support as $s): ?>
                    <li>
                        <a href="<?php echo $s[1]; ?>" style="
                            color:rgba(255,255,255,0.55); text-decoration:none;
                            font-size:14px; transition:color .2s;
                            display:flex; align-items:center; gap:8px;
                        " onmouseover="this.style.color='#00d4ff';"
                           onmouseout="this.style.color='rgba(255,255,255,0.55)';">
                            <i class="fas fa-chevron-right" style="font-size:10px; color:#1a5cff;"></i>
                            <?php echo $s[0]; ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <!-- Contact -->
            <div>
                <div style="font-family:'Syne',sans-serif; font-size:13px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; color:rgba(255,255,255,0.35); margin-bottom:18px;">
                    Contact
                </div>
                <div style="display:flex; flex-direction:column; gap:14px;">
                    <?php
                    $contacts = [
                        ['fas fa-map-marker-alt', 'India'],
                        ['fas fa-envelope',       'support@etransport.com'],
                        ['fas fa-phone',          '+91 98765 43210'],
                        ['fas fa-clock',          'Mon–Sat, 9am–6pm'],
                    ];
                    foreach($contacts as $c): ?>
                    <div style="display:flex; align-items:flex-start; gap:12px;">
                        <div style="
                            width:32px; height:32px; border-radius:8px;
                            background:rgba(26,92,255,0.15);
                            display:flex; align-items:center; justify-content:center;
                            flex-shrink:0;
                        ">
                            <i class="<?php echo $c[0]; ?>" style="color:#00d4ff; font-size:13px;"></i>
                        </div>
                        <span style="color:rgba(255,255,255,0.55); font-size:13px; line-height:1.5; padding-top:6px;">
                            <?php echo $c[1]; ?>
                        </span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

        </div>

        <!-- Divider -->
        <div style="border-top:1px solid rgba(255,255,255,0.08); margin-top:50px; padding:22px 0; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px;">

            <div style="color:rgba(255,255,255,0.35); font-size:13px;">
                © <?php echo date("Y"); ?> <strong style="color:rgba(255,255,255,0.6);">ETrans</strong> — All rights reserved.
                Built as a College Project by <strong style="color:#00d4ff;">Team ETrans</strong>
            </div>

            <div style="display:flex; align-items:center; gap:8px;">
                <span style="
                    background:rgba(0,196,140,0.15);
                    border:1px solid rgba(0,196,140,0.3);
                    color:#00c48c;
                    font-size:12px; font-weight:700;
                    padding:4px 12px; border-radius:50px;
                    display:flex; align-items:center; gap:6px;
                ">
                    <span style="width:6px;height:6px;border-radius:50%;background:#00c48c;display:inline-block;animation:pulse 2s infinite;"></span>
                    All Systems Operational
                </span>
            </div>

        </div>
    </div>
</footer>

<style>
@keyframes pulse {
    0%,100% { opacity:1; }
    50%      { opacity:.4; }
}
@media (max-width: 768px) {
    footer > div > div:first-child {
        grid-template-columns: 1fr 1fr !important;
    }
}
@media (max-width: 480px) {
    footer > div > div:first-child {
        grid-template-columns: 1fr !important;
    }
}
</style>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<!-- ================= FOOTER END ================= -->