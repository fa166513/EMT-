<?php
// Start session safely
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$current_page = basename($_SERVER['PHP_SELF']);
$current_dir  = basename(dirname($_SERVER['PHP_SELF']));
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>E-Transport Management System</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">

<style>
/* ── RESET & GLOBALS ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
    --navy:  #0b1f3a;
    --blue:  #1a5cff;
    --cyan:  #00d4ff;
    --green: #00c48c;
    --gold:  #f5a623;
    --red:   #ff4d6d;
    --light: #f0f4ff;
    --white: #ffffff;
}

body {
    font-family: 'DM Sans', sans-serif;
    background: var(--light);
    color: var(--navy);
    overflow-x: hidden;
}

/* ── TOPBAR (optional announcement) ── */
.etrans-topbar {
    background: linear-gradient(90deg, var(--blue), #3a7bff);
    color: white;
    text-align: center;
    font-size: 12px;
    font-weight: 500;
    padding: 7px 20px;
    letter-spacing: .3px;
    display: flex; align-items: center; justify-content: center; gap: 8px;
}
.etrans-topbar a {
    color: var(--cyan); font-weight: 700; text-decoration: none;
}
.topbar-close {
    position: absolute; right: 20px;
    background: none; border: none; color: rgba(255,255,255,0.6);
    cursor: pointer; font-size: 14px;
    transition: color .2s;
}
.topbar-close:hover { color: white; }

/* ── NAVBAR ── */
.etrans-navbar {
    background: var(--navy);
    padding: 0 40px;
    height: 64px;
    display: flex; align-items: center; justify-content: space-between;
    position: sticky; top: 0; z-index: 1000;
    box-shadow: 0 4px 24px rgba(0,0,0,0.18);
}

/* Brand */
.nav-brand {
    font-family: 'Syne', sans-serif;
    font-size: 22px; font-weight: 800;
    color: var(--white); text-decoration: none;
    letter-spacing: -.5px;
    display: flex; align-items: center; gap: 8px;
    flex-shrink: 0;
}
.nav-brand span { color: var(--cyan); }
.nav-brand .brand-icon {
    width: 34px; height: 34px;
    background: linear-gradient(135deg, var(--blue), var(--cyan));
    border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    font-size: 16px;
}

/* Center links */
.nav-links {
    display: flex; align-items: center; gap: 4px;
    list-style: none;
}
.nav-links a {
    color: rgba(255,255,255,0.65);
    text-decoration: none;
    font-size: 14px; font-weight: 500;
    padding: 8px 16px; border-radius: 8px;
    transition: color .2s, background .2s;
    display: flex; align-items: center; gap: 7px;
    white-space: nowrap;
}
.nav-links a:hover { color: white; background: rgba(255,255,255,0.07); }
.nav-links a.active { color: var(--cyan); background: rgba(0,212,255,0.08); }
.nav-links a i { font-size: 13px; }

/* Right side */
.nav-right {
    display: flex; align-items: center; gap: 12px;
}

/* User chip */
.user-chip {
    display: flex; align-items: center; gap: 8px;
    background: rgba(255,255,255,0.07);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 50px;
    padding: 6px 16px 6px 8px;
    color: rgba(255,255,255,0.85);
    font-size: 13px; font-weight: 500;
    text-decoration: none;
    transition: background .2s;
    cursor: pointer; position: relative;
}
.user-chip:hover { background: rgba(255,255,255,0.12); color: white; }
.user-avatar {
    width: 28px; height: 28px;
    background: linear-gradient(135deg, var(--blue), var(--cyan));
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-family: 'Syne', sans-serif;
    font-size: 12px; font-weight: 800; color: white;
}

/* Dropdown */
.user-dropdown {
    position: absolute; top: calc(100% + 10px); right: 0;
    background: white;
    border-radius: 14px;
    box-shadow: 0 16px 48px rgba(11,31,58,0.18);
    padding: 8px;
    min-width: 180px;
    display: none;
    border: 1.5px solid #edf0f8;
    z-index: 999;
}
.user-chip:hover .user-dropdown,
.user-chip.open .user-dropdown { display: block; }
.dropdown-item-custom {
    display: flex; align-items: center; gap: 10px;
    padding: 10px 14px; border-radius: 10px;
    font-size: 13px; color: var(--navy); font-weight: 500;
    text-decoration: none; transition: background .15s;
}
.dropdown-item-custom:hover { background: var(--light); color: var(--blue); }
.dropdown-item-custom i { width: 16px; text-align: center; color: var(--blue); }
.dropdown-divider-custom { border-top: 1.5px solid #f0f4ff; margin: 6px 0; }
.dropdown-item-custom.logout { color: var(--red); }
.dropdown-item-custom.logout i { color: var(--red); }
.dropdown-item-custom.logout:hover { background: #fff0f3; }

/* Auth buttons */
.btn-nav-login {
    color: rgba(255,255,255,0.75);
    font-size: 14px; font-weight: 500;
    text-decoration: none; padding: 8px 16px;
    border-radius: 8px; transition: color .2s, background .2s;
    display: flex; align-items: center; gap: 7px;
}
.btn-nav-login:hover { color: white; background: rgba(255,255,255,0.07); }
.btn-nav-register {
    background: var(--blue); color: white;
    font-size: 14px; font-weight: 600;
    text-decoration: none; padding: 9px 20px;
    border-radius: 50px;
    display: flex; align-items: center; gap: 7px;
    transition: background .2s, transform .15s;
    box-shadow: 0 4px 14px rgba(26,92,255,0.35);
}
.btn-nav-register:hover { background: var(--cyan); color: var(--navy); transform: translateY(-1px); }

/* Mobile hamburger */
.nav-toggler {
    display: none;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.15);
    color: white; width: 38px; height: 38px;
    border-radius: 8px; cursor: pointer;
    align-items: center; justify-content: center;
    font-size: 16px;
}

/* Mobile menu */
.nav-mobile {
    display: none;
    background: #0d2444;
    padding: 16px 24px 20px;
    border-top: 1px solid rgba(255,255,255,0.07);
}
.nav-mobile.open { display: block; }
.nav-mobile a {
    display: flex; align-items: center; gap: 10px;
    color: rgba(255,255,255,0.7); text-decoration: none;
    font-size: 15px; font-weight: 500;
    padding: 12px 0;
    border-bottom: 1px solid rgba(255,255,255,0.06);
}
.nav-mobile a:last-child { border-bottom: none; }
.nav-mobile a:hover { color: var(--cyan); }
.nav-mobile a i { color: var(--blue); width: 18px; text-align: center; }

/* ── GLOBAL COMPONENT STYLES ── */
.card { border: none; border-radius: 16px; }
.btn-primary { background: var(--blue); border: none; border-radius: 10px; font-weight: 600; }
.btn-primary:hover { background: #1248d4; }

/* Scrollbar */
::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: #f0f4ff; }
::-webkit-scrollbar-thumb { background: #c0d0ee; border-radius: 6px; }

@media (max-width: 900px) {
    .etrans-navbar { padding: 0 20px; }
    .nav-links, .nav-right .btn-nav-login, .nav-right .btn-nav-register { display: none; }
    .nav-toggler { display: flex; }
}
</style>

</head>
<body>

<!-- ── ANNOUNCEMENT TOPBAR ── -->
<div class="etrans-topbar" id="topbar">
    <i class="fas fa-tag"></i>
    🎉 Book early and save up to 20% on selected routes!
    <a href="#">View Offers</a>
    <button class="topbar-close" onclick="document.getElementById('topbar').style.display='none'">
        <i class="fas fa-times"></i>
    </button>
</div>

<!-- ── NAVBAR ── -->
<nav class="etrans-navbar">

    <!-- Brand -->
    <a href="/ETM/index.php" class="nav-brand">
        <div class="brand-icon">🚌</div>
        E-Transport <span>Mgmt</span>
    </a>

    <!-- Center nav links -->
    <ul class="nav-links">
        <li>
            <a href="/ETM/index.php" class="<?php echo $current_page === 'index.php' ? 'active' : ''; ?>">
                <i class="fas fa-house"></i> Home
            </a>
        </li>
        <li>
            <a href="/ETM/user/buses.php" class="<?php echo $current_page === 'buses.php' ? 'active' : ''; ?>">
                <i class="fas fa-bus"></i> Routes
            </a>
        </li>
        <li>
            <a href="/ETM/user/dashboard.php" class="<?php echo $current_page === 'dashboard.php' ? 'active' : ''; ?>">
                <i class="fas fa-gauge-high"></i> Dashboard
            </a>
        </li>
        <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <li>
            <a href="/ETM/admin/admin-dashboard.php" class="<?php echo $current_dir === 'admin' ? 'active' : ''; ?>">
                <i class="fas fa-shield-halved"></i> Admin
            </a>
        </li>
        <?php endif; ?>
        <li>
            <a href="#">
                <i class="fas fa-headset"></i> Support
            </a>
        </li>
    </ul>

    <!-- Right side -->
    <div class="nav-right">

        <?php if(isset($_SESSION['user'])): ?>

        <!-- Logged in user chip with dropdown -->
        <div class="user-chip" id="userChip">
            <div class="user-avatar">
                <?php echo strtoupper(substr($_SESSION['user'], 0, 1)); ?>
            </div>
            <?php echo htmlspecialchars($_SESSION['user']); ?>
            <i class="fas fa-chevron-down" style="font-size:10px; color:rgba(255,255,255,0.4); margin-left:4px;"></i>

            <div class="user-dropdown">
                <a href="/ETM/user/dashboard.php" class="dropdown-item-custom">
                    <i class="fas fa-gauge-high"></i> Dashboard
                </a>
                <a href="#" class="dropdown-item-custom">
                    <i class="fas fa-ticket"></i> My Bookings
                </a>
                <a href="#" class="dropdown-item-custom">
                    <i class="fas fa-user"></i> Profile
                </a>
                <a href="#" class="dropdown-item-custom">
                    <i class="fas fa-gear"></i> Settings
                </a>
                <div class="dropdown-divider-custom"></div>
                <a href="/ETM/auth/logout.php" class="dropdown-item-custom logout">
                    <i class="fas fa-right-from-bracket"></i> Logout
                </a>
            </div>
        </div>

        <?php else: ?>

        <!-- Guest buttons -->
        <a href="/ETM/auth/login.php" class="btn-nav-login">
            <i class="fas fa-right-to-bracket"></i> Login
        </a>
        <a href="/ETM/auth/register.php" class="btn-nav-register">
            <i class="fas fa-user-plus"></i> Register
        </a>

        <?php endif; ?>

        <!-- Mobile toggler -->
        <button class="nav-toggler" onclick="toggleMobileMenu()">
            <i class="fas fa-bars" id="toggleIcon"></i>
        </button>

    </div>
</nav>

<!-- ── MOBILE MENU ── -->
<div class="nav-mobile" id="mobileMenu">
    <a href="/ETM/index.php"><i class="fas fa-house"></i> Home</a>
    <a href="/ETM/user/buses.php"><i class="fas fa-bus"></i> Routes</a>
    <a href="/ETM/user/dashboard.php"><i class="fas fa-gauge-high"></i> Dashboard</a>
    <a href="#"><i class="fas fa-headset"></i> Support</a>
    <?php if(isset($_SESSION['user'])): ?>
    <a href="/ETM/auth/logout.php"><i class="fas fa-right-from-bracket"></i> Logout</a>
    <?php else: ?>
    <a href="/ETM/auth/login.php"><i class="fas fa-right-to-bracket"></i> Login</a>
    <a href="/ETM/auth/register.php"><i class="fas fa-user-plus"></i> Register</a>
    <?php endif; ?>
</div>

<script>
function toggleMobileMenu() {
    const menu = document.getElementById('mobileMenu');
    const icon = document.getElementById('toggleIcon');
    menu.classList.toggle('open');
    icon.className = menu.classList.contains('open') ? 'fas fa-times' : 'fas fa-bars';
}

// Close mobile menu on outside click
document.addEventListener('click', function(e) {
    const menu    = document.getElementById('mobileMenu');
    const toggler = document.querySelector('.nav-toggler');
    if (!menu.contains(e.target) && !toggler.contains(e.target)) {
        menu.classList.remove('open');
        document.getElementById('toggleIcon').className = 'fas fa-bars';
    }
});

// User dropdown toggle
const chip = document.getElementById('userChip');
if (chip) {
    chip.addEventListener('click', function(e) {
        e.stopPropagation();
        this.classList.toggle('open');
    });
    document.addEventListener('click', () => chip.classList.remove('open'));
}
</script>