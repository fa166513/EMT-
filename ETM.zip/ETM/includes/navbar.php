<?php
// ensure session exists
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!-- ===== NAVBAR ===== -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
<div class="container">

<!-- Logo -->
<a class="navbar-brand fw-semibold" href="/index.php">
<i class="bi bi-bus-front-fill"></i> E-Transport
</a>

<!-- Mobile Toggle -->
<button class="navbar-toggler" type="button"
data-bs-toggle="collapse"
data-bs-target="#navbarMenu">
<span class="navbar-toggler-icon"></span>
</button>

<!-- Menu -->
<div class="collapse navbar-collapse" id="navbarMenu">

<ul class="navbar-nav ms-auto align-items-lg-center">

<li class="nav-item">
<a class="nav-link" href="/index.php">
<i class="bi bi-house-door"></i> Home
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="/user/dashboard.php">
<i class="bi bi-speedometer2"></i> Dashboard
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="/user/bookings.php">
<i class="bi bi-ticket-perforated"></i> My Bookings
</a>
</li>

<?php if(isset($_SESSION['user'])): ?>

<li class="nav-item">
<span class="nav-link">
<i class="bi bi-person-circle"></i>
<?php echo htmlspecialchars($_SESSION['user']); ?>
</span>
</li>

<li class="nav-item ms-lg-2">
<a href="/logout.php" class="btn btn-light btn-sm">
<i class="bi bi-box-arrow-right"></i> Logout
</a>
</li>

<?php else: ?>

<li class="nav-item ms-lg-2">
<a href="/login.php" class="btn btn-light btn-sm">
<i class="bi bi-box-arrow-in-right"></i> Login
</a>
</li>

<?php endif; ?>

</ul>

</div>
</div>
</nav>